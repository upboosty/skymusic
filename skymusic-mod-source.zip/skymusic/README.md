# Sky Music (Fabric, Minecraft 1.20.1, client-side)

Build: push to GitHub -> Actions tab -> "build" -> download artifact `skymusic-jar`.
Or locally: `gradle build` (Java 17) -> build/libs/skymusic-1.0.0.jar
Needs Fabric Loader + Fabric API.

Use: put song.mp3 / .ogg / .wav / .flac and song.lrc (same name) in <minecraft folder>/skymusic/
Commands: /sky list | play <name> | pause | resume | stop | volume <0-100> | folder
Tip: set Minecraft's Music volume to 0 so it doesn't overlap.

## Performance (built in)
/sky perf auto        - default. Watches FPS and steps quality low/balanced/high automatically
/sky perf low|balanced|high|off   - fixed profile (off restores your original settings; high = your own settings)
/sky perf target <fps>            - FPS goal for auto mode (default 60)
/sky perf status
Also: sky and post effect scale with the level; skips rendering far-away entities, and drops to 10 FPS while the window is in the background.
Settings are remembered in config/skymusic.properties.
Note: Minecraft saves option changes on exit, so a later launch may treat tuned values as your "original".

## For even more FPS (separate mods / launcher settings)
Mods: Sodium (PC; may not run on Android/Pojav), Lithium, FerriteCore, ImmediatelyFast, EntityCulling, ModernFix.
JVM args (Aikar flags, 4-6 GB): -Xms4G -Xmx4G -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200
 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40
 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4
 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5
 -XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1

## Custom sky (built in, no shader mod needed)
Replaces the overworld sky: smooth day/dusk/night gradient, glowing sun + moon, animated light rays, twinkling stars,
rain/thunder dimming. Costs ~1-3k flat triangles per frame, and scales down with /sky perf low.
Disable: set enabled=false in config/skymusic-sky.properties and restart.
Note: distant terrain fog is still vanilla-colored, so it may not match the horizon color exactly at dusk.

## Built-in shader (no Iris/Sodium needed)
One cheap full-screen post pass using vanilla's post-effect system: depth-masked sun god rays (10 taps),
vibrance, warm tint, soft contrast curve, vignette. Works together with the custom sky.
/sky fx auto|on|off   (auto = on at balanced/high perf level, off at low, since it costs one extra full-screen pass)
