package dev.skymusic.mixin;

import dev.skymusic.Perf;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.render.Camera;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Never spawn particles far from the camera: nobody sees them, but they still cost CPU every tick. */
@Mixin(ParticleManager.class)
public class ParticleManagerMixin {
    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true)
    private void skymusic$distanceCull(ParticleEffect effect, double x, double y, double z,
                                       double vx, double vy, double vz, CallbackInfoReturnable<Particle> cir) {
        double max = Perf.particleCull;
        if (max <= 0) return;
        Camera cam = MinecraftClient.getInstance().gameRenderer.getCamera();
        if (cam == null || !cam.isReady()) return;
        Vec3d p = cam.getPos();
        double dx = x - p.x, dy = y - p.y, dz = z - p.z;
        if (dx * dx + dy * dy + dz * dz > max * max) cir.setReturnValue(null);
    }
}
