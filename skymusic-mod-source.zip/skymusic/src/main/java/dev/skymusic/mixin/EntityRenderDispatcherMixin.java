package dev.skymusic.mixin;

import dev.skymusic.Perf;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Skips rendering entities beyond the performance cull distance (big/important ones excepted). */
@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void skymusic$distanceCull(Entity entity, Frustum frustum, double x, double y, double z,
                                       CallbackInfoReturnable<Boolean> cir) {
        double max = Perf.cullDistance;
        if (max <= 0) return;
        EntityType<?> t = entity.getType();
        if (t == EntityType.PLAYER || t == EntityType.ENDER_DRAGON || t == EntityType.WITHER
            || t == EntityType.GHAST || t == EntityType.GIANT) return;
        double dx = entity.getX() - x, dy = entity.getY() - y, dz = entity.getZ() - z;
        if (dx * dx + dy * dy + dz * dz > max * max) cir.setReturnValue(false);
    }
}
