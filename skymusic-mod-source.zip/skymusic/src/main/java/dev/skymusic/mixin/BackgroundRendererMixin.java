package dev.skymusic.mixin;

import dev.skymusic.CustomSky;
import net.minecraft.client.render.BackgroundRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** After vanilla sets up fog, recolor it so distant terrain melts into the custom sky's horizon. */
@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {
    @Inject(method = "applyFog", at = @At("TAIL"))
    private static void skymusic$matchFog(CallbackInfo ci) {
        CustomSky.applyFog();
    }
}
