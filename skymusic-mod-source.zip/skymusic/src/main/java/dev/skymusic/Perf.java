package dev.skymusic;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.*;

import java.io.*;
import java.nio.file.*;
import java.util.Objects;
import java.util.Properties;

/** Built-in performance manager: quality profiles, FPS-adaptive auto mode, entity distance culling, background FPS throttle. */
public class Perf {
    public enum Mode { OFF, LOW, BALANCED, HIGH, AUTO }
    private enum Level { LOW, BALANCED, HIGH }

    /** Read by the entity-culling mixin. 0 = disabled. */
    public static volatile double cullDistance = 0;
    /** 0 = low, 1 = medium, 2 = high; read by CustomSky. */
    public static volatile int skyQuality = 2;

    private record Snap(int view, int sim, ParticlesMode particles, double entDist, int blend,
                        CloudRenderMode clouds, boolean ao, boolean shadows, GraphicsMode gfx) {}

    private static Snap orig;
    private static Mode mode = Mode.AUTO;
    private static Level cur = Level.BALANCED;
    private static int target = 60;
    private static boolean started = false, throttled = false;
    private static int savedFps = 260, ticks = 0, lowCount = 0, highCount = 0;
    private static long lastChange = 0;
    private static Path cfg;

    public static void init() {
        cfg = FabricLoader.getInstance().getConfigDir().resolve("skymusic.properties");
        try (InputStream in = Files.newInputStream(cfg)) {
            Properties p = new Properties(); p.load(in);
            mode = Mode.valueOf(p.getProperty("mode", "AUTO").toUpperCase());
            target = Integer.parseInt(p.getProperty("target", "60"));
        } catch (Exception ignored) {}
        ClientTickEvents.END_CLIENT_TICK.register(Perf::tick);
    }

    private static void saveCfg() {
        try (OutputStream out = Files.newOutputStream(cfg)) {
            Properties p = new Properties();
            p.setProperty("mode", mode.name()); p.setProperty("target", String.valueOf(target));
            p.store(out, "Sky Music performance settings");
        } catch (Exception ignored) {}
    }

    private static <T> void put(SimpleOption<T> opt, T v) {
        if (!Objects.equals(opt.getValue(), v)) opt.setValue(v);   // only touch what changed (avoids reloads)
    }

    private static void snapshot(MinecraftClient mc) {
        if (orig != null) return;
        GameOptions o = mc.options;
        orig = new Snap(o.getViewDistance().getValue(), o.getSimulationDistance().getValue(), o.getParticles().getValue(),
            o.getEntityDistanceScaling().getValue(), o.getBiomeBlendRadius().getValue(), o.getCloudRenderMode().getValue(),
            o.getAo().getValue(), o.getEntityShadows().getValue(), o.getGraphicsMode().getValue());
    }

    private static void set(Snap s, double cull) {
        GameOptions o = MinecraftClient.getInstance().options;
        put(o.getViewDistance(), s.view()); put(o.getSimulationDistance(), s.sim());
        put(o.getParticles(), s.particles()); put(o.getEntityDistanceScaling(), s.entDist());
        put(o.getBiomeBlendRadius(), s.blend()); put(o.getCloudRenderMode(), s.clouds());
        put(o.getAo(), s.ao()); put(o.getEntityShadows(), s.shadows()); put(o.getGraphicsMode(), s.gfx());
        cullDistance = cull;
    }

    private static void apply(Level l) {
        cur = l;
        skyQuality = switch (l) { case LOW -> 0; case BALANCED -> 1; default -> 2; };
        switch (l) {
            case LOW -> set(new Snap(Math.min(orig.view(), 6), Math.min(orig.sim(), 5), ParticlesMode.MINIMAL, 0.5, 0,
                CloudRenderMode.OFF, false, false, GraphicsMode.FAST), 32);
            case BALANCED -> set(new Snap(Math.min(orig.view(), 10), Math.min(orig.sim(), 8), ParticlesMode.DECREASED, 0.75, 1,
                CloudRenderMode.FAST, orig.ao(), false, orig.gfx() == GraphicsMode.FABULOUS ? GraphicsMode.FANCY : orig.gfx()), 64);
            case HIGH -> set(orig, 128);   // your own settings, plus light entity culling
        }
    }

    public static void setMode(Mode m, boolean announce) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        mode = m; lowCount = highCount = 0; lastChange = System.currentTimeMillis();
        if (m == Mode.OFF) {
            if (orig != null) set(orig, 0);
            cullDistance = 0;
            skyQuality = 2;
        } else {
            snapshot(mc);
            apply(m == Mode.AUTO ? Level.BALANCED : Level.valueOf(m.name()));
        }
        saveCfg();
        if (announce) SkyMusicClient.msg("Performance mode: " + m.name().toLowerCase());
    }

    private static void tick(MinecraftClient mc) {
        if (mc.options == null) return;
        if (!started && mc.world != null) { started = true; setMode(mode, false); }
        if (mode == Mode.OFF) {
            if (throttled) { put(mc.options.getMaxFps(), savedFps); throttled = false; }
            return;
        }
        // drop to 10 FPS while the game window is in the background
        boolean focused = mc.isWindowFocused();
        if (!focused && !throttled) { savedFps = mc.options.getMaxFps().getValue(); put(mc.options.getMaxFps(), 10); throttled = true; }
        else if (focused && throttled) { put(mc.options.getMaxFps(), savedFps); throttled = false; }

        if (mode != Mode.AUTO || ++ticks % 20 != 0) return;
        if (mc.world == null || mc.currentScreen != null || !focused) return;

        int fps = mc.getCurrentFps();
        long now = System.currentTimeMillis();
        if (fps < target * 0.85) { lowCount++; highCount = 0; }
        else if (fps > target * 1.6) { highCount++; lowCount = 0; }
        else { lowCount = highCount = 0; }

        if (lowCount >= 5 && now - lastChange > 20_000 && cur != Level.LOW) {
            apply(cur == Level.HIGH ? Level.BALANCED : Level.LOW);
            lastChange = now; lowCount = 0;
            SkyMusicClient.msg("Auto: FPS low, lowered quality to " + cur.name().toLowerCase());
        } else if (highCount >= 30 && now - lastChange > 60_000 && cur != Level.HIGH) {
            apply(cur == Level.LOW ? Level.BALANCED : Level.HIGH);
            lastChange = now; highCount = 0;
            SkyMusicClient.msg("Auto: FPS is great, raised quality to " + cur.name().toLowerCase());
        }
    }

    public static LiteralArgumentBuilder<FabricClientCommandSource> node() {
        LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("perf");
        for (Mode m : Mode.values())
            root.then(ClientCommandManager.literal(m.name().toLowerCase()).executes(c -> { setMode(m, true); return 1; }));
        root.then(ClientCommandManager.literal("target").then(
            ClientCommandManager.argument("fps", IntegerArgumentType.integer(20, 240)).executes(c -> {
                target = IntegerArgumentType.getInteger(c, "fps"); saveCfg();
                SkyMusicClient.msg("Auto target FPS: " + target); return 1; })));
        root.then(ClientCommandManager.literal("status").executes(c -> {
            SkyMusicClient.msg("mode=" + mode.name().toLowerCase() + ", level=" + cur.name().toLowerCase()
                + ", target=" + target + ", fps=" + MinecraftClient.getInstance().getCurrentFps()
                + ", entity cull=" + (cullDistance > 0 ? (int) cullDistance + " blocks" : "off")); return 1; }));
        return root;
    }
}
