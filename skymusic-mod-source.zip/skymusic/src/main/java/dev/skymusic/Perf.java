package dev.skymusic;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.*;

import java.io.*;
import java.nio.file.*;
import java.util.Objects;
import java.util.Properties;

/**
 * Performance manager. Quality is a ladder of 7 small steps (0 = your own settings untouched, 6 = potato).
 * Auto mode walks the ladder one step at a time, remembers steps that were too heavy, and avoids oscillating.
 * Also drives entity culling, particle culling and the sky/post-effect quality.
 */
public class Perf {
    public enum Mode { OFF, LOW, BALANCED, HIGH, AUTO }
    private static final int MAX_LEVEL = 6;

    /** Read by the culling mixins. 0 = disabled. */
    public static volatile double cullDistance = 0;
    public static volatile double particleCull = 0;
    /** 0 = low, 1 = medium, 2 = high; read by CustomSky / PostFx / SkyRenderer. */
    public static volatile int skyQuality = 2;

    private record Snap(int view, int sim, ParticlesMode particles, double entDist, int blend,
                        CloudRenderMode clouds, boolean ao, boolean shadows, GraphicsMode gfx) {}

    // per-level tables (index = level)
    private static final int[] VIEW_CAP    = {99, 99, 99, 12, 10, 8, 6};
    private static final int[] SIM_CAP     = {99, 99, 99, 10, 8, 6, 5};
    private static final int[] PART_FLOOR  = {0, 0, 1, 1, 1, 1, 2};          // 0 all, 1 decreased, 2 minimal
    private static final int[] CLOUD_MAX   = {2, 2, 2, 1, 1, 1, 0};          // 0 off, 1 fast, 2 fancy
    private static final int[] BLEND_CAP   = {9, 2, 2, 1, 1, 0, 0};
    private static final double[] ENT_CAP  = {9, 9, 9, 9, 0.75, 0.75, 0.5};
    private static final double[] CULL     = {0, 128, 96, 80, 64, 48, 32};
    private static final double[] PCULL    = {0, 64, 48, 40, 32, 24, 16};

    private static Snap orig;
    private static Mode mode = Mode.AUTO;
    private static int level = 2;
    private static int target = 60;
    private static boolean started = false, throttled = false;
    private static int savedFps = 260, ticks = 0, lowCount = 0, highCount = 0;
    private static long lastChange = 0, lastUp = 0;
    private static final long[] badUntil = new long[MAX_LEVEL + 1];
    private static Path cfg;

    public static void init() {
        cfg = FabricLoader.getInstance().getConfigDir().resolve("skymusic.properties");
        try (InputStream in = Files.newInputStream(cfg)) {
            Properties p = new Properties(); p.load(in);
            mode = Mode.valueOf(p.getProperty("mode", "AUTO").toUpperCase());
            target = Integer.parseInt(p.getProperty("target", "60"));
        } catch (Exception ignored) {}
        ClientTickEvents.END_CLIENT_TICK.register(Perf::tick);
    }

    private static void saveCfg() {
        try (OutputStream out = Files.newOutputStream(cfg)) {
            Properties p = new Properties();
            p.setProperty("mode", mode.name()); p.setProperty("target", String.valueOf(target));
            p.store(out, "Sky Music performance settings");
        } catch (Exception ignored) {}
    }

    private static <T> void put(SimpleOption<T> opt, T v) {
        if (!Objects.equals(opt.getValue(), v)) opt.setValue(v);   // only touch what changed (avoids reloads)
    }

    private static void snapshot(MinecraftClient mc) {
        if (orig != null) return;
        GameOptions o = mc.options;
        orig = new Snap(o.getViewDistance().getValue(), o.getSimulationDistance().getValue(), o.getParticles().getValue(),
            o.getEntityDistanceScaling().getValue(), o.getBiomeBlendRadius().getValue(), o.getCloudRenderMode().getValue(),
            o.getAo().getValue(), o.getEntityShadows().getValue(), o.getGraphicsMode().getValue());
    }

    private static void restoreOriginal() {
        if (orig == null) return;
        GameOptions o = MinecraftClient.getInstance().options;
        put(o.getViewDistance(), orig.view()); put(o.getSimulationDistance(), orig.sim());
        put(o.getParticles(), orig.particles()); put(o.getEntityDistanceScaling(), orig.entDist());
        put(o.getBiomeBlendRadius(), orig.blend()); put(o.getCloudRenderMode(), orig.clouds());
        put(o.getAo(), orig.ao()); put(o.getEntityShadows(), orig.shadows()); put(o.getGraphicsMode(), orig.gfx());
    }

    private static void applyLevel(int L) {
        L = Math.max(0, Math.min(MAX_LEVEL, L));
        level = L;
        GameOptions o = MinecraftClient.getInstance().options;
        put(o.getViewDistance(), Math.min(orig.view(), VIEW_CAP[L]));
        put(o.getSimulationDistance(), Math.min(orig.sim(), SIM_CAP[L]));
        put(o.getParticles(), ParticlesMode.values()[Math.max(orig.particles().ordinal(), PART_FLOOR[L])]);
        put(o.getCloudRenderMode(), CloudRenderMode.values()[Math.min(orig.clouds().ordinal(), CLOUD_MAX[L])]);
        put(o.getBiomeBlendRadius(), Math.min(orig.blend(), BLEND_CAP[L]));
        put(o.getEntityDistanceScaling(), Math.min(orig.entDist(), ENT_CAP[L]));
        put(o.getEntityShadows(), L >= 1 ? false : orig.shadows());
        put(o.getAo(), L >= 5 ? false : orig.ao());
        GraphicsMode g = orig.gfx();
        if (L >= 6) g = GraphicsMode.FAST;
        else if (L >= 4 && g == GraphicsMode.FABULOUS) g = GraphicsMode.FANCY;
        put(o.getGraphicsMode(), g);
        cullDistance = CULL[L];
        particleCull = PCULL[L];
        skyQuality = L <= 1 ? 2 : L <= 4 ? 1 : 0;
    }

    public static void setMode(Mode m, boolean announce) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        mode = m; lowCount = highCount = 0; lastChange = System.currentTimeMillis();
        if (m == Mode.OFF) {
            restoreOriginal();
            level = 0; cullDistance = 0; particleCull = 0; skyQuality = 2;
        } else {
            snapshot(mc);
            switch (m) {
                case LOW -> applyLevel(6);
                case BALANCED -> applyLevel(3);
                case HIGH -> applyLevel(1);
                default -> applyLevel(2);
            }
        }
        saveCfg();
        if (announce) SkyMusicClient.msg("Performance mode: " + m.name().toLowerCase() + " (level " + level + "/" + MAX_LEVEL + ")");
    }

    private static void tick(MinecraftClient mc) {
        if (mc.options == null) return;
        if (!started && mc.world != null) { started = true; setMode(mode, false); }
        if (mode == Mode.OFF) {
            if (throttled) { put(mc.options.getMaxFps(), savedFps); throttled = false; }
            return;
        }
        // drop to 10 FPS while the game window is in the background
        boolean focused = mc.isWindowFocused();
        if (!focused && !throttled) { savedFps = mc.options.getMaxFps().getValue(); put(mc.options.getMaxFps(), 10); throttled = true; }
        else if (focused && throttled) { put(mc.options.getMaxFps(), savedFps); throttled = false; }

        if (mode != Mode.AUTO || ++ticks % 20 != 0) return;
        if (mc.world == null || mc.currentScreen != null || !focused) return;

        int fps = mc.getCurrentFps();
        long now = System.currentTimeMillis();
        if (fps < target * 0.9) { lowCount++; highCount = 0; }
        else if (fps > target * 1.5) { highCount++; lowCount = 0; }
        else { lowCount = highCount = 0; }

        if (lowCount >= 4 && now - lastChange > 12_000 && level < MAX_LEVEL) {
            if (now - lastUp < 90_000) badUntil[level] = now + 300_000;   // we just climbed here and it was too heavy
            applyLevel(level + 1);
            lastChange = now; lowCount = 0;
            SkyMusicClient.msg("Auto: " + fps + " FPS, quality step " + level + "/" + MAX_LEVEL);
        } else if (highCount >= 25 && now - lastChange > 45_000 && level > 1) {
            if (now < badUntil[level - 1]) { highCount = 0; }
            else {
                applyLevel(level - 1);
                lastChange = now; lastUp = now; highCount = 0;
                SkyMusicClient.msg("Auto: plenty of FPS, quality step " + level + "/" + MAX_LEVEL);
            }
        }
    }

    public static LiteralArgumentBuilder<FabricClientCommandSource> node() {
        LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("perf");
        for (Mode m : Mode.values())
            root.then(ClientCommandManager.literal(m.name().toLowerCase()).executes(c -> { setMode(m, true); return 1; }));
        root.then(ClientCommandManager.literal("target").then(
            ClientCommandManager.argument("fps", IntegerArgumentType.integer(20, 240)).executes(c -> {
                target = IntegerArgumentType.getInteger(c, "fps"); saveCfg();
                SkyMusicClient.msg("Auto target FPS: " + target); return 1; })));
        root.then(ClientCommandManager.literal("status").executes(c -> {
            SkyMusicClient.msg("mode=" + mode.name().toLowerCase() + ", step=" + level + "/" + MAX_LEVEL
                + ", target=" + target + ", fps=" + MinecraftClient.getInstance().getCurrentFps()
                + ", entity cull=" + (cullDistance > 0 ? (int) cullDistance + "b" : "off")
                + ", particle cull=" + (particleCull > 0 ? (int) particleCull + "b" : "off")); return 1; }));
        return root;
    }
}
