package dev.skymusic;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector4f;

/** Built-in "shader": one cheap full-screen post pass (sun rays + color grading), no Iris/Sodium needed. */
public class PostFx {
    public enum Mode { AUTO, ON, OFF }
    private static Mode mode = Mode.AUTO;
    private static PostEffectProcessor proc;
    private static int w, h;
    private static boolean failed = false;

    public static boolean active() {
        return mode == Mode.ON || (mode == Mode.AUTO && Perf.skyQuality >= 1);
    }

    public static void init() {
        WorldRenderEvents.END.register(PostFx::render);
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(
            new SimpleSynchronousResourceReloadListener() {
                @Override public Identifier getFabricId() { return new Identifier("skymusic", "postfx"); }
                @Override public void reload(ResourceManager rm) {
                    if (proc != null) { try { proc.close(); } catch (Exception ignored) {} proc = null; }
                    failed = false;
                }
            });
    }

    private static float sm(float a, float b, float x) {
        float t = Math.max(0f, Math.min(1f, (x - a) / (b - a)));
        return t * t * (3f - 2f * t);
    }

    private static void render(WorldRenderContext ctx) {
        if (failed || !active()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = ctx.world();
        if (world == null) return;
        try {
            if (proc == null) {
                proc = new PostEffectProcessor(mc.getTextureManager(), mc.getResourceManager(), mc.getFramebuffer(),
                    new Identifier("skymusic", "shaders/post/potato.json"));
                w = h = 0;
            }
            int fw = mc.getWindow().getFramebufferWidth(), fh = mc.getWindow().getFramebufferHeight();
            if (fw != w || fh != h) { proc.setupDimensions(fw, fh); w = fw; h = fh; }

            // sun position on screen
            float td = ctx.tickDelta();
            float ang = world.getSkyAngle(td) * (float) (Math.PI * 2);
            float sx = -(float) Math.sin(ang), sy = (float) Math.cos(ang);
            float rain = world.getRainGradient(td);
            float vis = sm(-0.05f, 0.25f, sy) * (1f - rain);
            float u = 0.5f, v = 0.5f;
            Matrix4f vp = new Matrix4f(ctx.projectionMatrix()).mul(ctx.matrixStack().peek().getPositionMatrix());
            Vector4f c = new Vector4f(sx * 100f, sy * 100f, 0f, 1f);
            vp.transform(c);
            if (c.w <= 0f) vis = 0f; else { u = c.x / c.w * 0.5f + 0.5f; v = c.y / c.w * 0.5f + 0.5f; }

            proc.setUniforms("SunU", u);
            proc.setUniforms("SunV", v);
            proc.setUniforms("RayVis", vis);
            proc.setUniforms("Warm", 1f - sm(0f, 0.5f, sy));
            proc.setUniforms("Aspect", fw / (float) fh);

            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.resetTextureMatrix();
            proc.render(td);
            mc.getFramebuffer().beginWrite(false);
            RenderSystem.enableDepthTest();
        } catch (Throwable e) {
            failed = true;
            proc = null;
            SkyMusicClient.msg("Post effect disabled (error: " + e + ")");
        }
    }

    public static LiteralArgumentBuilder<FabricClientCommandSource> node() {
        LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("fx");
        for (Mode m : Mode.values())
            root.then(ClientCommandManager.literal(m.name().toLowerCase()).executes(c -> {
                mode = m; failed = false;
                SkyMusicClient.msg("Post effect: " + m.name().toLowerCase() + (m == Mode.AUTO ? " (on at balanced/high, off at low)" : ""));
                return 1; }));
        return root;
    }
}
