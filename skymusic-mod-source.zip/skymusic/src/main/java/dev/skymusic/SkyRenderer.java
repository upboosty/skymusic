package dev.skymusic;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;

/** Draws the current + next lyric line as big billboard text high in the sky. */
public class SkyRenderer {
    private static int lastIdx = -2;
    private static float anchorYaw = 0;
    private static double lineStart = 0;

    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        AudioPlayer ap = SkyMusicClient.PLAYER;
        double t = ap.getTime();
        Lrc lrc = SkyMusicClient.lyrics;
        if (t < 0 || lrc == null || lrc.lines.isEmpty()) return;

        int idx = lrc.indexAt(t);
        if (idx < 0) return;
        if (idx != lastIdx) {
            lastIdx = idx;
            anchorYaw = ctx.camera().getYaw();   // lock the line in the sky where you were looking
            lineStart = t;
        }
        String cur = lrc.lines.get(idx).text();
        String next = idx + 1 < lrc.lines.size() ? lrc.lines.get(idx + 1).text() : "";

        float fade = (float) Math.min(1.0, (t - lineStart) / 0.35);
        int a = Math.max(8, (int) (255 * fade));

        double rad = Math.toRadians(anchorYaw);
        double dist = 50;
        double dx = -Math.sin(rad) * dist, dz = Math.cos(rad) * dist;
        double dy = 26;

        MatrixStack m = ctx.matrixStack();
        Camera cam = ctx.camera();
        VertexConsumerProvider.Immediate vc = mc.getBufferBuilders().getEntityVertexConsumers();

        if (!cur.isEmpty()) draw(m, vc, cam, mc.textRenderer, cur, dx, dy, dz, 0.45f, (a << 24) | 0xFFFFFF);
        if (!next.isEmpty()) draw(m, vc, cam, mc.textRenderer, next, dx, dy - 7, dz, 0.28f, (0x90 << 24) | 0xBBBBFF);
        vc.draw();
    }

    private static void draw(MatrixStack m, VertexConsumerProvider vc, Camera cam, TextRenderer tr,
                             String s, double x, double y, double z, float scale, int color) {
        m.push();
        m.translate(x, y, z);
        m.multiply(cam.getRotation());
        m.scale(-scale, -scale, scale);
        float w = -tr.getWidth(s) / 2f;
        tr.draw(s, w, 0, color, true, m.peek().getPositionMatrix(), vc,
                TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        m.pop();
    }
}
