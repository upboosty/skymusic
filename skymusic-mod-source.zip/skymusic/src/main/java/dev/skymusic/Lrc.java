package dev.skymusic;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/** .lrc parser. Also copes with text copied from an API/JSON (literal \n sequences, one giant line). */
public class Lrc {
    public record Line(double time, String text) {}
    private static final Pattern TAG = Pattern.compile("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]");
    private static final Pattern WORD_TAG = Pattern.compile("<\\d+:\\d+(?:[.:]\\d+)?>");
    public final List<Line> lines = new ArrayList<>();

    public static Lrc load(Path file) {
        Lrc l = new Lrc();
        String c;
        try { c = new String(Files.readAllBytes(file), StandardCharsets.UTF_8); }
        catch (Exception e) { return l; }
        if (c.startsWith("\uFEFF")) c = c.substring(1);
        // turn JSON-style escapes into real characters
        c = c.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\r", "\n").replace("\\\"", "\"").replace("\r", "\n");

        List<Integer> starts = new ArrayList<>(), ends = new ArrayList<>();
        List<Double> times = new ArrayList<>();
        Matcher m = TAG.matcher(c);
        while (m.find()) {
            double t = Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2));
            if (m.group(3) != null) t += Double.parseDouble("0." + m.group(3));
            starts.add(m.start()); ends.add(m.end()); times.add(t);
        }
        List<Double> pending = new ArrayList<>();
        for (int i = 0; i < times.size(); i++) {
            pending.add(times.get(i));
            boolean hasNext = i + 1 < times.size();
            String seg = c.substring(ends.get(i), hasNext ? starts.get(i + 1) : c.length());
            if (seg.isEmpty() && hasNext) continue;          // stacked tags: [t1][t2]text
            String text = clean(seg);
            for (double t : pending) l.lines.add(new Line(t, text));
            pending.clear();
        }
        l.lines.sort(Comparator.comparingDouble(Line::time));
        return l;
    }

    private static String clean(String seg) {
        int nl = seg.indexOf('\n');
        if (nl >= 0) seg = seg.substring(0, nl);
        int q = seg.indexOf("\",\"");                          // JSON junk after the last line
        if (q >= 0) seg = seg.substring(0, q);
        seg = WORD_TAG.matcher(seg).replaceAll("").trim();
        if (seg.endsWith("\"")) seg = seg.substring(0, seg.length() - 1).trim();
        return seg;
    }

    public int indexAt(double t) {
        int idx = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).time() <= t) idx = i; else break;
        }
        return idx;
    }
}
