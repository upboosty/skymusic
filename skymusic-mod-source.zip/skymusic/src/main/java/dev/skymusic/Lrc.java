package dev.skymusic;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/** .lrc parser. Also copes with text copied from an API/JSON (literal \n sequences, one giant line). */
public class Lrc {
    public record Line(double time, String text) {}
    private static final Pattern TAG = Pattern.compile("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]");
    private static final Pattern WORD_TAG = Pattern.compile("<\\d+:\\d+(?:[.:]\\d+)?>");
    public final List<Line> lines = new ArrayList<>();

    public static Lrc load(Path file) {
        Lrc l = new Lrc();
        String c;
        try { c = new String(Files.readAllBytes(file), StandardCharsets.UTF_8); }
        catch (Exception e) { return l; }
        if (c.startsWith("\uFEFF")) c = c.substring(1);
        // turn JSON-style escapes into real characters
        c = c.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\r", "\n").replace("\\\"", "\"").replace("\r", "\n");

        List<Integer> starts = new ArrayList<>(), ends = new ArrayList<>();
        List<Double> times = new ArrayList<>();
        Matcher m = TAG.matcher(c);
        while (m.find()) {
            double t = Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2));
            if (m.group(3) != null) t += Double.parseDouble("0." + m.group(3));
            starts.add(m.start()); ends.add(m.end()); times.add(t);
        }
        List<Double> pending = new ArrayList<>();
        for (int i = 0; i < times.size(); i++) {
            pending.add(times.get(i));
            boolean hasNext = i + 1 < times.size();
            String seg = c.substring(ends.get(i), hasNext ? starts.get(i + 1) : c.length());
            if (seg.isEmpty() && hasNext) continue;          // stacked tags: [t1][t2]text
            String text = clean(seg);
            for (double t : pending) l.lines.add(new Line(t, text));
            pending.clear();
        }
        l.lines.sort(Comparator.comparingDouble(Line::time));
        return l;
    }

    private static String clean(String seg) {
        int nl = seg.indexOf('\n');
        if (nl >= 0) seg = seg.substring(0, nl);
        int q = seg.indexOf("\",\"");                          // JSON junk after the last line
        if (q >= 0) seg = seg.substring(0, q);
        seg = WORD_TAG.matcher(seg).replaceAll("").trim();
        if (seg.endsWith("\"")) seg = seg.substring(0, seg.length() - 1).trim();
        return seg;
    }

    /** true when the file has no real timing (e.g. every line is [00:00.00]) */
    public boolean unsynced() {
        if (lines.size() < 2) return false;
        return lines.get(lines.size() - 1).time() - lines.get(0).time() < 1.0;
    }

    /** Spread the lines over the song, longer lines get more time. Only an estimate. */
    public void spread(double dur) {
        if (lines.isEmpty() || dur <= 5) return;
        double start = Math.min(8.0, dur * 0.08), end = Math.max(start + 5, dur - Math.min(10.0, dur * 0.06));
        double total = 0;
        for (Line l : lines) total += l.text().length() + 12;
        List<Line> out = new ArrayList<>();
        double acc = 0;
        for (Line l : lines) {
            out.add(new Line(start + (end - start) * acc / total, l.text()));
            acc += l.text().length() + 12;
        }
        lines.clear();
        lines.addAll(out);
    }

    public int indexAt(double t) {
        int idx = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).time() <= t) idx = i; else break;
        }
        return idx;
    }
}
