package dev.skymusic;

import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/** Minimal .lrc parser: [mm:ss.xx] text */
public class Lrc {
    public record Line(double time, String text) {}
    private static final Pattern TAG = Pattern.compile("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]");
    public final List<Line> lines = new ArrayList<>();

    public static Lrc load(Path file) {
        Lrc l = new Lrc();
        try {
            for (String raw : Files.readAllLines(file)) {
                Matcher m = TAG.matcher(raw);
                List<Double> times = new ArrayList<>();
                int end = 0;
                while (m.find()) {
                    double t = Integer.parseInt(m.group(1)) * 60 + Integer.parseInt(m.group(2));
                    if (m.group(3) != null) t += Double.parseDouble("0." + m.group(3));
                    times.add(t);
                    end = m.end();
                }
                String text = raw.substring(end).trim();
                for (double t : times) l.lines.add(new Line(t, text));
            }
        } catch (Exception ignored) {}
        l.lines.sort(Comparator.comparingDouble(Line::time));
        return l;
    }

    public int indexAt(double t) {
        int idx = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).time() <= t) idx = i; else break;
        }
        return idx;
    }
}
