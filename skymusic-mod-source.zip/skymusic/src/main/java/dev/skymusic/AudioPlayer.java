package dev.skymusic;

import javazoom.jl.decoder.*;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.AL11;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.io.*;
import java.nio.*;
import java.nio.file.*;

/** Decodes mp3/ogg and plays through Minecraft's own OpenAL context. */
public class AudioPlayer {
    private record Decoded(ShortBuffer pcm, int channels, int rate) {}

    private int source = 0, buffer = 0;
    private boolean paused = false;
    private float volume = 0.7f;
    private volatile boolean loading = false;
    private volatile int token = 0;
    private float master = 1f;
    private long startNanos, pauseStart;
    private double pausedTotal;
    private boolean useWall = false;

    public boolean isActive() { return source != 0; }
    public boolean isLoading() { return loading; }

    public void play(Path file, Runnable onStarted, java.util.function.Consumer<String> onError) {
        stop();
        loading = true;
        final int myToken = ++token;
        Thread t = new Thread(() -> {
            try {
                Decoded d = decode(file);
                MinecraftClient.getInstance().execute(() -> {
                    loading = false;
                    if (myToken != token) { MemoryUtil.memFree(d.pcm()); return; }
                    start(d);
                    onStarted.run();
                });
            } catch (Throwable e) {
                loading = false;
                onError.accept(e.toString());
            }
        }, "skymusic-decode");
        t.setDaemon(true);
        t.start();
    }

    private void start(Decoded d) {
        buffer = AL10.alGenBuffers();
        AL10.alBufferData(buffer, d.channels() == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, d.pcm(), d.rate());
        MemoryUtil.memFree(d.pcm());
        source = AL10.alGenSources();
        AL10.alSourcei(source, AL10.AL_BUFFER, buffer);
        AL10.alSourcei(source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
        AL10.alSourcef(source, AL10.AL_GAIN, volume * master);
        AL10.alSourcePlay(source);
        paused = false;
        startNanos = System.nanoTime();
        pausedTotal = 0;
        useWall = false;
    }

    public void stop() {
        token++;
        if (source != 0) {
            AL10.alSourceStop(source);
            AL10.alDeleteSources(source);
            AL10.alDeleteBuffers(buffer);
            source = 0; buffer = 0;
        }
        paused = false;
    }

    public void pause() {
        if (source != 0 && !paused) { AL10.alSourcePause(source); paused = true; pauseStart = System.nanoTime(); }
    }
    public void resume() {
        if (source != 0 && paused) {
            AL10.alSourcePlay(source); paused = false;
            pausedTotal += (System.nanoTime() - pauseStart) / 1e9;
        }
    }

    public void setVolume(float v) { volume = Math.max(0, Math.min(1, v)); applyGain(); }
    public void setMaster(float m) { if (m != master) { master = m; applyGain(); } }
    private void applyGain() { if (source != 0) AL10.alSourcef(source, AL10.AL_GAIN, volume * master); }

    /** Seconds into the song, or -1 if nothing is playing. Auto-cleans up when finished. */
    public double getTime() {
        if (source == 0) return -1;
        int state = AL10.alGetSourcei(source, AL10.AL_SOURCE_STATE);
        if (state == AL10.AL_STOPPED) { stop(); return -1; }
        double wall = ((paused ? pauseStart : System.nanoTime()) - startNanos) / 1e9 - pausedTotal;
        double off = AL10.alGetSourcef(source, AL11.AL_SEC_OFFSET);
        // if the audio clock never moves on this device, fall back to the wall clock
        if (!useWall && !paused && wall > 1.5 && off <= 0.0005) useWall = true;
        return useWall ? wall : off;
    }

    private static Decoded decode(Path file) throws Exception {
        String n = file.getFileName().toString().toLowerCase();
        if (n.endsWith(".ogg")) return decodeOgg(file);
        if (n.endsWith(".mp3")) return decodeMp3(file);
        if (n.endsWith(".wav")) return decodeWav(file);
        if (n.endsWith(".flac")) return decodeFlac(file);
        throw new IOException("Unsupported format (use .mp3, .ogg, .wav or .flac)");
    }

    private static Decoded decodeOgg(Path file) throws IOException {
        byte[] bytes = Files.readAllBytes(file);
        ByteBuffer in = MemoryUtil.memAlloc(bytes.length);
        in.put(bytes).flip();
        try (MemoryStack stack = MemoryStack.stackPush()) {
            IntBuffer ch = stack.mallocInt(1), rate = stack.mallocInt(1);
            ShortBuffer pcm = STBVorbis.stb_vorbis_decode_memory(in, ch, rate);
            if (pcm == null) throw new IOException("Could not decode ogg");
            // stb allocs with malloc; copy to a MemoryUtil buffer so we can free safely
            ShortBuffer copy = MemoryUtil.memAllocShort(pcm.remaining());
            copy.put(pcm).flip();
            org.lwjgl.system.libc.LibCStdlib.free(pcm);
            return new Decoded(copy, ch.get(0), rate.get(0));
        } finally {
            MemoryUtil.memFree(in);
        }
    }

    private static Decoded decodeMp3(Path file) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream(1 << 22);
        int rate = 44100, ch = 2;
        try (InputStream is = new BufferedInputStream(Files.newInputStream(file))) {
            Bitstream bs = new Bitstream(is);
            Decoder dec = new Decoder();
            Header h;
            while ((h = bs.readFrame()) != null) {
                SampleBuffer sb = (SampleBuffer) dec.decodeFrame(h, bs);
                rate = sb.getSampleFrequency();
                ch = sb.getChannelCount();
                short[] b = sb.getBuffer();
                int len = sb.getBufferLength();
                for (int i = 0; i < len; i++) { out.write(b[i] & 0xFF); out.write((b[i] >> 8) & 0xFF); }
                bs.closeFrame();
            }
        }
        byte[] raw = out.toByteArray();
        ShortBuffer pcm = MemoryUtil.memAllocShort(raw.length / 2);
        for (int i = 0; i + 1 < raw.length; i += 2) pcm.put((short) ((raw[i] & 0xFF) | (raw[i + 1] << 8)));
        pcm.flip();
        return new Decoded(pcm, ch, rate);
    }

    // ---------- WAV ----------
    private static Decoded decodeWav(Path file) throws IOException {
        byte[] raw = Files.readAllBytes(file);
        ByteBuffer bb = ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);
        if (raw.length < 12 || bb.getInt(0) != 0x46464952 || bb.getInt(8) != 0x45564157)
            throw new IOException("Not a valid WAV file");
        int pos = 12, fmtTag = 1, ch = 2, rate = 44100, bits = 16, dataOff = -1, dataLen = 0;
        while (pos + 8 <= raw.length) {
            int id = bb.getInt(pos), size = bb.getInt(pos + 4);
            int body = pos + 8;
            if (id == 0x20746d66) { // "fmt "
                fmtTag = bb.getShort(body) & 0xFFFF;
                ch = bb.getShort(body + 2);
                rate = bb.getInt(body + 4);
                bits = bb.getShort(body + 14);
                if (fmtTag == 0xFFFE && size >= 26) fmtTag = bb.getShort(body + 24) & 0xFFFF;
            } else if (id == 0x61746164) { // "data"
                dataOff = body;
                dataLen = (size < 0 || body + size > raw.length) ? raw.length - body : size;
                break;
            }
            pos = body + size + (size & 1);
        }
        if (dataOff < 0) throw new IOException("WAV has no audio data");
        if (fmtTag != 1 && fmtTag != 3) throw new IOException("Unsupported WAV encoding");
        return fromPcm(raw, dataOff, dataLen, bits, ch, rate, fmtTag == 3, true);
    }

    // ---------- FLAC ----------
    private static Decoded decodeFlac(Path file) throws Exception {
        final ByteArrayOutputStream out = new ByteArrayOutputStream(1 << 24);
        final int[] info = new int[3]; // bits, channels, rate
        try (InputStream is = new BufferedInputStream(Files.newInputStream(file))) {
            org.jflac.FLACDecoder dec = new org.jflac.FLACDecoder(is);
            dec.addPCMProcessor(new org.jflac.PCMProcessor() {
                public void processStreamInfo(org.jflac.metadata.StreamInfo si) {
                    info[0] = si.getBitsPerSample();
                    info[1] = si.getChannels();
                    info[2] = si.getSampleRate();
                }
                public void processPCM(org.jflac.util.ByteData pcm) {
                    out.write(pcm.getData(), 0, pcm.getLen());
                }
            });
            dec.decode();
        }
        byte[] raw = out.toByteArray();
        return fromPcm(raw, 0, raw.length, info[0], info[1], info[2], false, false);
    }

    // ---------- shared: any PCM -> 16-bit ----------
    private static Decoded fromPcm(byte[] raw, int off, int len, int bits, int ch, int rate,
                                   boolean isFloat, boolean unsigned8) throws IOException {
        if (ch < 1 || ch > 2) throw new IOException("Only mono/stereo supported (file has " + ch + " channels)");
        if (bits != 8 && bits != 16 && bits != 24 && bits != 32) throw new IOException("Unsupported bit depth: " + bits);
        int bytes = bits / 8;
        int n = len / bytes;
        ShortBuffer out = MemoryUtil.memAllocShort(n);
        ByteBuffer bb = ByteBuffer.wrap(raw, off, len).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < n; i++) {
            short v;
            switch (bits) {
                case 8: { int b = bb.get(); if (unsigned8) b = (b & 0xFF) - 128; v = (short) (b << 8); break; }
                case 16: v = bb.getShort(); break;
                case 24: { int b0 = bb.get() & 0xFF, b1 = bb.get() & 0xFF, b2 = bb.get(); v = (short) ((b2 << 8) | b1); break; }
                default:
                    if (isFloat) { float f = Math.max(-1f, Math.min(1f, bb.getFloat())); v = (short) (f * 32767f); }
                    else v = (short) (bb.getInt() >> 16);
            }
            out.put(v);
        }
        out.flip();
        return new Decoded(out, ch, rate);
    }
}
