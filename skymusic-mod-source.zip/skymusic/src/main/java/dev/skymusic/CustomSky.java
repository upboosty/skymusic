package dev.skymusic;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.world.World;
import org.joml.Matrix4f;

import java.io.*;
import java.nio.file.*;
import java.util.Properties;
import java.util.Random;

/**
 * Replaces the overworld sky with a cheap procedural one: smooth day/dusk/night gradient,
 * soft glowing sun and moon, animated light rays, twinkling stars. Only flat colored triangles, so it is potato-safe.
 */
public class CustomSky {
    private static final float R = 100f, TAU = (float) (Math.PI * 2);
    private static final float[] RINGS = {-1.5708f, -0.35f, -0.12f, -0.03f, 0f, 0.04f, 0.09f, 0.16f, 0.26f, 0.4f, 0.58f, 0.8f, 1.1f, 1.5708f};

    // palette (rgb)
    private static final float[] NZ = {0.008f, 0.012f, 0.045f}, NH = {0.03f, 0.05f, 0.13f};
    private static final float[] DZ = {0.16f, 0.40f, 0.88f}, DH = {0.74f, 0.86f, 1.0f};
    private static final float[] DUSK_Z = {0.30f, 0.28f, 0.62f}, DUSK_H = {1.0f, 0.55f, 0.30f};

    // stars (precomputed)
    private static final int MAX_STARS = 1700;
    private static final float[] SD = new float[MAX_STARS * 3], SU = new float[MAX_STARS * 3], SV = new float[MAX_STARS * 3];
    private static final float[] SSIZE = new float[MAX_STARS], SBR = new float[MAX_STARS], STINT = new float[MAX_STARS];

    static {
        Random r = new Random(1337);
        for (int i = 0; i < MAX_STARS; i++) {
            double y;
            do { y = r.nextDouble() * 2 - 1; } while (y < -0.12);
            double a = r.nextDouble() * Math.PI * 2, rr = Math.sqrt(1 - y * y);
            float[] d = {(float) (rr * Math.cos(a)), (float) y, (float) (rr * Math.sin(a))};
            float[] u = new float[3], v = new float[3];
            basis(d, u, v);
            System.arraycopy(d, 0, SD, i * 3, 3); System.arraycopy(u, 0, SU, i * 3, 3); System.arraycopy(v, 0, SV, i * 3, 3);
            float q = r.nextFloat();
            SSIZE[i] = 0.22f + q * q * q * 0.95f;
            SBR[i] = 0.4f + 0.6f * r.nextFloat();
            STINT[i] = r.nextFloat();
        }
    }

    // moon: brightness grid computed once (maria, craters, limb darkening), drawn as a disc of small gouraud triangles
    private static final int MRN = 22, MSN = 48;
    private static final float[] MOONC = new float[(MRN + 1) * (MSN + 1)];
    private static float h2(int x, int y) {
        int n = x * 374761393 + y * 668265263;
        n = (n ^ (n >> 13)) * 1274126177;
        n ^= n >> 16;
        return (n & 0xffff) / 65535f;
    }
    private static float vn(float x, float y) {
        int xi = (int) Math.floor(x), yi = (int) Math.floor(y);
        float fx = x - xi, fy = y - yi;
        fx = fx * fx * (3f - 2f * fx); fy = fy * fy * (3f - 2f * fy);
        float a = h2(xi, yi), b = h2(xi + 1, yi), c2 = h2(xi, yi + 1), d = h2(xi + 1, yi + 1);
        return (a + (b - a) * fx) * (1f - fy) + (c2 + (d - c2) * fx) * fy;
    }
    static {
        Random cr = new Random(42);
        int nc = 46;
        float[] ccx = new float[nc], ccy = new float[nc], ccr = new float[nc];
        for (int i = 0; i < nc; i++) {
            float ang = cr.nextFloat() * TAU, rad = (float) Math.sqrt(cr.nextFloat()) * 0.92f;
            ccx[i] = (float) Math.cos(ang) * rad; ccy[i] = (float) Math.sin(ang) * rad;
            float q = cr.nextFloat();
            ccr[i] = 0.025f + q * q * 0.13f;
        }
        for (int i = 0; i <= MRN; i++) {
            for (int j = 0; j <= MSN; j++) {
                float rho = (float) i / MRN, ang = TAU * j / MSN;
                float px = rho * (float) Math.cos(ang), py = rho * (float) Math.sin(ang);
                float mare = vn(px * 2.1f + 3.1f, py * 2.1f + 7.7f) * 0.65f + vn(px * 5.3f, py * 5.3f) * 0.25f;
                float b = 0.84f - 0.34f * Math.min(1f, Math.max(0f, mare - 0.40f) * 1.7f);
                for (int k = 0; k < nc; k++) {
                    float dd = (float) Math.hypot(px - ccx[k], py - ccy[k]);
                    if (dd < ccr[k]) b -= 0.11f * (1f - dd / ccr[k]);
                    else if (dd < ccr[k] * 1.25f) b += 0.10f * (1f - (dd - ccr[k]) / (ccr[k] * 0.25f));
                }
                b += (vn(px * 21f, py * 21f) - 0.5f) * 0.10f;
                b *= 0.70f + 0.30f * (float) Math.sqrt(Math.max(0f, 1f - rho * rho));
                MOONC[i * (MSN + 1) + j] = Math.max(0.12f, Math.min(1f, b));
            }
        }
    }
    private static void moonVtx(float[] d, float[] u, float[] v, int i, int j, float rad, float vis) {
        pt(d, u, v, TAU * j / MSN, rad * i / MRN);
        float b = MOONC[i * (MSN + 1) + j];
        vtx(P[0], P[1], P[2], b * 0.95f, b * 0.97f, b, 0.97f * vis);
    }

    // per-frame state
    private static float sx, sy, sz, mx, my, mz, h, dusk, rain, glowVis, moonVis;
    private static final float[] zen = new float[3], hor = new float[3], sunCol = new float[3], tmp = new float[3], P = new float[3];
    private static final float[] PX = new float[14 * 41 * 3], CC = new float[14 * 41 * 3];
    private static volatile float fogR, fogG, fogB, mist;
    private static volatile boolean fogActive = false;
    private static BufferBuilder curB;
    private static Matrix4f curM;

    public static void init() {
        boolean enabled = true;
        Path p = FabricLoader.getInstance().getConfigDir().resolve("skymusic-sky.properties");
        try {
            if (Files.exists(p)) {
                Properties pr = new Properties();
                try (InputStream in = Files.newInputStream(p)) { pr.load(in); }
                enabled = Boolean.parseBoolean(pr.getProperty("enabled", "true"));
            } else {
                Files.writeString(p, "# set enabled=false (then restart) to get the vanilla sky back\nenabled=true\n");
            }
        } catch (Exception ignored) {}
        if (enabled) DimensionRenderingRegistry.registerSkyRenderer(World.OVERWORLD, CustomSky::render);
    }

    // ---------- math helpers ----------
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    private static float sm(float a, float b, float x) {
        float t = Math.max(0f, Math.min(1f, (x - a) / (b - a)));
        return t * t * (3f - 2f * t);
    }
    private static float hash(int k, int salt) {
        double s = Math.sin(k * 12.9898 + salt * 78.233) * 43758.5453;
        return (float) (s - Math.floor(s));
    }
    private static void basis(float[] d, float[] u, float[] v) {
        // up x d, with up = (0,1,0) (or x axis near the poles)
        float ux = 0, uy = 1, uz = 0;
        if (Math.abs(d[1]) > 0.99f) { ux = 1; uy = 0; }
        float cx = uy * d[2] - uz * d[1], cy = uz * d[0] - ux * d[2], cz = ux * d[1] - uy * d[0];
        float l = (float) Math.sqrt(cx * cx + cy * cy + cz * cz);
        u[0] = cx / l; u[1] = cy / l; u[2] = cz / l;
        v[0] = d[1] * u[2] - d[2] * u[1]; v[1] = d[2] * u[0] - d[0] * u[2]; v[2] = d[0] * u[1] - d[1] * u[0];
    }

    private static void vtx(float x, float y, float z, float r, float g, float b, float a) {
        curB.vertex(curM, x, y, z).color(r, g, b, a).next();
    }
    /** point on the sky sphere, offset from dir d by `rad` in direction `ang` of the tangent plane */
    private static void pt(float[] d, float[] u, float[] v, float ang, float rad) {
        float c = (float) Math.cos(ang), s = (float) Math.sin(ang);
        float x = d[0] * R + (u[0] * c + v[0] * s) * rad;
        float y = d[1] * R + (u[1] * c + v[1] * s) * rad;
        float z = d[2] * R + (u[2] * c + v[2] * s) * rad;
        float k = R / (float) Math.sqrt(x * x + y * y + z * z);
        P[0] = x * k; P[1] = y * k; P[2] = z * k;
    }
    private static void fan(float[] d, float[] u, float[] v, float rad, int n, float[] c0, float a0, float[] c1, float a1) {
        float cx = d[0] * R, cy = d[1] * R, cz = d[2] * R;
        for (int i = 0; i < n; i++) {
            vtx(cx, cy, cz, c0[0], c0[1], c0[2], a0);
            pt(d, u, v, TAU * i / n, rad);       vtx(P[0], P[1], P[2], c1[0], c1[1], c1[2], a1);
            pt(d, u, v, TAU * (i + 1) / n, rad); vtx(P[0], P[1], P[2], c1[0], c1[1], c1[2], a1);
        }
    }
    private static void ray(float[] d, float[] u, float[] v, float ang, float hw, float len, float[] c, float a) {
        vtx(d[0] * R, d[1] * R, d[2] * R, c[0], c[1], c[2], a);
        float cs1 = (float) Math.cos(ang - hw), sn1 = (float) Math.sin(ang - hw);
        float cs2 = (float) Math.cos(ang + hw), sn2 = (float) Math.sin(ang + hw);
        tipPoint(d, u, v, cs1, sn1, len); vtx(P[0], P[1], P[2], c[0], c[1], c[2], 0f);
        tipPoint(d, u, v, cs2, sn2, len); vtx(P[0], P[1], P[2], c[0], c[1], c[2], 0f);
    }
    private static void tipPoint(float[] d, float[] u, float[] v, float c, float s, float rad) {
        float x = d[0] * R + (u[0] * c + v[0] * s) * rad;
        float y = d[1] * R + (u[1] * c + v[1] * s) * rad;
        float z = d[2] * R + (u[2] * c + v[2] * s) * rad;
        float k = R / (float) Math.sqrt(x * x + y * y + z * z);
        P[0] = x * k; P[1] = y * k; P[2] = z * k;
    }

    // ---------- sky color for a direction ----------
    private static void skyColor(float dx, float dy, float dz) {
        float g = dy > 0 ? (float) Math.sqrt(dy) : 0f;
        float r = lerp(hor[0], zen[0], g), gg = lerp(hor[1], zen[1], g), bl = lerp(hor[2], zen[2], g);
        if (dy < 0) { float k = 1f - 0.45f * Math.min(1f, -dy * 5f); r *= k; gg *= k; bl *= k; }

        float sd = dx * sx + dy * sy + dz * sz;
        if (sd > 0f) {
            float s2 = sd * sd, s4 = s2 * s2, s8 = s4 * s4, s16 = s8 * s8;
            float add = (s8 * 0.30f + s16 * s16 * s16 * 0.55f) * glowVis;
            r += sunCol[0] * add; gg += sunCol[1] * add; bl += sunCol[2] * add;
        }
        float band = (float) Math.exp(-dy * dy * 30f);
        float sdp = Math.max(sd, 0f);
        float bd = band * dusk * (0.25f + 0.75f * sdp * sdp) * 0.55f * (1f - rain);
        r += DUSK_H[0] * bd; gg += DUSK_H[1] * bd; bl += DUSK_H[2] * bd;

        float md = dx * mx + dy * my + dz * mz;
        if (md > 0f) {
            float m2 = md * md, m4 = m2 * m2, m8 = m4 * m4, m16 = m8 * m8, m32 = m16 * m16;
            float add = m32 * 0.22f * moonVis * (1f - rain);
            r += 0.5f * add; gg += 0.62f * add; bl += add;
        }
        tmp[0] = Math.min(1f, r); tmp[1] = Math.min(1f, gg); tmp[2] = Math.min(1f, bl);
    }

    // ---------- fog ----------
    /** called from BackgroundRendererMixin after vanilla configured fog */
    public static void applyFog() {
        if (!fogActive) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || mc.world.getRegistryKey() != World.OVERWORLD) return;
        if (mc.gameRenderer.getCamera().getSubmersionType() != CameraSubmersionType.NONE) return;
        if (mc.player.hasStatusEffect(StatusEffects.BLINDNESS) || mc.player.hasStatusEffect(StatusEffects.DARKNESS)) return;
        RenderSystem.setShaderFogColor(fogR, fogG, fogB);
        float start = RenderSystem.getShaderFogStart(), end = RenderSystem.getShaderFogEnd();
        if (end > 64f && mist > 0f) RenderSystem.setShaderFogStart(start * (1f - 0.4f * mist));   // morning/evening/rain mist
    }

    // ---------- aurora: tall streaked curtains ----------
    private static void drawAurora(float t, float vis, int q) {
        int ribbons = q == 1 ? 3 : 5, cols = q == 1 ? 60 : 100;
        float[][] pp = new float[3][3], cp = new float[3][3];
        float[] pa = new float[3], ca = new float[3];
        for (int r = 0; r < ribbons; r++) {
            float presence = 0.7f + 0.3f * (float) Math.sin(t * 0.03f + r * 2.1f);
            float a0 = hash(r, 11) * TAU + 0.25f * (float) Math.sin(t * 0.01f + r);
            float span = 2.3f + hash(r, 12) * 1.6f;
            float baseE = 0.10f + 0.10f * hash(r, 13);
            float hMul = 0.60f + 0.40f * hash(r, 14);
            float tealShift = 0.25f * hash(r, 15);
            for (int j = 0; j <= cols; j++) {
                float f = (float) j / cols;
                float a = a0 + span * (f - 0.5f) + 0.12f * (float) Math.sin(t * 0.05f + r + f * 4f);
                float edge = (float) Math.pow(Math.sin(Math.PI * f), 0.7);
                float s1 = 0.5f + 0.5f * (float) Math.sin(a * 46f + t * 0.9f + r * 5f);
                float s2 = 0.5f + 0.5f * (float) Math.sin(a * 19f - t * 0.6f + r * 2f);
                float s = s1 * 0.6f + s2 * 0.4f;
                s *= s;                                                      // sharper streaks
                float eb = baseE + 0.07f * (float) Math.sin(a * 3f + t * 0.35f + r) + 0.04f * (float) Math.sin(a * 8f - t * 0.5f);
                float hgt = hMul * (0.25f + 0.75f * s) * (0.75f + 0.25f * (float) Math.sin(a * 5f - t * 0.4f + r * 2f));
                float al = vis * presence * edge * (0.25f + 0.75f * s) * 0.80f;
                float[] es = {eb, eb + hgt * 0.40f, eb + hgt};
                for (int k = 0; k < 3; k++) {
                    float ce = (float) Math.cos(es[k]);
                    cp[k][0] = ce * (float) Math.cos(a) * R; cp[k][1] = (float) Math.sin(es[k]) * R; cp[k][2] = ce * (float) Math.sin(a) * R;
                }
                ca[0] = al; ca[1] = al * 0.55f; ca[2] = 0f;
                if (j > 0) {
                    for (int k = 0; k < 2; k++) {
                        float[] c0 = auroraCol(k, tealShift), c1 = auroraCol(k + 1, tealShift);
                        vtx(pp[k][0], pp[k][1], pp[k][2], c0[0], c0[1], c0[2], pa[k]);
                        vtx(pp[k + 1][0], pp[k + 1][1], pp[k + 1][2], c1[0], c1[1], c1[2], pa[k + 1]);
                        vtx(cp[k][0], cp[k][1], cp[k][2], c0[0], c0[1], c0[2], ca[k]);
                        vtx(cp[k][0], cp[k][1], cp[k][2], c0[0], c0[1], c0[2], ca[k]);
                        vtx(pp[k + 1][0], pp[k + 1][1], pp[k + 1][2], c1[0], c1[1], c1[2], pa[k + 1]);
                        vtx(cp[k + 1][0], cp[k + 1][1], cp[k + 1][2], c1[0], c1[1], c1[2], ca[k + 1]);
                    }
                }
                for (int k = 0; k < 3; k++) { pp[k][0] = cp[k][0]; pp[k][1] = cp[k][1]; pp[k][2] = cp[k][2]; pa[k] = ca[k]; }
            }
        }
    }
    /** row 0 = bright green base, 1 = green-teal middle, 2 = violet fringe on top */
    private static float[] auroraCol(int row, float teal) {
        if (row == 0) return new float[]{0.20f, 1.0f, 0.45f + teal};
        if (row == 1) return new float[]{0.10f, 0.80f, 0.55f + teal};
        return new float[]{0.45f, 0.30f, 1.0f};
    }

    // ---------- shooting star ----------
    private static void drawShootingStar(float t, float vis) {
        final float PERIOD = 6.5f, LIFE = 0.9f;
        if (vis < 0.3f) return;
        int slot = (int) Math.floor(t / PERIOD);
        float local = t - slot * PERIOD;
        if (local > LIFE || hash(slot, 21) < 0.35f) return;          // not every slot has a shooting star
        float e = 0.35f + 0.9f * hash(slot, 22), a = hash(slot, 23) * TAU, phi = hash(slot, 24) * TAU;
        float[] d = {(float) (Math.cos(e) * Math.cos(a)), (float) Math.sin(e), (float) (Math.cos(e) * Math.sin(a))};
        float[] u = new float[3], v = new float[3];
        basis(d, u, v);
        float prog = local / LIFE;
        float headOff = prog * 70f, tailLen = 26f * Math.min(1f, local * 5f);
        float fade = (float) Math.sin(Math.PI * prog) * vis;
        float cp = (float) Math.cos(phi), sp = (float) Math.sin(phi);
        tipPoint(d, u, v, cp, sp, headOff);
        float hx = P[0], hy = P[1], hz = P[2];
        tipPoint(d, u, v, cp, sp, headOff - tailLen);
        float px = (u[0] * -sp + v[0] * cp) * 0.6f, py = (u[1] * -sp + v[1] * cp) * 0.6f, pz = (u[2] * -sp + v[2] * cp) * 0.6f;
        vtx(hx, hy, hz, 1f, 1f, 1f, 0.95f * fade);
        vtx(P[0] + px, P[1] + py, P[2] + pz, 0.7f, 0.85f, 1f, 0f);
        vtx(P[0] - px, P[1] - py, P[2] - pz, 0.7f, 0.85f, 1f, 0f);
    }

    // ---------- main render ----------
    public static void render(WorldRenderContext ctx) {
        ClientWorld w = ctx.world();
        if (w == null) return;
        CameraSubmersionType st = ctx.camera().getSubmersionType();
        if (st == CameraSubmersionType.LAVA || st == CameraSubmersionType.POWDER_SNOW) return;

        float td = ctx.tickDelta();
        int q = Math.max(1, Math.min(2, Perf.skyQuality));
        float ang = w.getSkyAngle(td) * TAU;
        sx = -(float) Math.sin(ang); sy = (float) Math.cos(ang); sz = 0f;
        mx = -sx; my = -sy; mz = 0f;
        h = sy;
        rain = w.getRainGradient(td);
        float thunder = w.getThunderGradient(td);
        float t = (w.getTime() + td) / 20f;

        float day = sm(-0.10f, 0.30f, h);
        dusk = Math.max(0f, Math.min(1f, 1f - Math.abs(h - 0.02f) / 0.28f));
        dusk = dusk * dusk * (3f - 2f * dusk);
        glowVis = sm(-0.25f, 0.05f, h) * (1f - rain * 0.85f);
        moonVis = sm(0.15f, -0.10f, h);

        for (int i = 0; i < 3; i++) {
            zen[i] = lerp(NZ[i], DZ[i], day); hor[i] = lerp(NH[i], DH[i], day);
            zen[i] += (DUSK_Z[i] - zen[i]) * dusk * 0.55f;
            hor[i] += (DUSK_H[i] - hor[i]) * dusk * 0.75f;
        }
        float rm = Math.min(1f, rain * 0.75f + thunder * 0.15f), dark = 1f - 0.35f * rain - 0.2f * thunder;
        float lz = 0.3f * zen[0] + 0.59f * zen[1] + 0.11f * zen[2], lh = 0.3f * hor[0] + 0.59f * hor[1] + 0.11f * hor[2];
        for (int i = 0; i < 3; i++) {
            zen[i] = lerp(zen[i], lz * 0.85f, rm) * dark;
            hor[i] = lerp(hor[i], lh * 0.9f, rm) * dark;
        }
        float warmT = sm(0f, 0.45f, h);
        sunCol[0] = 1f; sunCol[1] = lerp(0.55f, 0.97f, warmT); sunCol[2] = lerp(0.25f, 0.86f, warmT);

        // fog color = sky color at the horizon in the direction you are facing
        float yawR = (float) Math.toRadians(ctx.camera().getYaw());
        skyColor(-(float) Math.sin(yawR), 0.03f, (float) Math.cos(yawR));
        fogR = tmp[0]; fogG = tmp[1]; fogB = tmp[2];
        mist = Math.max(dusk * 0.6f, rain * 0.5f);
        fogActive = true;

        Matrix4f mat = ctx.matrixStack().peek().getPositionMatrix();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();

        // ---- 1) opaque gradient dome ----
        RenderSystem.disableBlend();
        int segs = q == 0 ? 20 : q == 1 ? 28 : 40;
        int rn = RINGS.length, sn = segs + 1;
        for (int i = 0; i < rn; i++) {
            float ce = (float) Math.cos(RINGS[i]), se = (float) Math.sin(RINGS[i]);
            for (int j = 0; j < sn; j++) {
                float a = TAU * j / segs;
                float dx = ce * (float) Math.cos(a), dz = ce * (float) Math.sin(a);
                int k = (i * sn + j) * 3;
                PX[k] = dx * R; PX[k + 1] = se * R; PX[k + 2] = dz * R;
                skyColor(dx, se, dz);
                CC[k] = tmp[0]; CC[k + 1] = tmp[1]; CC[k + 2] = tmp[2];
            }
        }
        curB = Tessellator.getInstance().getBuffer();
        curM = mat;
        curB.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < rn - 1; i++) {
            for (int j = 0; j < segs; j++) {
                int a = (i * sn + j) * 3, b = a + 3, c = a + sn * 3, d = c + 3;
                vtx(PX[a], PX[a + 1], PX[a + 2], CC[a], CC[a + 1], CC[a + 2], 1f);
                vtx(PX[c], PX[c + 1], PX[c + 2], CC[c], CC[c + 1], CC[c + 2], 1f);
                vtx(PX[b], PX[b + 1], PX[b + 2], CC[b], CC[b + 1], CC[b + 2], 1f);
                vtx(PX[b], PX[b + 1], PX[b + 2], CC[b], CC[b + 1], CC[b + 2], 1f);
                vtx(PX[c], PX[c + 1], PX[c + 2], CC[c], CC[c + 1], CC[c + 2], 1f);
                vtx(PX[d], PX[d + 1], PX[d + 2], CC[d], CC[d + 1], CC[d + 2], 1f);
            }
        }
        BufferRenderer.drawWithGlobalProgram(curB.end());

        // ---- 2) additive layer: sun, rays, moon, stars ----
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        curB.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);

        int gn = q == 0 ? 12 : q == 1 ? 16 : 24;
        float[] white = {1f, 0.98f, 0.9f};

        if (h > -0.25f) {
            float[] d = {sx, sy, sz}, u = new float[3], v = new float[3];
            basis(d, u, v);
            float vis = sm(-0.25f, 0.0f, h) * (1f - rain * 0.7f);
            fan(d, u, v, 75f, gn, sunCol, 0.30f * vis, sunCol, 0f);         // big soft glow
            fan(d, u, v, 24f, gn, sunCol, 0.55f * vis, sunCol, 0f);         // inner glow

            float rayVis = sm(-0.14f, 0.22f, h) * (1f - rain) * (0.7f + 0.5f * dusk);
            if (rayVis > 0.01f) {
                int n = q == 0 ? 6 : q == 1 ? 10 : 16;
                for (int k = 0; k < n; k++) {
                    float a = TAU * k / n + t * 0.015f + hash(k, 1) * 0.4f;
                    float hw = 0.035f + 0.05f * hash(k, 2);
                    float len = 80f + 150f * hash(k, 3);
                    float pulse = 0.65f + 0.35f * (float) Math.sin(t * 0.7f + k * 1.7f);
                    ray(d, u, v, a, hw, len, sunCol, 0.30f * pulse * rayVis);
                }
                if (q >= 1) {
                    int n2 = q == 1 ? 6 : 10;
                    for (int k = 0; k < n2; k++) {
                        float a = TAU * k / n2 - t * 0.01f + hash(k, 4);
                        float pulse = 0.7f + 0.3f * (float) Math.sin(t * 0.4f + k * 2.3f);
                        ray(d, u, v, a, 0.14f + 0.12f * hash(k, 5), 190f, sunCol, 0.11f * pulse * rayVis);
                    }
                }
            }
            fan(d, u, v, 9.5f, gn, sunCol, 0.9f * vis, sunCol, 0f);         // warm rim
            fan(d, u, v, 6.2f, gn, white, 1.0f * vis, white, 0.95f * vis);  // bright core
        }

        if (h < 0.3f && moonVis > 0.01f) {
            float[] d = {mx, my, mz}, u = new float[3], v = new float[3];
            basis(d, u, v);
            float[] mg = {0.45f, 0.58f, 1.0f}, mh = {0.75f, 0.85f, 1.0f};
            float vis = moonVis * (1f - rain * 0.8f);
            fan(d, u, v, 55f, gn, mg, 0.16f * vis, mg, 0f);                 // wide cold corona
            fan(d, u, v, 22f, gn, mh, 0.22f * vis, mh, 0f);                 // inner halo
            for (int i = 0; i < MRN; i++) {
                for (int j = 0; j < MSN; j++) {
                    moonVtx(d, u, v, i, j, 7.6f, vis);
                    moonVtx(d, u, v, i + 1, j, 7.6f, vis);
                    moonVtx(d, u, v, i, j + 1, 7.6f, vis);
                    moonVtx(d, u, v, i, j + 1, 7.6f, vis);
                    moonVtx(d, u, v, i + 1, j, 7.6f, vis);
                    moonVtx(d, u, v, i + 1, j + 1, 7.6f, vis);
                }
            }
        }

        float starVis = sm(0.05f, -0.2f, h) * (1f - rain * 0.9f);
        if (starVis > 0.01f) {
            MatrixStack ms = ctx.matrixStack();
            ms.push();
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-90f));
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(ang * 57.29578f));
            curM = ms.peek().getPositionMatrix();
            int n = q <= 1 ? 850 : 1700;
            for (int i = 0; i < n; i++) {
                float a = starVis * SBR[i] * (0.7f + 0.3f * (float) Math.sin(t * (1.2f + SBR[i]) + i * 3.7f));
                if (a < 0.02f) continue;
                float cr = lerp(0.75f, 1.0f, STINT[i]), cg = lerp(0.85f, 0.92f, STINT[i]), cb = lerp(1.0f, 0.75f, STINT[i]);
                int k = i * 3;
                float s = SSIZE[i];
                float cx = SD[k] * R, cy = SD[k + 1] * R, cz = SD[k + 2] * R;
                float ux = SU[k] * s, uy = SU[k + 1] * s, uz = SU[k + 2] * s, vx = SV[k] * s, vy = SV[k + 1] * s, vz = SV[k + 2] * s;
                vtx(cx - ux - vx, cy - uy - vy, cz - uz - vz, cr, cg, cb, a);
                vtx(cx + ux - vx, cy + uy - vy, cz + uz - vz, cr, cg, cb, a);
                vtx(cx + ux + vx, cy + uy + vy, cz + uz + vz, cr, cg, cb, a);
                vtx(cx - ux - vx, cy - uy - vy, cz - uz - vz, cr, cg, cb, a);
                vtx(cx + ux + vx, cy + uy + vy, cz + uz + vz, cr, cg, cb, a);
                vtx(cx - ux + vx, cy - uy + vy, cz - uz + vz, cr, cg, cb, a);
            }
            ms.pop();
            curM = mat;
        }
        if (q >= 1 && starVis > 0.05f) {
            drawAurora(t, starVis, q);
            drawShootingStar(t, starVis);
        }
        BufferRenderer.drawWithGlobalProgram(curB.end());

        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
    }
}
