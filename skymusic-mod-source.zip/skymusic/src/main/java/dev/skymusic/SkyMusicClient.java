package dev.skymusic;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.sound.SoundCategory;
import net.minecraft.text.Text;

import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class SkyMusicClient implements ClientModInitializer {
    public static final AudioPlayer PLAYER = new AudioPlayer();
    public static volatile Lrc lyrics = null;
    public static volatile String title = "";
    private static Path dir;
    private static boolean ducked = false;
    private static double savedMusic = 1.0;

    @Override
    public void onInitializeClient() {
        dir = FabricLoader.getInstance().getGameDir().resolve("skymusic");
        try { Files.createDirectories(dir); } catch (Exception ignored) {}

        WorldRenderEvents.LAST.register(SkyRenderer::render);
        Perf.init();
        CustomSky.init();
        PostFx.init();

        ClientTickEvents.END_CLIENT_TICK.register(SkyMusicClient::tick);
        // leaving the world / quitting must stop our music and give the game music slider back
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> client.execute(SkyMusicClient::stopAll));
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> stopAll());

        ClientCommandRegistrationCallback.EVENT.register((d, reg) -> d.register(
            ClientCommandManager.literal("sky")
                .then(ClientCommandManager.literal("play")
                    .then(ClientCommandManager.argument("song", StringArgumentType.greedyString())
                        .suggests((c, b) -> { songs().forEach(p -> b.suggest(stem(p))); return b.buildFuture(); })
                        .executes(c -> { play(StringArgumentType.getString(c, "song")); return 1; })))
                .then(ClientCommandManager.literal("stop").executes(c -> { stopAll(); msg("Stopped"); return 1; }))
                .then(ClientCommandManager.literal("pause").executes(c -> { PLAYER.pause(); msg("Paused"); return 1; }))
                .then(ClientCommandManager.literal("resume").executes(c -> { PLAYER.resume(); msg("Resumed"); return 1; }))
                .then(ClientCommandManager.literal("volume")
                    .then(ClientCommandManager.argument("percent", FloatArgumentType.floatArg(0, 100))
                        .executes(c -> { PLAYER.setVolume(FloatArgumentType.getFloat(c, "percent") / 100f); msg("Volume set"); return 1; })))
                .then(ClientCommandManager.literal("sync")
                    .then(ClientCommandManager.argument("seconds", FloatArgumentType.floatArg(-30, 30))
                        .executes(c -> { AudioPlayer.syncOffset = FloatArgumentType.getFloat(c, "seconds"); msg("Lyric sync: " + AudioPlayer.syncOffset + "s (positive = lyrics earlier)"); return 1; })))
                .then(ClientCommandManager.literal("debug").executes(c -> {
                    Lrc l = lyrics; double t = PLAYER.getTime();
                    msg("time=" + String.format("%.2f", t) + " lines=" + (l == null ? "none" : l.lines.size())
                        + " idx=" + (l == null ? -1 : l.indexAt(t)) + " sync=" + AudioPlayer.syncOffset);
                    return 1; }))
                .then(ClientCommandManager.literal("font")
                    .then(ClientCommandManager.literal("on").executes(c -> { SkyRenderer.customFont = true; msg("Custom lyric font on"); return 1; }))
                    .then(ClientCommandManager.literal("off").executes(c -> { SkyRenderer.customFont = false; msg("Custom lyric font off (vanilla font)"); return 1; })))
                .then(ClientCommandManager.literal("list").executes(c -> {
                    List<Path> s = songs();
                    if (s.isEmpty()) msg("No songs. Put .mp3/.ogg/.wav/.flac (+ .lrc) in: " + dir);
                    else s.forEach(p -> msg("- " + stem(p)));
                    return 1; }))
                .then(Perf.node())
                .then(PostFx.node())
                .then(ClientCommandManager.literal("folder").executes(c -> { msg(dir.toString()); return 1; }))
        ));
    }

    /** Runs every client tick: mutes the game's own music while ours plays, follows the master volume, cleans up. */
    private static void tick(MinecraftClient mc) {
        if (mc.options == null) return;
        PLAYER.getTime();   // also detects the end of a song
        boolean want = PLAYER.isActive() || PLAYER.isLoading();
        SimpleOption<Double> music = mc.options.getSoundVolumeOption(SoundCategory.MUSIC);
        if (want && !ducked) {
            savedMusic = music.getValue();
            ducked = true;
            music.setValue(0.0);
            mc.getSoundManager().stopSounds(null, SoundCategory.MUSIC);
        } else if (!want && ducked) {
            music.setValue(savedMusic);
            ducked = false;
        }
        if (!want) lyrics = null;
        PLAYER.setMaster(mc.options.getSoundVolume(SoundCategory.MASTER));
    }

    private static void stopAll() {
        PLAYER.stop();
        lyrics = null;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (ducked && mc.options != null) {
            mc.options.getSoundVolumeOption(SoundCategory.MUSIC).setValue(savedMusic);
        }
        ducked = false;
    }

    private static void play(String query) {
        Path found = songs().stream()
            .filter(p -> stem(p).equalsIgnoreCase(query)).findFirst()
            .orElseGet(() -> songs().stream().filter(p -> stem(p).toLowerCase().contains(query.toLowerCase())).findFirst().orElse(null));
        if (found == null) { msg("Song not found. Use /sky list"); return; }

        title = stem(found);
        Path lrcFile = findLrc(found);
        Lrc parsed = lrcFile == null ? null : Lrc.load(lrcFile);
        String note;
        if (lrcFile == null) { parsed = null; note = " (no .lrc found, no lyrics)"; }
        else if (parsed.lines.isEmpty()) { parsed = null; note = " (" + lrcFile.getFileName() + " has no [mm:ss.xx] timestamps)"; }
        else note = " (" + parsed.lines.size() + " lyric lines)";
        lyrics = parsed;
        final String n = note;
        msg("Loading " + stem(found) + "...");
        PLAYER.play(found, () -> {
            Lrc l = lyrics;
            String extra = "";
            if (l != null && l.unsynced()) { l.spread(PLAYER.duration); extra = " [lyrics had no timing, spread evenly over the song; use /sky sync to nudge]"; }
            msg("Playing " + stem(found) + n + extra);
        }, err -> msg("Error: " + err));
    }

    /** exact name first, then a forgiving match (ignores case, spaces, punctuation). */
    private static Path findLrc(Path audio) {
        Path exact = dir.resolve(stem(audio) + ".lrc");
        if (Files.exists(exact)) return exact;
        String want = norm(stem(audio));
        try (Stream<Path> s = Files.list(dir)) {
            List<Path> all = s.filter(p -> p.getFileName().toString().toLowerCase().endsWith(".lrc")).toList();
            for (Path p : all) if (norm(stem(p)).equals(want)) return p;
            for (Path p : all) { String x = norm(stem(p)); if (!x.isEmpty() && (x.contains(want) || want.contains(x))) return p; }
        } catch (Exception ignored) {}
        return null;
    }

    private static String norm(String s) { return s.toLowerCase().replaceAll("[^\\p{L}\\p{Nd}]", ""); }

    private static List<Path> songs() {
        try (Stream<Path> s = Files.list(dir)) {
            return s.filter(p -> { String n = p.getFileName().toString().toLowerCase();
                        return n.endsWith(".mp3") || n.endsWith(".ogg") || n.endsWith(".wav") || n.endsWith(".flac"); })
                    .sorted().collect(Collectors.toList());
        } catch (Exception e) { return List.of(); }
    }

    private static String stem(Path p) {
        String n = p.getFileName().toString();
        int i = n.lastIndexOf('.');
        return i < 0 ? n : n.substring(0, i);
    }

    static void msg(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> { if (mc.player != null) mc.player.sendMessage(Text.literal("[Sky] " + s), false); });
    }
}
