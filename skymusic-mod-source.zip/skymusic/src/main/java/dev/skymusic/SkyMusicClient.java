package dev.skymusic;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.nio.file.*;
import java.util.*;
import java.util.stream.*;

public class SkyMusicClient implements ClientModInitializer {
    public static final AudioPlayer PLAYER = new AudioPlayer();
    public static volatile Lrc lyrics = null;
    private static Path dir;

    @Override
    public void onInitializeClient() {
        dir = FabricLoader.getInstance().getGameDir().resolve("skymusic");
        try { Files.createDirectories(dir); } catch (Exception ignored) {}

        WorldRenderEvents.LAST.register(SkyRenderer::render);
        Perf.init();
        CustomSky.init();
        PostFx.init();

        ClientCommandRegistrationCallback.EVENT.register((d, reg) -> d.register(
            ClientCommandManager.literal("sky")
                .then(ClientCommandManager.literal("play")
                    .then(ClientCommandManager.argument("song", StringArgumentType.greedyString())
                        .suggests((c, b) -> { songs().forEach(p -> b.suggest(stem(p))); return b.buildFuture(); })
                        .executes(c -> { play(StringArgumentType.getString(c, "song")); return 1; })))
                .then(ClientCommandManager.literal("stop").executes(c -> { PLAYER.stop(); lyrics = null; msg("Stopped"); return 1; }))
                .then(ClientCommandManager.literal("pause").executes(c -> { PLAYER.pause(); msg("Paused"); return 1; }))
                .then(ClientCommandManager.literal("resume").executes(c -> { PLAYER.resume(); msg("Resumed"); return 1; }))
                .then(ClientCommandManager.literal("volume")
                    .then(ClientCommandManager.argument("percent", FloatArgumentType.floatArg(0, 100))
                        .executes(c -> { PLAYER.setVolume(FloatArgumentType.getFloat(c, "percent") / 100f); msg("Volume set"); return 1; })))
                .then(ClientCommandManager.literal("list").executes(c -> {
                    List<Path> s = songs();
                    if (s.isEmpty()) msg("No songs. Put .mp3/.ogg/.wav/.flac (+ .lrc) in: " + dir);
                    else s.forEach(p -> msg("- " + stem(p)));
                    return 1; }))
                .then(Perf.node())
                .then(PostFx.node())
                .then(ClientCommandManager.literal("folder").executes(c -> { msg(dir.toString()); return 1; }))
        ));
    }

    private static void play(String query) {
        Path found = songs().stream()
            .filter(p -> stem(p).equalsIgnoreCase(query)).findFirst()
            .orElseGet(() -> songs().stream().filter(p -> stem(p).toLowerCase().contains(query.toLowerCase())).findFirst().orElse(null));
        if (found == null) { msg("Song not found. Use /sky list"); return; }
        Path lrc = dir.resolve(stem(found) + ".lrc");
        lyrics = Files.exists(lrc) ? Lrc.load(lrc) : null;
        msg("Loading " + stem(found) + "...");
        PLAYER.play(found,
            () -> msg("Playing " + stem(found) + (lyrics == null ? " (no .lrc found, no lyrics)" : "")),
            err -> msg("Error: " + err));
    }

    private static List<Path> songs() {
        try (Stream<Path> s = Files.list(dir)) {
            return s.filter(p -> { String n = p.getFileName().toString().toLowerCase(); return n.endsWith(".mp3") || n.endsWith(".ogg") || n.endsWith(".wav") || n.endsWith(".flac"); })
                    .sorted().collect(Collectors.toList());
        } catch (Exception e) { return List.of(); }
    }

    private static String stem(Path p) {
        String n = p.getFileName().toString();
        return n.substring(0, n.lastIndexOf('.'));
    }

    static void msg(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> { if (mc.player != null) mc.player.sendMessage(Text.literal("[Sky] " + s), false); });
    }
}
