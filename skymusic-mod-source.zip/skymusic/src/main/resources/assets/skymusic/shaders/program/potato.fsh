#version 150
// Sky Music "potato" post effect: depth-masked sun rays + vibrance + soft curve + vignette.

#define RAY_SAMPLES 10
#define RAY_STRENGTH 0.55
#define RAY_DENSITY 0.9
#define RAY_DECAY 0.93
#define VIBRANCE 1.18
#define VIGNETTE 0.55

uniform sampler2D DiffuseSampler;
uniform sampler2D DepthSampler;

uniform float SunU;
uniform float SunV;
uniform float RayVis;
uniform float Warm;
uniform float Aspect;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec3 c = texture(DiffuseSampler, texCoord).rgb;

    if (RayVis > 0.001) {
        vec2 sunUV = vec2(SunU, SunV);
        vec2 delta = (sunUV - texCoord) * (RAY_DENSITY / float(RAY_SAMPLES));
        vec2 p = texCoord;
        float decay = 1.0;
        float acc = 0.0;
        for (int i = 0; i < RAY_SAMPLES; i++) {
            p += delta;
            float sky = step(0.99999, texture(DepthSampler, clamp(p, 0.001, 0.999)).r);
            acc += sky * decay;
            decay *= RAY_DECAY;
        }
        acc /= float(RAY_SAMPLES);

        vec2 dd = sunUV - texCoord;
        dd.x *= Aspect;
        float fall = clamp(1.0 - length(dd) * 0.85, 0.0, 1.0);
        fall *= fall;

        vec3 rayColor = mix(vec3(1.0, 0.93, 0.78), vec3(1.0, 0.55, 0.28), Warm);
        c += rayColor * acc * fall * RayVis * RAY_STRENGTH;
    }

    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(l), c, VIBRANCE);
    c *= vec3(1.03, 1.0, 0.96);
    c = mix(c, smoothstep(0.0, 1.0, c), 0.35);

    vec2 q = texCoord - 0.5;
    c *= 1.0 - dot(q, q) * VIGNETTE;

    fragColor = vec4(c, 1.0);
}
