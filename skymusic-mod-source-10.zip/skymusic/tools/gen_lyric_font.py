#!/usr/bin/env python3
"""
Bakes the lyric font atlas used by SkyRenderer (one texture, one draw call for all lyric glyphs).
Output:
  src/main/resources/assets/skymusic/textures/font/lyrics_atlas.png (+ .mcmeta)
  src/main/resources/assets/skymusic/font/lyrics_atlas.txt        (glyph metrics)
Needs: Pillow, fontTools.   Run:  python3 tools/gen_lyric_font.py
Each glyph is stored 3 times: sharp (full res), soft (1/2 res, light blur: "out of focus" lines),
glow (1/4 res, big blur: halo + soft shadow).
Swap the look: change MAIN_FONT / EMBOLDEN below (any OFL .ttf, e.g. Inter ExtraBold for a very SF-like look).
"""
import os, sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from fontTools.ttLib import TTFont

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
MAIN_FONT = os.path.join(HERE, "fonts", "outfit-bold.ttf")
FALLBACK_FONT = os.path.join(HERE, "fonts", "dejavu-bold.ttf")   # notes, hearts, stars ...
S = 84              # em size in texels (sharp)
EMBOLDEN = 2        # extra stroke in texels: Bold -> ExtraBold
TRACK = 3.0         # extra letter spacing in texels (on top of the font advance + stroke)
SOFT_K, SOFT_SIGMA, SOFT_PAD = 2, 3.0, 10      # variant scale divisor, blur sigma (full-res texels), padding
GLOW_K, GLOW_SIGMA, GLOW_PAD = 4, 13.0, 40
ATLAS_W = 2048

chars = [chr(c) for c in range(32, 127)] + [chr(c) for c in range(161, 256) if c != 173]
chars += list("\u0141\u0142\u0152\u0153\u0160\u0161\u0178\u017d\u017e\u011e\u011f\u0130\u0131\u015e\u015f\u0106\u0107\u010c\u010d\u0118\u0119\u0105\u0104\u0144\u0143\u015a\u015b\u0179\u017a\u017b\u017c\u0158\u0159\u011b\u011a\u016f\u016e\u0102\u0103\u0218\u0219\u021a\u021b")
chars += list("\u2018\u2019\u201a\u201c\u201d\u201e\u2026\u2013\u2014\u2022\u2032\u2033\u20ac\u2122\u2190\u2192\u2191\u2193\u266a\u266b\u2665\u2605\u2606")

def cmap(path):
    return set(TTFont(path, fontNumber=0).getBestCmap().keys())
main_cmap, fb_cmap = cmap(MAIN_FONT), cmap(FALLBACK_FONT)
main_font = ImageFont.truetype(MAIN_FONT, S)
fb_font = ImageFont.truetype(FALLBACK_FONT, int(S * 0.92))

def pick(ch):
    if ord(ch) in main_cmap: return main_font
    if ord(ch) in fb_cmap: return fb_font
    return None

CW, CH, OX, OY = S * 3, S * 3, S, int(S * 2.0)   # scratch canvas and the pen origin on it (baseline)
def render(ch, font):
    im = Image.new("L", (CW, CH), 0)
    d = ImageDraw.Draw(im)
    d.text((OX, OY), ch, font=font, fill=255, anchor="ls", stroke_width=EMBOLDEN, stroke_fill=255)
    return im

def variant(full, bbox, k, sigma, pad):
    """blur the glyph, shrink by k; returns (image, offset of its top-left from the pen origin in sharp texels)"""
    l, t, r, b = bbox
    l -= pad; t -= pad; r += pad; b += pad
    w = ((r - l + k - 1) // k) * k; h = ((b - t + k - 1) // k) * k
    crop = full.crop((l, t, l + w, t + h))
    crop = crop.filter(ImageFilter.GaussianBlur(sigma))
    small = crop.resize((w // k, h // k), Image.LANCZOS)
    return small, (l - OX, t - OY)

items = []   # dict per glyph
for ch in chars:
    font = pick(ch)
    if font is None:
        print("skip (no glyph):", repr(ch)); continue
    full = render(ch, font)
    bbox = full.getbbox()
    adv = font.getlength(ch) + 2 * EMBOLDEN * 0.5 + TRACK
    if ch == " ":
        items.append(dict(cp=32, adv=adv, v=[None, None, None])); continue
    if bbox is None:
        continue
    l, t, r, b = bbox
    l -= 2; t -= 2; r += 2; b += 2                      # 2 texels of transparent border for the linear filter
    sharp = full.crop((l, t, r, b))
    soft, soff = variant(full, bbox, SOFT_K, SOFT_SIGMA, SOFT_PAD)
    glow, goff = variant(full, bbox, GLOW_K, GLOW_SIGMA, GLOW_PAD)
    items.append(dict(cp=ord(ch), adv=adv,
                      v=[(sharp, (l - OX, t - OY), 1), (soft, soff, SOFT_K), (glow, goff, GLOW_K)]))

# shelf packing, tallest first
rects = []
for it in items:
    for vi, v in enumerate(it["v"]):
        if v is not None: rects.append((v[0].size[1], it, vi))
rects.sort(key=lambda r: -r[0])
x = y = shelf = 0; GAP = 2
place = {}
for h, it, vi in rects:
    w = it["v"][vi][0].size[0]
    if x + w + GAP > ATLAS_W:
        x = 0; y += shelf + GAP; shelf = 0
    place[(id(it), vi)] = (x, y)
    x += w + GAP; shelf = max(shelf, h)
ATLAS_H = 1
while ATLAS_H < y + shelf + GAP: ATLAS_H *= 2

atlas = Image.new("RGBA", (ATLAS_W, ATLAS_H), (255, 255, 255, 0))
for h, it, vi in rects:
    img = it["v"][vi][0]
    px, py = place[(id(it), vi)]
    white = Image.new("RGBA", img.size, (255, 255, 255, 255))
    white.putalpha(img)
    atlas.paste(white, (px, py))

tex_dir = os.path.join(ROOT, "src/main/resources/assets/skymusic/textures/font")
font_dir = os.path.join(ROOT, "src/main/resources/assets/skymusic/font")
os.makedirs(tex_dir, exist_ok=True); os.makedirs(font_dir, exist_ok=True)
atlas.save(os.path.join(tex_dir, "lyrics_atlas.png"), optimize=True)
with open(os.path.join(tex_dir, "lyrics_atlas.png.mcmeta"), "w") as f:
    f.write('{"texture":{"blur":true,"clamp":true}}')

with open(os.path.join(font_dir, "lyrics_atlas.txt"), "w") as f:
    f.write("# atlas W H S  |  glyph: codepoint advance then 3 variants (sharp soft glow) of: x y w h offX offY scale (all in atlas texels / sharp texels, offsets from pen origin and baseline, y down); '-' = none\n")
    f.write("atlas %d %d %d\n" % (ATLAS_W, ATLAS_H, S))
    for it in items:
        parts = [str(it["cp"]), "%.2f" % it["adv"]]
        for vi, v in enumerate(it["v"]):
            if v is None: parts.append("-"); continue
            px, py = place[(id(it), vi)]
            parts.append("%d,%d,%d,%d,%.1f,%.1f,%d" % (px, py, v[0].size[0], v[0].size[1], v[1][0], v[1][1], v[2]))
        f.write(" ".join(parts) + "\n")
print("glyphs:", len(items), "atlas:", ATLAS_W, "x", ATLAS_H, "(%.1f MB as RGBA)" % (ATLAS_W * ATLAS_H * 4 / 1e6))
