# Sky Music (Fabric, Minecraft 1.20.1, client-side)

Build: push to GitHub -> Actions tab -> "build" -> download artifact `skymusic-jar`.
Or locally: `gradle build` (Java 17) -> build/libs/skymusic-1.0.0.jar
Needs Fabric Loader + Fabric API.

Use: put song.mp3 / .ogg / .wav / .flac and song.lrc (same name) in <minecraft folder>/skymusic/
Commands: /sky list | play <name> | pause | resume | stop | volume <0-100> | folder
Tip: set Minecraft's Music volume to 0 so it doesn't overlap.

## Performance (built in)
/sky perf auto        - default. Watches FPS and moves a 7-step quality ladder one step at a time (remembers steps that were too heavy)
/sky perf low|balanced|high|off   - fixed profile (off restores your original settings; high = your own settings)
/sky perf target <fps>            - FPS goal for auto mode (default 60)
/sky perf status
Also: sky and post effect scale with the level; skips rendering far-away entities, and drops to 10 FPS while the window is in the background.
Settings are remembered in config/skymusic.properties.
Note: Minecraft saves option changes on exit, so a later launch may treat tuned values as your "original".

## For even more FPS (separate mods / launcher settings)
Mods: Sodium (PC; may not run on Android/Pojav), Lithium, FerriteCore, ImmediatelyFast, EntityCulling, ModernFix.
JVM args (Aikar flags, 4-6 GB): -Xms4G -Xmx4G -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200
 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40
 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4
 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5
 -XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1

## Custom sky (built in, no shader mod needed)
Replaces the overworld sky: smooth day/dusk/night gradient, glowing sun + moon, animated light rays, twinkling stars,
rain/thunder dimming. Costs ~1-3k flat triangles per frame, and scales down with /sky perf low.
Disable: set enabled=false in config/skymusic-sky.properties and restart.
Note: distant terrain fog is still vanilla-colored, so it may not match the horizon color exactly at dusk.

## Built-in shader "Cine" (no Iris/Sodium needed)
On by default. One full-screen pass: dithered god rays, soft bloom, light FXAA (high quality only), filmic curve, golden-hour / moonlight / rain grading. Cost scales with the performance step (Q 0/1/2).
(older description follows)
One cheap full-screen post pass using vanilla's post-effect system: depth-masked sun god rays (10 taps),
vibrance, warm tint, soft contrast curve, vignette. Works together with the custom sky.
/sky fx auto|on|off   (auto = on at balanced/high perf level, off at low, since it costs one extra full-screen pass)

## Lyrics display (Apple Music style)
Each lyric line is a real object in the world (drawn with the depth buffer, like an entity or a block): trees, houses and hills hide it when they are in front of it, and it is part of the post-processing like everything else. It faces you when it is born and then stays locked at that position and rotation (walk around it, it does not follow you).
The whole line shows up dim, then every word lights up white in time with the singing (soft blue glow, a tiny lift and swell, long words light up in parts). Every letter is jelly: it springs up from below one after the other (stretching while it flies, squashing when it lands), then hops and wobbles like gummy candy the moment it is sung, and lit letters breathe very slightly. When a line is done it dims, goes out of focus (blurred), drifts up word by word and fades while the next one is born somewhere else. When the song ends the last lines leave the same way. The title shows the same way before the first line.
Where a line is born: close to you (about 5.5-9 blocks ahead), on the LEFT or RIGHT side of your view, slightly above your crosshair - never straight in front of you. The side switches randomly (75% chance to switch each line, never more than 2 in a row on the same side). If a wall, tree or hill is in the way it is born closer, in front of it (same place on your screen, just nearer and smaller), and it prefers spots that are free of blocks and not hidden from you. Very long lines are shrunk a little so they fit beside the crosshair. It is never born lower than your feet.
If you are not looking at the current line, a small plain subtitle shows at the top of the screen until the next line is born (/sky subtitle auto|on|off). /sky height <deg> moves where new lines are born up or down on your screen (default 26; lower = lower, higher = higher). /sky size <percent> makes the text bigger or smaller (default 100).
Lyrics are part of the HUD: F1 hides them.

Speed: all lyric letters are one batch of textured quads (one texture, one draw call per frame) from a baked font atlas, so there is no per-letter font switching any more. A line's sign is projected once per frame; glyph corners are plain arithmetic. The first versions drew each letter through the vanilla font renderer, which lagged and stuttered.
Font: Outfit Bold made into a puffy "jelly" face (rounded fat strokes, darker belly baked into the colour), baked with a soft and a glow copy of every glyph (assets/skymusic/textures/font/lyrics_atlas.png + font/lyrics_atlas.txt). Letters that are not in the atlas (Cyrillic, Greek, CJK ...) fall back to the vanilla font automatically.
Want another font? Put an OFL .ttf in tools/fonts, change MAIN_FONT (and EMBOLDEN) at the top of tools/gen_lyric_font.py and run `python3 tools/gen_lyric_font.py` (needs Pillow + fontTools). Inter ExtraBold gives a very SF-like look. Set JELLY = False there for the plain (non-puffy) letters; JELLY_CUT / JELLY_BLUR tune how fat and round the jelly is.
/sky font off  -> use the vanilla font instead. /sky debug prints what the lyric renderer is doing (quads drawn, which font).
While a /sky song plays, Minecraft's own music is muted automatically and restored afterwards; leaving the world stops the song.
If a .lrc has no real timing (every line is [00:00.00]) the lines are spread over the song as an estimate. Tell the mod when the singing really starts with /sky start <seconds> (e.g. /sky start 30). It is remembered for that song in skymusic/lyric-starts.properties; /sky start 0 goes back to automatic.
.lrc names are matched loosely (case, spaces, punctuation ignored). Text pasted from lrclib's JSON (with literal \n) is also understood.

## Bundled mods (inside the jar)
Lithium 0.11.4 (LGPL-3.0, game logic/CPU) and FerriteCore 6.0.1 (MIT, memory). Both are loaded automatically; no separate install.
If you also have them in your mods folder, Fabric just uses the newer copy.

## Sky textures
The moon (craters + maria), the star sprite and the aurora curtain pattern are small generated PNGs in assets/skymusic/textures/sky.
Regenerate / tweak them with `python3 tools/gen_textures.py` (needs numpy + Pillow). Night sky: 1500-2600 tiny soft stars with a faint milky-way belt (no star-free hole around the moon),
a textured moon about 6.5 degrees wide, and 3-4 aurora curtains made of fine animated green rays.

## Sky extras
Night: animated aurora ribbons and shooting stars (medium/high quality). Fog color follows the horizon color in the direction you face,
with a little extra mist at dawn, dusk and in rain. Far particles are never spawned (saves CPU).
All mixins are optional: if a hook does not match, it is skipped instead of crashing.
