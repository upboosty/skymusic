# Sky Music (Fabric, Minecraft 1.20.1, client-side)

Build: push to GitHub -> Actions tab -> "build" -> download artifact `skymusic-jar`.
Or locally: `gradle build` (Java 17) -> build/libs/skymusic-1.0.0.jar
Needs Fabric Loader + Fabric API.

Use: put song.mp3 / .ogg / .wav / .flac and song.lrc (same name) in <minecraft folder>/skymusic/
Commands: /sky list | play <name> | pause | resume | stop | volume <0-100> | folder
Tip: set Minecraft's Music volume to 0 so it doesn't overlap.

## Performance (built in)
/sky perf auto        - default. Watches FPS and moves a 7-step quality ladder one step at a time (remembers steps that were too heavy)
/sky perf low|balanced|high|off   - fixed profile (off restores your original settings; high = your own settings)
/sky perf target <fps>            - FPS goal for auto mode (default 60)
/sky perf status
Also: sky and post effect scale with the level; skips rendering far-away entities, and drops to 10 FPS while the window is in the background.
Settings are remembered in config/skymusic.properties.
Note: Minecraft saves option changes on exit, so a later launch may treat tuned values as your "original".

## For even more FPS (separate mods / launcher settings)
Mods: Sodium (PC; may not run on Android/Pojav), Lithium, FerriteCore, ImmediatelyFast, EntityCulling, ModernFix.
JVM args (Aikar flags, 4-6 GB): -Xms4G -Xmx4G -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200
 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40
 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4
 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5
 -XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1

## Custom sky (built in, no shader mod needed)
Replaces the overworld sky: smooth day/dusk/night gradient, glowing sun + moon, animated light rays, twinkling stars,
rain/thunder dimming. Costs ~1-3k flat triangles per frame, and scales down with /sky perf low.
Disable: set enabled=false in config/skymusic-sky.properties and restart.
Note: distant terrain fog is still vanilla-colored, so it may not match the horizon color exactly at dusk.

## Built-in shader "Cine" (no Iris/Sodium needed)
On by default. ONE full-screen pass (no extra render targets, no extra geometry, no mixins) that fakes a shader-pack look from the colour + depth the game already drew:
- **Vibrant day rays**: depth-masked god rays toward the sun with angular shafts, saturated gold (deep orange at golden hour) with a sky-blue fringe. The sky dome's own rays are golden and brighter too.
- **Bloom**: soft-threshold glow around the sun, snow, glowstone, lava, water glints; warmer at golden hour.
- **Ambient atmosphere**: depth haze tinted like the sky horizon, brighter toward the sun, thicker in valleys and in rain/dusk (zero extra texture taps).
- **Fake water reflections**: sky colour + sun glitter mirrored analytically on water surfaces (Fresnel, tiny ripples). It never samples the screen, so it is NOT screen-space reflections.
- **Fake sun shading**: 3-4 short depth taps toward the sun darken ground/faces next to tall things and faces turned away from the sun, with cool blue (violet at dusk) shade. Soft contact shadows only, NOT shadow maps. Off at quality step 0 (lowest).
- Vibrance, golden-hour / moonlight / rain grading, filmic shoulder, light FXAA (high quality only), vignette, dither.
Not used on purpose: global illumination, ray tracing, screen-space reflections, volumetric lighting, shadow maps.
Cost: one pass; tap count scales with the performance step (Q 0/1/2): bloom 5/8/12, rays 8/12/18, sun shading 0/3/4. In the Nether/End only bloom + grading run.

Commands (all remembered in config/skymusic-fx.properties):
/sky fx auto|on|off          shader on/off (auto = off at the lowest performance steps)
/sky fx preset lite|default|vivid    lite = no sun shading, lighter haze/bloom (cheapest); vivid = stronger rays/bloom/colour
/sky fx rays|bloom|vibrance|shadows|water|haze <0-200>    strength in percent; 0 skips that effect completely (it then costs nothing)
/sky fx status
If the GPU ever rejects the shader the mod turns it off by itself and says so in chat (the game keeps running).

## Lyrics display
Each lyric line is born in the air 8-14 blocks in front of you, inside your view, at a random spot. It faces you when it is born and then stays locked at that position and rotation (walk around it, it does not follow you). Letters type in as the line is sung. When a line is done it slides up and fades away while the next one is born somewhere else in front of you. When the song ends the last lines fade away too. The title shows the same way before the first line.
It is never born lower than your feet (if you look down it is born just ahead of where you stand), never closer than about 6 blocks, and it tries to pick a spot that is free of blocks (trees, ground, water).
If you are not looking at the current line, a small plain subtitle shows at the top of the screen until the next line is born (/sky subtitle auto|on|off).
New lines never overlap the previous ones or the crosshair. /sky height <deg> moves where new lines are born, up or down (default 26).
Lyrics are part of the HUD: F1 hides them. If the bundled TTF font can't load on your device (all letters would be identical boxes) the mod switches to the vanilla font by itself.
/sky font off  -> use the vanilla font instead (if the custom font ever renders as boxes on your device)
/sky debug also prints what the lyric renderer is doing (glyphs drawn, which font).
Bundled fonts: Outfit Bold (OFL) with DejaVu Sans Bold as fallback (see licenses in assets/skymusic/font).
While a /sky song plays, Minecraft's own music is muted automatically and restored afterwards; leaving the world stops the song.
If a .lrc has no real timing (every line is [00:00.00]) the lines are spread over the song as an estimate. Tell the mod when the singing really starts with /sky start <seconds> (e.g. /sky start 30). It is remembered for that song in skymusic/lyric-starts.properties; /sky start 0 goes back to automatic.
.lrc names are matched loosely (case, spaces, punctuation ignored). Text pasted from lrclib's JSON (with literal \n) is also understood.

## Bundled mods (inside the jar)
Lithium 0.11.4 (LGPL-3.0, game logic/CPU) and FerriteCore 6.0.1 (MIT, memory). Both are loaded automatically; no separate install.
If you also have them in your mods folder, Fabric just uses the newer copy.

## Sky textures
The moon (craters + maria), the star sprite and the aurora curtain pattern are small generated PNGs in assets/skymusic/textures/sky.
Regenerate / tweak them with `python3 tools/gen_textures.py` (needs numpy + Pillow). Night sky: 1500-2600 tiny soft stars with a faint milky-way belt (no star-free hole around the moon),
a textured moon about 6.5 degrees wide, and 3-4 aurora curtains made of fine animated green rays.

## Sky extras
Night: animated aurora ribbons and shooting stars (medium/high quality). Fog color follows the horizon color in the direction you face,
with a little extra mist at dawn, dusk and in rain. Far particles are never spawned (saves CPU).
All mixins are optional: if a hook does not match, it is skipped instead of crashing.
