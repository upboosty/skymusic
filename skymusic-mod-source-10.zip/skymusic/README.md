# Sky Music (Fabric, Minecraft 1.20.1, client-side)

Build: push to GitHub -> Actions tab -> "build" -> download artifact `skymusic-jar`.
Or locally: `gradle build` (Java 17) -> build/libs/skymusic-1.0.0.jar
Needs Fabric Loader + Fabric API.

Use: put song.mp3 / .ogg / .wav / .flac and song.lrc (same name) in <minecraft folder>/skymusic/
Commands: /sky list | play <name> | pause | resume | stop | volume <0-100> | folder
Tip: set Minecraft's Music volume to 0 so it doesn't overlap.

## Performance (built in)
/sky perf auto        - default. Watches FPS and moves a 7-step quality ladder one step at a time (remembers steps that were too heavy)
/sky perf low|balanced|high|off   - fixed profile (off restores your original settings; high = your own settings)
/sky perf target <fps>            - FPS goal for auto mode (default 60)
/sky perf status
Also: sky and post effect scale with the level; skips rendering far-away entities, and drops to 10 FPS while the window is in the background.
Settings are remembered in config/skymusic.properties.
Note: Minecraft saves option changes on exit, so a later launch may treat tuned values as your "original".

## For even more FPS (separate mods / launcher settings)
Mods: Sodium (PC; may not run on Android/Pojav), Lithium, FerriteCore, ImmediatelyFast, EntityCulling, ModernFix.
JVM args (Aikar flags, 4-6 GB): -Xms4G -Xmx4G -XX:+UseG1GC -XX:+ParallelRefProcEnabled -XX:MaxGCPauseMillis=200
 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40
 -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -XX:G1HeapWastePercent=5 -XX:G1MixedGCCountTarget=4
 -XX:InitiatingHeapOccupancyPercent=15 -XX:G1MixedGCLiveThresholdPercent=90 -XX:G1RSetUpdatingPauseTimePercent=5
 -XX:SurvivorRatio=32 -XX:+PerfDisableSharedMem -XX:MaxTenuringThreshold=1

## Custom sky (built in, no shader mod needed)
Replaces the overworld sky: smooth day/dusk/night gradient, glowing sun + moon, twinkling stars,
rain/thunder dimming. Costs ~1-3k flat triangles per frame, and scales down with /sky perf low.
Disable: set enabled=false in config/skymusic-sky.properties and restart.
Note: distant terrain fog is still vanilla-colored, so it may not match the horizon color exactly at dusk.

## Built-in shader "Cine" (no Iris/Sodium needed)
On by default. One full-screen pass: soft bloom, light FXAA (high quality only), filmic curve, golden-hour / moonlight / rain grading, and the sun's god rays on top. Cost scales with the performance step (Q 0/1/2).
/sky fx auto|on|off   (auto = on at balanced/high perf level, off at low, since it costs one extra full-screen pass)

### God rays (from the glsl-godrays demo)
The sun's rays are the radial-blur "Volumetric Light Scattering as a Post-Process" effect from https://github.com/Erkaman/glsl-godrays (MIT), with the demo's own numbers: density 1.0, weight 0.01, decay 1.0, exposure 1.0, 100 samples, added on top of the finished picture. The demo draws an "occlusion texture" (white sun, everything that hides it black); the mod does not store it, it evaluates it where the loop samples it: the sun disc (the bright core of the sky sun), counted only where the depth buffer shows sky. So terrain, trees, clouds, entities and the lyrics cut the rays exactly like the black geometry in the demo. Samples that cannot land on the sun are 0 in the demo, so they are skipped (checked: same result as the full loop to 1e-13), which keeps it cheap on phones.
The old rays (the spokes drawn in the sky and the old dithered post rays, halo and hot core) are gone. The sun disc and its soft glow in the sky are still there. The rays are tinted with the colour of the sun (white at noon, orange at dusk; the demo's sun is white).
Only in the overworld, only while the sun is above the horizon, fading out in rain, and off under water / lava. The tunables are the RAY_* constants at the top of the god ray code in shaders/program/cine.fsh.

## Lyrics display (Apple Music style)
Each lyric line is a real object in the world (drawn with the depth buffer, like an entity or a block): trees, houses and hills hide it when they are in front of it, and it is part of the post-processing like everything else. It faces you when it is born and then stays locked at that position and rotation (walk around it, it does not follow you).
The whole line shows up dim, then every word lights up white in time with the singing (a tiny lift and swell, long words light up in parts). Every letter is jelly (squashes and stretches, thickness follows a little): it springs up from below one after the other (stretching while it flies, squashing when it lands), then hops and wobbles like gummy candy the moment it is sung, and lit letters breathe very slightly. When a line is done it dims, drifts up word by word and fades while the next one is born somewhere else. When the song ends the last lines leave the same way. The title shows the same way before the first line.
Where a line is born: close to you (about 5.5-9 blocks ahead), on the LEFT or RIGHT side of your view, slightly above your crosshair - never straight in front of you. The side switches randomly (75% chance to switch each line, never more than 2 in a row on the same side). If a wall, tree or hill is in the way it is born closer, in front of it (same place on your screen, just nearer and smaller), and it prefers spots that are free of blocks and not hidden from you. Very long lines are shrunk a little so they fit beside the crosshair. It is never born lower than your feet.
If you are not looking at the current line, a small plain subtitle shows at the top of the screen until the next line is born (/sky subtitle auto|on|off). /sky height <deg> moves where new lines are born up or down on your screen (default 26; lower = lower, higher = higher). /sky size <percent> makes the text bigger or smaller (default 100).
Lyrics are part of the HUD: F1 hides them.
Lighting: the letters are lit by the world they hang in: sky light and block light at the sign (shade under trees, caves, torches), time of day and weather (vanilla's sky brightness: dark at night, darker in rain and thunder, white flash with lightning), blue moonlight and golden dusk, the dimension's ambient light (nether, end, other dimensions, no sky needed), your brightness setting, night vision, water and lava tint. The side walls are shaded by the real direction of the sun or moon. The text never gets darker than LEGIBLE in SkyRenderer.java, and sung letters glow a little by themselves (EMIT).

Speed: all lyric letters are one batch of coloured triangles (one draw call per frame). Every letter is a solid extruded from a baked outline (front face + side walls, plus a back face when you are behind the sign) and is moved by the jelly animation with one small matrix per letter. Letters that are off screen are skipped.
Font: Impact, baked to assets/skymusic/font/text3d.bin by tools/gen_text3d.py (about 560 glyphs: Latin, Cyrillic, Greek, symbols, notes). The side walls are shaded by which way they face (light from the upper left), so the letters look solid. Letters that are not in the font fall back to the flat vanilla font automatically.
Thickness: DEPTH at the top of SkyRenderer.java (layout px, default 6; a capital is about 14.7 px high). Size of the letters in the line: EM in MeshFont.java. How far the sign is turned toward the middle of your view: TILT in SkyRenderer.java (0 = straight at you).
Want another font? Put a .ttf (TrueType outlines) in tools/fonts and run `python3 tools/gen_text3d.py tools/fonts/<name>.ttf` (needs fontTools). Adjust EM in MeshFont.java if its capitals come out bigger or smaller (the script prints the height of H in em).
Note: Impact belongs to Monotype and is not freely redistributable; fine for your own use, but do not publish the mod with it inside.
/sky font off  -> use the vanilla font instead. /sky debug prints what the lyric renderer is doing (triangles drawn, which font).
While a /sky song plays, Minecraft's own music is muted automatically and restored afterwards; leaving the world stops the song.
If a .lrc has no real timing (every line is [00:00.00]) the lines are spread over the song as an estimate. Tell the mod when the singing really starts with /sky start <seconds> (e.g. /sky start 30). It is remembered for that song in skymusic/lyric-starts.properties; /sky start 0 goes back to automatic.
.lrc names are matched loosely (case, spaces, punctuation ignored). Text pasted from lrclib's JSON (with literal \n) is also understood.

## Bundled mods (inside the jar)
Lithium 0.11.4 (LGPL-3.0, game logic/CPU) and FerriteCore 6.0.1 (MIT, memory). Both are loaded automatically; no separate install.
If you also have them in your mods folder, Fabric just uses the newer copy.

## Sky textures
The moon (craters + maria), the star sprite and the aurora curtain pattern are small generated PNGs in assets/skymusic/textures/sky.
Regenerate / tweak them with `python3 tools/gen_textures.py` (needs numpy + Pillow). Night sky: 1500-2600 tiny soft stars with a faint milky-way belt (no star-free hole around the moon),
a textured moon about 6.5 degrees wide, and 3-4 aurora curtains made of fine animated green rays.

## Sky extras
Night: animated aurora ribbons and shooting stars (medium/high quality). Fog color follows the horizon color in the direction you face,
with a little extra mist at dawn, dusk and in rain. Far particles are never spawned (saves CPU).
All mixins are optional: if a hook does not match, it is skipped instead of crashing.
