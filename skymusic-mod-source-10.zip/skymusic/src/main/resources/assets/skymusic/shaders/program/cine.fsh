#version 150
// Sky Music "Cine" post shader: ONE full-screen pass, no extra render targets, no extra geometry.
// Everything below is a cheap fake built from the colour + depth the game already rendered:
//   - bloom           : golden-spiral taps (5/8/12), soft threshold, saturated + warm at golden hour
//   - god rays        : depth-masked radial blur toward the sun (8/12/18 taps) with angular shafts, vibrant gold/sky tint
//   - haze            : analytic depth fog with sun forward-scattering + valley mist (0 extra taps)
//   - water shine     : ANALYTIC sky + sun reflection on water tops (0 extra taps, no screen-space reflection)
//   - sun shading     : 3-4 short depth taps toward the sun = contact shadows (no shadow maps, Q >= 1 only)
//   - grading         : vibrance, golden hour, moonlight, rain, filmic shoulder, vignette, dither
// Q = 0 light (phones), 1 balanced, 2 high (adds FXAA + more taps).
// Loops use constant bounds + early break so strict GLSL-ES translators (Android) accept them.

uniform sampler2D DiffuseSampler;
uniform sampler2D DepthSampler;
uniform vec2 OutSize;

uniform float SunU;
uniform float SunV;
uniform float RayVis;
uniform float Warm;
uniform float Aspect;
uniform float Q;
uniform float Night;
uniform float Rain;

uniform float GameTime;   // seconds
uniform float Near;       // projection near / far (read from the real projection matrix)
uniform float Far;
uniform float TanHalf;    // tan(fov / 2) (vertical)
uniform float Under;      // 1 when the camera is in water / lava / powder snow
uniform float DayVis;     // 0..1, sun above the horizon and not raining
uniform vec3 CamPos;      // world space
uniform vec3 CamRight;
uniform vec3 CamUp;
uniform vec3 CamFwd;
uniform vec3 SunDir;      // world space, towards the sun
uniform vec3 ZenCol;      // same palette as the sky dome
uniform vec3 HorCol;
uniform vec3 SunCol;
uniform vec3 GainA;       // x = rays, y = bloom, z = vibrance      (1.0 = default, 0 = feature skipped)
uniform vec3 GainB;       // x = sun shading, y = water shine, z = haze

in vec2 texCoord;
out vec4 fragColor;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

// depth buffer value -> distance along the view axis, in blocks
float lin(float z) {
    float n = z * 2.0 - 1.0;
    return 2.0 * Near * Far / (Far + Near - n * (Far - Near));
}

// ---- light FXAA (only at Q = 2) ----
vec3 fxaa(vec2 uv, vec3 rgbM) {
    vec2 px = 1.0 / OutSize;
    vec3 rgbNW = texture(DiffuseSampler, uv + vec2(-1.0, -1.0) * px).rgb;
    vec3 rgbNE = texture(DiffuseSampler, uv + vec2( 1.0, -1.0) * px).rgb;
    vec3 rgbSW = texture(DiffuseSampler, uv + vec2(-1.0,  1.0) * px).rgb;
    vec3 rgbSE = texture(DiffuseSampler, uv + vec2( 1.0,  1.0) * px).rgb;
    float lNW = luma(rgbNW), lNE = luma(rgbNE), lSW = luma(rgbSW), lSE = luma(rgbSE), lM = luma(rgbM);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    if (lMax - lMin < max(0.03, lMax * 0.125)) return rgbM;
    vec2 dir;
    dir.x = -((lNW + lNE) - (lSW + lSE));
    dir.y =  ((lNW + lSW) - (lNE + lSE));
    float dirReduce = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-6.0), vec2(6.0)) * px;
    vec3 a = 0.5 * (texture(DiffuseSampler, uv + dir * (1.0 / 3.0 - 0.5)).rgb
                  + texture(DiffuseSampler, uv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 b = a * 0.5 + 0.25 * (texture(DiffuseSampler, uv + dir * -0.5).rgb
                             + texture(DiffuseSampler, uv + dir *  0.5).rgb);
    float lB = luma(b);
    return (lB < lMin || lB > lMax) ? a : b;
}

void main() {
    vec2 uv = texCoord;
    float noise = hash12(gl_FragCoord.xy);
    float z0 = texture(DepthSampler, uv).r;
    bool isSky = z0 > 0.99999;
    vec3 c = texture(DiffuseSampler, uv).rgb;
    if (Q > 1.5) c = fxaa(uv, c);

    // ---------- view ray (no matrices needed: camera basis comes in as three vectors) ----------
    vec2 ndc = uv * 2.0 - 1.0;
    vec3 vray = vec3(ndc.x * Aspect * TanHalf, ndc.y * TanHalf, -1.0);          // view space, z = -1
    vec3 Vu = CamFwd + vray.x * CamRight + vray.y * CamUp;                       // world space, unnormalised
    vec3 V = normalize(Vu);
    float d0 = isSky ? Far : lin(z0);
    vec3 wp = CamPos + Vu * d0;                                                  // world position of this pixel
    bool geo = !isSky && Under < 0.5;

    // ---------- sun shading: short contact shadows toward the sun (screen-space depth taps, NOT shadow maps) ----------
    float shade = 0.0;
    if (geo && Q > 0.5 && GainB.x > 0.01 && DayVis > 0.02 && d0 < 90.0) {
        vec3 vp = vray * d0;                                                      // view-space position
        vec3 L = vec3(dot(SunDir, CamRight), dot(SunDir, CamUp), -dot(SunDir, CamFwd));   // sun direction in view space
        int sn = Q > 1.5 ? 4 : 3;
        float reach = Q > 1.5 ? 1.0 : 1.45;
        float bias = 0.05 + d0 * 0.0045;                                          // hides depth quantisation / self shadowing
        for (int i = 0; i < 4; i++) {
            if (i >= sn) break;
            float t = 0.5 * exp2(float(i) * 1.1) * reach * (0.92 + 0.16 * noise);   // ~0.5 .. 5.5 blocks toward the sun
            vec3 p = vp + L * t;
            float dr = -p.z;
            if (dr < Near) break;
            vec2 puv = vec2(p.x / (dr * Aspect * TanHalf), p.y / (dr * TanHalf)) * 0.5 + 0.5;
            if (puv.x < 0.0 || puv.x > 1.0 || puv.y < 0.0 || puv.y > 1.0) break;
            float diff = dr - lin(texture(DepthSampler, puv).r);                  // > 0: something solid is in front of the light ray
            shade = max(shade, smoothstep(bias, bias + 0.15, diff) * (1.0 - smoothstep(3.0, 5.0, diff)));
        }
        shade *= (1.0 - smoothstep(45.0, 90.0, d0)) * DayVis * GainB.x;
    }
    vec3 shTint = mix(vec3(0.66, 0.78, 1.0), vec3(0.62, 0.60, 0.85), Warm);       // shade is lit by the blue sky (violet at dusk)
    c = mix(c, c * shTint, shade * 0.75);
    c *= 1.0 - shade * 0.14;

    // ---------- water shine: analytic sky + sun reflection (no screen sampling at all) ----------
    // Water tops sit at y = n + 8/9, so "blue + right height + looking down" finds them from depth alone.
    if (geo && GainB.y > 0.01 && V.y < -0.02) {
        float wm = 1.0 - smoothstep(0.012, 0.045, abs(fract(wp.y) - 0.8889));
        float blue = smoothstep(0.02, 0.10, c.b - c.r * 0.8);
        float k = wm * blue * GainB.y;
        if (k > 0.002) {
            float amp = 0.05 / (1.0 + d0 * 0.04);                                  // ripples fade with distance (no far shimmer)
            vec2 pw = wp.xz;
            vec3 N = normalize(vec3(
                (sin(pw.x * 1.3 + pw.y * 0.7 + GameTime * 1.2) + 0.5 * sin(pw.x * 3.1 - pw.y * 2.3 - GameTime * 1.7)) * amp,
                1.0,
                (sin(pw.y * 1.1 - pw.x * 0.5 + GameTime * 1.0) + 0.5 * sin(pw.y * 2.9 + pw.x * 2.1 + GameTime * 1.5)) * amp));
            vec3 R = reflect(V, N);
            R.y = abs(R.y);
            float cosT = clamp(-V.y, 0.0, 1.0);
            float F = mix(0.16, 0.95, pow(1.0 - cosT, 4.0));                        // Fresnel: mirror-like at grazing angles
            vec3 sky = mix(HorCol, ZenCol, sqrt(R.y));
            float sd = max(dot(R, SunDir), 0.0);
            sky += SunCol * (pow(sd, 6.0) * 0.25 + pow(sd, 48.0) * 0.45) * DayVis;
            float sparkle = 0.55 + 0.45 * hash12(floor(gl_FragCoord.xy * 0.5) + floor(GameTime * 5.0));
            vec3 glint = SunCol * pow(sd, 700.0) * 5.0 * sparkle * DayVis;
            c = mix(c, sky * 1.05, F * 0.85 * k) + glint * k;
        }
    }

    // ---------- haze: depth fog tinted like the horizon, brighter toward the sun, thicker in valleys ----------
    if (geo && GainB.z > 0.01) {
        float dens = 0.0042 * (1.0 + Rain * 1.5 + Warm * 0.5);
        float hz = 1.0 - exp(-d0 * dens);
        hz *= exp(-max(wp.y - 72.0, 0.0) * 0.012);
        float fwd = pow(max(dot(V, SunDir), 0.0), 5.0);
        vec3 hc = HorCol + SunCol * fwd * 0.40 * DayVis;
        c = mix(c, hc, clamp(hz * 0.6 * GainB.z, 0.0, 0.75));
    }

    // ---------- bloom: golden-spiral taps, rotated per pixel so few taps still look smooth ----------
    if (GainA.y > 0.01) {
        int bn = Q > 1.5 ? 12 : (Q > 0.5 ? 8 : 5);
        float radius = 0.026;
        vec3 bloom = vec3(0.0);
        float rot = noise * 6.2831853;
        for (int i = 0; i < 12; i++) {
            if (i >= bn) break;
            float r = sqrt((float(i) + 0.5) / float(bn));
            float a = float(i) * 2.3999632 + rot;
            vec2 o = vec2(cos(a) / Aspect, sin(a)) * r * radius;
            vec3 s = texture(DiffuseSampler, uv + o).rgb;
            float br = smoothstep(0.82, 1.02, luma(s));                           // only the really bright stuff glows
            bloom += s * br * (1.0 - r * 0.55);
        }
        bloom /= float(bn);
        bloom = mix(vec3(luma(bloom)), bloom, 1.25) * mix(vec3(1.0), vec3(1.0, 0.82, 0.62), Warm * 0.6);
        c += bloom * 1.4 * GainA.y * (1.0 - Rain * 0.5) * (1.0 - Night * 0.35);
    }

    // ---------- god rays: radial blur of the sky mask toward the sun + angular shafts ----------
    if (RayVis > 0.001 && GainA.x > 0.01) {
        int n = Q > 1.5 ? 18 : (Q > 0.5 ? 12 : 8);
        vec2 sunUV = vec2(SunU, SunV);
        vec2 delta = (sunUV - uv) * (0.95 / float(n));
        vec2 p = uv + delta * noise;                 // jitter hides banding at low sample counts
        float decay = 1.0, acc = 0.0;
        for (int i = 0; i < 18; i++) {
            if (i >= n) break;
            p += delta;
            float sky = step(0.99999, texture(DepthSampler, clamp(p, 0.001, 0.999)).r);
            acc += sky * decay;
            decay *= 0.94;
        }
        acc /= float(n);

        vec2 dd = sunUV - uv;
        dd.x *= Aspect;
        float d = length(dd);
        float fall = clamp(1.0 - d * 0.6, 0.0, 1.0);
        fall *= fall;

        // beams: irregular angular modulation so open sky shows individual shafts, not just a smooth glow
        float ang = atan(dd.y, dd.x);
        float shaft = 0.62 + 0.38 * (0.5 * sin(ang * 7.0 + GameTime * 0.10)
                                   + 0.3 * sin(ang * 17.0 - GameTime * 0.17)
                                   + 0.2 * sin(ang * 31.0 + GameTime * 0.05));
        shaft = mix(1.0, shaft, smoothstep(0.02, 0.20, d));

        vec3 rayColor = mix(vec3(1.0, 0.82, 0.42), vec3(1.0, 0.45, 0.14), Warm);                 // saturated gold -> deep orange
        vec3 outer = mix(rayColor, vec3(0.55, 0.80, 1.0), smoothstep(0.15, 0.85, d) * 0.55 * (1.0 - Warm));   // sky-blue fringe far from the sun
        float g = GainA.x * RayVis;
        c += outer * acc * shaft * fall * g * 0.80;
        c += rayColor * pow(fall, 3.0) * g * 0.22;                                // wide halo
        c += mix(rayColor, vec3(1.0), 0.35) * exp(-d * 16.0) * g * 0.45;          // hot core glow
    }

    // ---------- filmic shoulder (keeps bright rays/bloom from clipping to flat white) ----------
    vec3 fm = vec3(1.0) - exp(-c * 1.45);
    c = mix(c, fm, 0.55);

    // ---------- grading ----------
    float l = luma(c);
    float mx = max(c.r, max(c.g, c.b)), mn = min(c.r, min(c.g, c.b));
    float vib = 0.28 * (1.0 - (mx - mn));                                   // lifts dull colours more than vivid ones
    float day = DayVis * GainA.z;
    float sat = 1.0 + vib + 0.06 + 0.20 * day + (isSky ? 0.22 * day : 0.0); // daylight + sky get an extra vibrance push
    c = mix(vec3(l), c, sat);
    c = mix(c, c * vec3(1.06, 1.0, 0.92), Warm * 0.7);                      // golden hour
    c = mix(c, c * vec3(0.93, 0.98, 1.05) + vec3(0.003, 0.006, 0.014), Night * 0.6); // moonlit blue (kept mild so the aurora stays green)
    c = mix(c, vec3(luma(c)) * vec3(0.95, 0.98, 1.02), Rain * 0.35);        // wet, flatter look
    c = mix(c, smoothstep(0.0, 1.0, c), 0.30);                              // gentle S-curve

    vec2 q = uv - 0.5;
    c *= 1.0 - dot(q, q) * 0.55;                                            // vignette
    c += (noise - 0.5) / 255.0;                                             // dither

    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
