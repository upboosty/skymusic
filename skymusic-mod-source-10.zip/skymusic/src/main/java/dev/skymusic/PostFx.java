package dev.skymusic;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import dev.skymusic.mixin.PostEffectProcessorAccessor;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.gl.PostEffectPass;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.render.CameraSubmersionType;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.function.IntConsumer;

/**
 * Built-in "shader": ONE cheap full-screen post pass, no Iris/Sodium needed, no extra render targets.
 * It fakes the shader-pack look from colour + depth only: vibrant god rays, bloom, atmospheric haze,
 * analytic water sky/sun reflections and short sun-direction contact shadows (see cine.fsh).
 * No GI, no ray tracing, no screen-space reflections, no volumetric lighting, no shadow maps.
 */
public class PostFx {
    public enum Mode { AUTO, ON, OFF }
    private static Mode mode = Mode.ON;
    private static PostEffectProcessor proc;
    private static int w, h;
    private static boolean failed = false;

    // effect strengths in percent (100 = default, 0 = that part is skipped entirely in the shader = free)
    private static int pRays = 100, pBloom = 100, pVibrance = 100, pShadows = 100, pWater = 100, pHaze = 100;
    private static Path cfg;

    // scratch, reused every frame (no per-frame allocation)
    private static final float[] zen = new float[3], hor = new float[3], sunC = new float[3];

    public static boolean active() {
        return mode == Mode.ON || (mode == Mode.AUTO && Perf.skyQuality >= 1);   // default ON: the shader scales its own cost with Perf quality
    }

    public static void init() {
        cfg = FabricLoader.getInstance().getConfigDir().resolve("skymusic-fx.properties");
        loadCfg();
        WorldRenderEvents.END.register(PostFx::render);
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(
            new SimpleSynchronousResourceReloadListener() {
                @Override public Identifier getFabricId() { return new Identifier("skymusic", "postfx"); }
                @Override public void reload(ResourceManager rm) {
                    if (proc != null) { try { proc.close(); } catch (Exception ignored) {} proc = null; }
                    failed = false;
                }
            });
    }

    // ---------- config ----------
    private static int clampPct(String s, int def) {
        try { return Math.max(0, Math.min(200, Integer.parseInt(s.trim()))); } catch (Exception e) { return def; }
    }

    private static void loadCfg() {
        try (InputStream in = Files.newInputStream(cfg)) {
            Properties p = new Properties(); p.load(in);
            try { mode = Mode.valueOf(p.getProperty("mode", "ON").toUpperCase()); } catch (Exception ignored) {}
            pRays = clampPct(p.getProperty("rays", "100"), 100);
            pBloom = clampPct(p.getProperty("bloom", "100"), 100);
            pVibrance = clampPct(p.getProperty("vibrance", "100"), 100);
            pShadows = clampPct(p.getProperty("shadows", "100"), 100);
            pWater = clampPct(p.getProperty("water", "100"), 100);
            pHaze = clampPct(p.getProperty("haze", "100"), 100);
        } catch (Exception ignored) {}
    }

    private static void saveCfg() {
        try (OutputStream out = Files.newOutputStream(cfg)) {
            Properties p = new Properties();
            p.setProperty("mode", mode.name());
            p.setProperty("rays", String.valueOf(pRays));
            p.setProperty("bloom", String.valueOf(pBloom));
            p.setProperty("vibrance", String.valueOf(pVibrance));
            p.setProperty("shadows", String.valueOf(pShadows));
            p.setProperty("water", String.valueOf(pWater));
            p.setProperty("haze", String.valueOf(pHaze));
            p.store(out, "Sky Music shader strengths in percent (0-200). 0 = that effect is skipped completely.");
        } catch (Exception ignored) {}
    }

    // ---------- uniforms ----------
    private static void setU(String name, float value) {
        for (PostEffectPass pass : ((PostEffectProcessorAccessor) (Object) proc).skymusic$getPasses()) {
            GlUniform u = pass.getProgram().getUniformByName(name);
            if (u != null) u.set(value);
        }
    }

    private static void setU3(String name, float x, float y, float z) {
        for (PostEffectPass pass : ((PostEffectProcessorAccessor) (Object) proc).skymusic$getPasses()) {
            GlUniform u = pass.getProgram().getUniformByName(name);
            if (u != null) u.set(x, y, z);
        }
    }

    private static float sm(float a, float b, float x) {
        float t = Math.max(0f, Math.min(1f, (x - a) / (b - a)));
        return t * t * (3f - 2f * t);
    }

    private static void render(WorldRenderContext ctx) {
        if (failed || !active()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld world = ctx.world();
        if (world == null) return;
        try {
            if (proc == null) {
                proc = new PostEffectProcessor(mc.getTextureManager(), mc.getResourceManager(), mc.getFramebuffer(),
                    new Identifier("skymusic", "shaders/post/cine.json"));
                w = h = 0;
            }
            int fw = mc.getWindow().getFramebufferWidth(), fh = mc.getWindow().getFramebufferHeight();
            if (fw != w || fh != h) { proc.setupDimensions(fw, fh); w = fw; h = fh; }

            // only the overworld has the sun/sky this shader fakes light for (Nether / End keep bloom + grading only)
            float sunGate = world.getRegistryKey() == World.OVERWORLD ? 1f : 0f;

            // sun position (world space) and on screen
            float td = ctx.tickDelta();
            float ang = world.getSkyAngle(td) * (float) (Math.PI * 2);
            float sx = -(float) Math.sin(ang), sy = (float) Math.cos(ang);
            float rain = world.getRainGradient(td);
            float thunder = world.getThunderGradient(td);
            float vis = sm(-0.05f, 0.25f, sy) * (1f - rain) * sunGate;
            float u = 0.5f, v = 0.5f;
            Matrix4f view = ctx.matrixStack().peek().getPositionMatrix();
            Matrix4f proj = ctx.projectionMatrix();
            Matrix4f vp = new Matrix4f(proj).mul(view);
            Vector4f c = new Vector4f(sx * 100f, sy * 100f, 0f, 1f);
            vp.transform(c);
            if (c.w <= 0f) vis = 0f; else { u = c.x / c.w * 0.5f + 0.5f; v = c.y / c.w * 0.5f + 0.5f; }

            // camera basis in world space = rows of the (rotation-only) view matrix; the camera looks down -Z
            float rx = view.m00(), ry = view.m10(), rz = view.m20();
            float ux = view.m01(), uy = view.m11(), uz = view.m21();
            float fx = -view.m02(), fy = -view.m12(), fz = -view.m22();

            // near / far / fov straight from the real projection matrix (stays right with any view distance or FOV)
            float m22 = proj.m22(), m32 = proj.m32(), m11 = proj.m11();
            float near = m32 / (m22 - 1f), far = m32 / (m22 + 1f);
            if (!(near > 0f) || !(far > near) || Float.isInfinite(far)) { near = 0.05f; far = 512f; }
            float tanHalf = m11 > 0.0001f ? 1f / m11 : 0.6f;

            CustomSky.palette(sy, rain, thunder, zen, hor, sunC);
            Vec3d cp = ctx.camera().getPos();
            boolean under = ctx.camera().getSubmersionType() != CameraSubmersionType.NONE;
            float dayVis = sm(0f, 0.3f, sy) * (1f - rain * 0.85f) * sunGate;
            float t = ((world.getTime() % 24000L) + td) / 20f;       // seconds, wraps every 20 minutes (keeps float precision)

            setU("SunU", u);
            setU("SunV", v);
            setU("RayVis", vis);
            setU("Warm", 1f - sm(0f, 0.5f, sy));
            setU("Aspect", fw / (float) fh);
            setU("Q", Perf.skyQuality);                          // 0 = light (phones), 1 = balanced, 2 = high (adds FXAA, more taps)
            setU("Night", 1f - sm(-0.15f, 0.15f, sy));
            setU("Rain", rain);
            setU("GameTime", t);
            setU("Near", near);
            setU("Far", far);
            setU("TanHalf", tanHalf);
            setU("Under", under ? 1f : 0f);
            setU("DayVis", dayVis);
            setU3("CamPos", (float) cp.x, (float) cp.y, (float) cp.z);
            setU3("CamRight", rx, ry, rz);
            setU3("CamUp", ux, uy, uz);
            setU3("CamFwd", fx, fy, fz);
            setU3("SunDir", sx, sy, 0f);
            setU3("ZenCol", zen[0], zen[1], zen[2]);
            setU3("HorCol", hor[0], hor[1], hor[2]);
            setU3("SunCol", sunC[0], sunC[1], sunC[2]);
            setU3("GainA", pRays / 100f, pBloom / 100f, pVibrance / 100f);
            setU3("GainB", pShadows / 100f * sunGate, pWater / 100f * sunGate, pHaze / 100f * sunGate);

            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.resetTextureMatrix();
            proc.render(td);
            mc.getFramebuffer().beginWrite(false);
            RenderSystem.enableDepthTest();
        } catch (Throwable e) {
            failed = true;
            proc = null;
            SkyMusicClient.msg("Post effect disabled (error: " + e + ")");
        }
    }

    // ---------- commands: /sky fx ... ----------
    private static LiteralArgumentBuilder<FabricClientCommandSource> gain(String name, String label, IntConsumer setter) {
        return ClientCommandManager.literal(name).then(
            ClientCommandManager.argument("percent", IntegerArgumentType.integer(0, 200)).executes(c -> {
                int pct = IntegerArgumentType.getInteger(c, "percent");
                setter.accept(pct); saveCfg();
                SkyMusicClient.msg(label + ": " + pct + "%" + (pct == 0 ? " (off, costs nothing)" : ""));
                return 1; }));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> preset(String name, int rays, int bloom, int vib, int shadows, int water, int haze) {
        return ClientCommandManager.literal(name).executes(c -> {
            pRays = rays; pBloom = bloom; pVibrance = vib; pShadows = shadows; pWater = water; pHaze = haze;
            saveCfg();
            SkyMusicClient.msg("Shader preset: " + name);
            return 1; });
    }

    public static LiteralArgumentBuilder<FabricClientCommandSource> node() {
        LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("fx");
        for (Mode m : Mode.values())
            root.then(ClientCommandManager.literal(m.name().toLowerCase()).executes(c -> {
                mode = m; failed = false; saveCfg();
                SkyMusicClient.msg("Post effect: " + m.name().toLowerCase() + (m == Mode.AUTO ? " (off at the lowest performance steps)" : ""));
                return 1; }));
        root.then(gain("rays", "God rays", v -> pRays = v));
        root.then(gain("bloom", "Bloom", v -> pBloom = v));
        root.then(gain("vibrance", "Vibrance", v -> pVibrance = v));
        root.then(gain("shadows", "Sun shading / contact shadows", v -> pShadows = v));
        root.then(gain("water", "Water shine (fake reflections)", v -> pWater = v));
        root.then(gain("haze", "Atmosphere haze", v -> pHaze = v));
        root.then(ClientCommandManager.literal("preset")
            .then(preset("lite", 80, 70, 100, 0, 100, 70))          // cheapest: no contact shadows
            .then(preset("default", 100, 100, 100, 100, 100, 100))
            .then(preset("vivid", 150, 130, 140, 100, 100, 100)));
        root.then(ClientCommandManager.literal("status").executes(c -> {
            SkyMusicClient.msg("shader=" + mode.name().toLowerCase() + (failed ? " (FAILED, see log)" : "")
                + ", quality=" + Perf.skyQuality + "/2, rays=" + pRays + "%, bloom=" + pBloom + "%, vibrance=" + pVibrance
                + "%, shadows=" + pShadows + "%" + (Perf.skyQuality < 1 ? " (needs quality 1+)" : "")
                + ", water=" + pWater + "%, haze=" + pHaze + "%");
            return 1; }));
        return root;
    }
}
