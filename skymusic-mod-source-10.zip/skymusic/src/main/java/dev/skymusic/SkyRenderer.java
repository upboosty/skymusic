package dev.skymusic;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Giant Apple-Music-style lyrics floating in the sky.
 *
 * Look: bold baked font (one atlas texture), every word starts dim and lights up as it is sung (soft glow, tiny lift),
 * lines spring in from below, then defocus (blur), dim and drift up when they are done.
 *
 * Speed: the whole lyric text is ONE batch of textured quads (one texture, one draw call). The old version drew every
 * letter through the vanilla font renderer, which switches glyph textures all the time and made hundreds of draw calls per frame.
 * Each lyric line is a flat sign in the world, drawn in the WORLD pass with the depth buffer on, so it behaves like an entity / block:
 * trees, houses and hills hide it when they are in front of it. New lines are born close to you, on the left or right side, a bit above
 * your crosshair, and if a building is in the way they are born in front of it. (F1 still hides them.)
 * Letters that are not in the atlas fall back to the vanilla font.
 */
public class SkyRenderer {
    public static volatile boolean customFont = true;
    /** 0 = never, 1 = always, 2 = auto: a small plain subtitle only while the sky lyrics are out of view */
    public static volatile int subtitleMode = 2;
    public static volatile String status = "not rendered yet";
    /** /sky size <percent>: size of the lyric lines (1 = default) */
    public static volatile float SIZE = 1f;

    private static final float ROW_GAP = 26f;       // layout px between rows (the layout thinks in a 20 px font)
    private static final float BASE = 6f;           // baseline is this far below the visual middle of a row
    private static final float SPACE_W = 7.4f;      // width of a space
    private static final float LEG = 2.1f;          // vanilla font (8 px) -> layout px, for letters the atlas does not have
    private static final float MAX_SCALE = 0.30f;   // world units per layout px (short lines)
    private static final float TARGET_W = 44f;      // max line width in blocks
    private static final double DIST = 70;          // radius of the lyric dome (blocks)
    public static volatile float ELEV = 0.45f;       // elevation of the lyric block centre in radians (~26 degrees up), /sky height <deg>
    private static boolean anchored = false;
    private static boolean errorShown = false;

    // camera matrices captured at the end of the world render, used by the HUD pass
    private static final Matrix4f VP = new Matrix4f();
    private static boolean haveVP = false;
    private static float camYaw = 0, camPitch = 0;
    private static double camX = 0, camY = 0, camZ = 0;
    private static float scrW = 1, scrH = 1;

    public static void init() {
        LyricFont.load();
        WorldRenderEvents.LAST.register(SkyRenderer::worldPass);       // the lyrics are drawn here, with the depth buffer
        HudRenderCallback.EVENT.register(SkyRenderer::renderHud);      // only the small subtitle is drawn here
    }

    public static void recheckFont() { LAYOUTS.clear(); }

    private static final Matrix4f WORLD_M = new Matrix4f();             // camera rotation of this frame: camera-relative world -> eye space
    private static float tanHX = 1.5f, tanHY = 0.7f;                    // tangent of the half field of view (horizontal / vertical)

    private static void capture(WorldRenderContext ctx) {
        Matrix4f proj = ctx.projectionMatrix();
        WORLD_M.set(ctx.matrixStack().peek().getPositionMatrix());
        VP.set(proj).mul(WORLD_M);
        camYaw = ctx.camera().getYaw();
        camPitch = ctx.camera().getPitch();
        camX = ctx.camera().getPos().x; camY = ctx.camera().getPos().y; camZ = ctx.camera().getPos().z;
        float m00 = Math.abs(proj.m00()), m11 = Math.abs(proj.m11());
        if (m00 > 1e-4f && m11 > 1e-4f) { tanHX = 1f / m00; tanHY = 1f / m11; }
        haveVP = true;
    }

    private static boolean useAtlas() { return customFont && LyricFont.ok; }

    // ---------- layout of one lyric line ----------
    /** one animated piece of a line: a short word, or a part of a long word */
    private static final class Seg {
        float x, w;                 // start and width inside its row (layout px)
        float f0, f1;               // the share of the line's sweep during which it lights up (0..1)
        int idx, n;                 // running number in the line, number of letters
        int base;                   // number of the first letter of this piece in the whole line (for the jelly wave)
        boolean legacy;             // contains letters the atlas does not have -> vanilla font
        int[] cp; float[] gx;       // atlas glyphs: code points and pen x from the segment start
        OrderedText ot; float lw;   // vanilla: the text and its vanilla width
    }
    private static final class Layout {
        Seg[][] segs; float[] rowW; int rows; float maxW = 1f; int total = 1;
    }

    // layouts are cached by text; the carousel draws up to four lines at once
    private static final java.util.HashMap<String, Layout> LAYOUTS = new java.util.HashMap<>();
    private static boolean layoutAtlas = true;
    private static Layout layoutFor(String text, TextRenderer tr, boolean atlas) {
        if (atlas != layoutAtlas || LAYOUTS.size() > 64) { LAYOUTS.clear(); layoutAtlas = atlas; }
        Layout l = LAYOUTS.get(text);
        if (l == null) { l = build(text, tr, atlas); LAYOUTS.put(text, l); }
        return l;
    }

    private static Layout build(String text, TextRenderer tr, boolean atlas) {
        String[] rows = wrap(text);
        Layout L = new Layout();
        L.rows = rows.length;
        L.segs = new Seg[rows.length][];
        L.rowW = new float[rows.length];
        List<Seg> all = new ArrayList<>();
        int total = 0;
        for (int r = 0; r < rows.length; r++) {
            List<Seg> list = new ArrayList<>();
            float cx = 0;
            boolean first = true;
            for (String word : rows[r].trim().split("\\s+")) {
                if (word.isEmpty()) continue;
                if (!first) cx += SPACE_W;
                first = false;
                int[] cps = word.codePoints().toArray();
                int pieces = cps.length > 6 ? (int) Math.ceil(cps.length / 4.0) : 1;     // long words light up in parts
                int per = (int) Math.ceil(cps.length / (double) pieces);
                for (int a = 0; a < cps.length; a += per) {
                    int b = Math.min(cps.length, a + per);
                    Seg s = new Seg();
                    s.x = cx; s.n = b - a;
                    boolean okAtlas = atlas;
                    for (int k = a; k < b && okAtlas; k++) {
                        LyricFont.Glyph g = LyricFont.get(cps[k]);
                        if (g == null || !g.has[0]) okAtlas = false;
                    }
                    if (okAtlas) {
                        s.cp = Arrays.copyOfRange(cps, a, b);
                        s.gx = new float[s.n];
                        float px = 0;
                        for (int k = 0; k < s.n; k++) { s.gx[k] = px; px += LyricFont.get(s.cp[k]).adv; }
                        s.w = px;
                    } else {
                        s.legacy = true;
                        Text t = Text.literal(new String(cps, a, b - a));
                        s.ot = t.asOrderedText();
                        s.lw = tr.getWidth(t);
                        s.w = s.lw * LEG;
                    }
                    cx += s.w;
                    list.add(s); all.add(s); total += s.n;
                }
            }
            L.segs[r] = list.toArray(new Seg[0]);
            L.rowW[r] = cx;
            L.maxW = Math.max(L.maxW, cx);
        }
        float acc = 0; int i = 0;
        for (Seg s : all) {                                   // when each piece lights up: longer pieces take longer
            s.f0 = acc / Math.max(1, total);
            s.base = (int) acc;
            acc += s.n;
            s.f1 = acc / Math.max(1, total);
            s.idx = i++;
        }
        L.total = Math.max(1, total);
        return L;
    }

    private static String[] wrap(String s) {
        s = s.trim();
        int len = s.codePointCount(0, s.length());
        int k = Math.min(5, Math.max(1, (int) Math.ceil(len / 21.0)));
        if (k == 1) return new String[]{s};
        String[] words = s.split("\\s+");
        int target = (int) Math.ceil(len / (double) k);
        List<String> rows = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : words) {
            if (cur.length() > 0 && cur.length() + 1 + w.length() > target && rows.size() < k - 1) {
                rows.add(cur.toString()); cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        rows.add(cur.toString());
        return rows.toArray(new String[0]);
    }

    // ---------- helpers ----------
    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static float easeOutCubic(float x) { float u = 1f - x; return 1f - u * u * u; }
    private static float smooth(float x) { return x * x * (3f - 2f * x); }
    private static float lerp(float a, float b, float f) { return a + (b - a) * f; }
    private static float wrapDeg(float d) { return ((d % 360f) + 540f) % 360f - 180f; }
    private static int rgb(float r, float g, float b, int a) {
        return (a << 24) | ((int) (clamp01(r) * 255) << 16) | ((int) (clamp01(g) * 255) << 8) | (int) (clamp01(b) * 255);
    }
    /** underdamped spring 0 -> 1 (t in seconds): slides in and overshoots by about 8% before it settles */
    private static float spring(float t) {
        if (t <= 0f) return 0f;
        if (t > 1.6f) return 1f;
        double z = 0.62, w = 11.0, wd = w * Math.sqrt(1.0 - z * z), k = z * w;
        return (float) (1.0 - Math.exp(-k * t) * (Math.cos(wd * t) + (k / wd) * Math.sin(wd * t)));
    }

    // ---------- jelly motion ----------
    private static final double ENTER_Z = 0.40, ENTER_W = 14.0;     // springy entrance of every letter (damping ratio, rad/s)
    private static final float ENTER_DROP = 22f;                    // letters fly up from this far below (layout px)
    private static final float ENTER_VN = (float) peakVel(ENTER_Z, ENTER_W);
    private static double animSecs = 0;
    private static float sPos, sVel;                                // result of springPV()

    private static double peakVel(double z, double w) {
        double wd = w * Math.sqrt(1.0 - z * z), k = z * w, t = Math.atan(wd / k) / wd;
        return w * w / wd * Math.exp(-k * t) * Math.sin(wd * t);
    }

    /** underdamped spring 0 -> 1 with its own damping ratio z and frequency w; sPos = position, sVel = velocity (1/s) */
    private static void springPV(float t, double z, double w) {
        if (t <= 0f) { sPos = 0f; sVel = 0f; return; }
        double wd = w * Math.sqrt(1.0 - z * z), k = z * w;
        if (t > 9.0 / k) { sPos = 1f; sVel = 0f; return; }
        double e = Math.exp(-k * t), c = Math.cos(wd * t), sn = Math.sin(wd * t);
        sPos = (float) (1.0 - e * (c + (k / wd) * sn));
        sVel = (float) (e * (w * w / wd) * sn);
    }

    /** damped jelly shake: starts at 0 without a jolt, about 0.7 at the first swing, gone after ~1 s */
    private static float wobble(float t) {
        if (t <= 0f || t > 1.7f) return 0f;
        float ramp = t >= 0.04f ? 1f : smooth(t / 0.04f);
        return ramp * (float) (Math.exp(-5.2 * t) * Math.sin(21.0 * t));
    }

    /** the sideways part of the shake (slower, so it does not move in lock step with the squash) */
    private static float sway(float t) {
        if (t <= 0f || t > 1.7f) return 0f;
        float ramp = t >= 0.05f ? 1f : smooth(t / 0.05f);
        return ramp * (float) (Math.exp(-4.6 * t) * Math.sin(17.0 * t));
    }

    // what letterMotion() hands back: scale, lean (sideways shift of the top per unit of height), vertical offset (down = +), opacity
    private static float mSx, mSy, mLean, mOff, mA;

    /**
     * Jelly motion of one letter. gi / total = its number in the line (the wave runs along the line), tIn = seconds since the line
     * was born, onset = when this letter is sung, sl = how far it has left (0..1), p = how sung it is (0..1), dimK = line dimming.
     * Entrance: springs up from below, stretches while it flies and squashes when it lands. Sung: hops up and shakes like jelly.
     * Leaving: stretches a little while it drifts up. Lit letters breathe very slightly.
     */
    private static void letterMotion(int gi, int total, float tIn, float onset, float sl, float p, float dimK) {
        float stag = Math.min(0.026f, 0.38f / Math.max(1, total));
        float te = tIn - gi * stag;
        springPV(te, ENTER_Z, ENTER_W);
        float e = sPos, v = sVel / ENTER_VN;
        if (v < 0f) v *= 2.4f;                                 // the way back down is slower: exaggerate it so the landing really squashes
        float sy = 1f + 0.26f * v, sx = 1f - 0.17f * v;
        float off = (1f - e) * ENTER_DROP;
        mA = smooth(clamp01(te / 0.20f));

        float ts = tIn - onset;
        float wv = wobble(ts);
        sy *= 1f + 0.20f * wv;  sx *= 1f - 0.13f * wv;
        mLean = ((gi & 1) == 0 ? 1f : -1f) * 0.12f * sway(ts);
        springPV(ts, 0.50, 15.0);
        off -= 3.2f * sPos;                                    // sung letters hop up a little and settle with a bounce

        float ev = (float) Math.sin(Math.PI * sl);             // leaving: stretch while drifting up
        sy *= 1f + 0.14f * ev;  sx *= 1f - 0.09f * ev;
        off -= sl * 5f;

        float idleK = p * (1f - dimK) * (1f - sl) * mA;        // lit letters breathe, just barely
        sy *= 1f + 0.014f * (float) Math.sin(animSecs * 3.4 + gi * 0.65) * idleK;
        sx *= 1f - 0.009f * (float) Math.sin(animSecs * 3.4 + gi * 0.65) * idleK;
        off += 0.5f * (float) Math.sin(animSecs * 2.3 + gi * 0.9) * idleK;
        mSx = sx; mSy = sy; mOff = off;
    }

    private static float scaleOf(Layout L) { return Math.min(Math.min(MAX_SCALE, TARGET_W / L.maxW), 22f / (L.rows * ROW_GAP)) * SIZE; }
    private static float heightOf(Layout L, float mult) { return L.rows * ROW_GAP * scaleOf(L) * mult; }

    // ---------- projection ----------
    private static final Vector4f V4 = new Vector4f();
    private static final float[] PC = new float[2];
    private static final Matrix4f AFF = new Matrix4f(), MT = new Matrix4f();

    /** world point (relative to the camera) -> GUI-scaled screen coordinates; false if behind the camera */
    private static boolean project(double x, double y, double z, float[] out) {
        V4.set((float) x, (float) y, (float) z, 1f);
        VP.transform(V4);
        if (V4.w <= 0.05f) return false;
        out[0] = (V4.x / V4.w * 0.5f + 0.5f) * scrW;
        out[1] = (0.5f - V4.y / V4.w * 0.5f) * scrH;
        return true;
    }

    // the plane of the sign being drawn, in clip space: point(x, y) = C0 + x * CX + y * CY  (x right, y down, in layout px)
    private static float c0x, c0y, c0w, cxx, cxy, cxw, cyx, cyy, cyw;
    private static float SX, SY;
    // the same plane in camera-relative world coordinates: point(x, y) = O + x * (prx, 0, prz) + y * (0, puy, 0)
    private static float pox, poy, poz, prx, prz, puy, pnx, pnz;

    private static void setPlane(double rx, double ry, double rz, float rightX, float rightZ, float s) {
        pox = (float) rx; poy = (float) ry; poz = (float) rz;
        prx = rightX * s; prz = rightZ * s; puy = -s;
        pnx = -rightZ * s; pnz = rightX * s;              // normal of the sign, pointing to the side it faces (toward you when it was born)
        V4.set((float) rx, (float) ry, (float) rz, 1f); VP.transform(V4); c0x = V4.x; c0y = V4.y; c0w = V4.w;
        V4.set(rightX * s, 0f, rightZ * s, 0f); VP.transform(V4); cxx = V4.x; cxy = V4.y; cxw = V4.w;
        V4.set(0f, -s, 0f, 0f); VP.transform(V4); cyx = V4.x; cyy = V4.y; cyw = V4.w;
    }

    /** sign plane point -> GUI screen coordinates in SX, SY; false if behind the camera */
    private static boolean sp(float x, float y) {
        float w = c0w + x * cxw + y * cyw;
        if (w <= 0.05f) return false;
        float inv = 1f / w;
        SX = ((c0x + x * cxx + y * cyx) * inv * 0.5f + 0.5f) * scrW;
        SY = (0.5f - (c0y + x * cxy + y * cyy) * inv * 0.5f) * scrH;
        return true;
    }

    // ---------- the one textured batch ----------
    private static BufferBuilder buf;
    private static boolean begun = false;
    private static int drawn = 0;

    private static void beginAtlas() {
        RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
        RenderSystem.setShaderTexture(0, LyricFont.TEX);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();                  // the text is a real object in the world: blocks and entities in front of it hide it
        RenderSystem.depthFunc(515);                     // GL_LEQUAL
        RenderSystem.depthMask(false);                   // but it does not write depth itself (soft, glowing, overlapping glyph layers)
        RenderSystem.disableCull();
        buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        begun = true;
    }

    private static void endAtlas() {
        if (!begun) return;
        begun = false;
        try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch (Throwable ignored) { }
        restoreWorldState();
    }

    /** the state the world renderer expects after us */
    private static void restoreWorldState() {
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
    }

    private static final float[] QX = new float[4], QY = new float[4];     // screen position of the corners (only used to skip off-screen glyphs)
    private static final float[] QLX = new float[4], QLY = new float[4];   // the same corners on the sign plane (layout px)

    /**
     * One glyph quad of variant vi (0 sharp, 1 soft, 2 glow). pen = pen x and base = baseline y on the sign plane (already including the
     * letter's own bounce), pvx = x of the letter's foot (middle of its advance). The letter is squashed / stretched by sx, sy about its
     * foot (so it stays planted like jelly), lean shifts the top sideways, dy = extra offset down (shadow).
     */
    private static void glyphQuad(LyricFont.Glyph g, int vi, float pen, float base, float pvx, float sx, float sy, float lean,
                                  float r, float gr, float b, float a, float dy) {
        if (a < 0.012f || !g.has[vi]) return;
        float l = pen + g.ox[vi], t = base + g.oy[vi], rr = l + g.w[vi], bb = t + g.h[vi];
        l = pvx + (l - pvx) * sx; rr = pvx + (rr - pvx) * sx;
        t = base + (t - base) * sy; bb = base + (bb - base) * sy;
        float lt = lean * (base - t), lb = lean * (base - bb);          // the top leans, the foot stays
        t += dy; bb += dy;
        QLX[0] = l + lt;  QLY[0] = t;
        QLX[1] = l + lb;  QLY[1] = bb;
        QLX[2] = rr + lb; QLY[2] = bb;
        QLX[3] = rr + lt; QLY[3] = t;
        for (int q = 0; q < 4; q++) { if (!sp(QLX[q], QLY[q])) return; QX[q] = SX; QY[q] = SY; }
        float minX = Math.min(Math.min(QX[0], QX[1]), Math.min(QX[2], QX[3])), maxX = Math.max(Math.max(QX[0], QX[1]), Math.max(QX[2], QX[3]));
        float minY = Math.min(Math.min(QY[0], QY[1]), Math.min(QY[2], QY[3])), maxY = Math.max(Math.max(QY[0], QY[1]), Math.max(QY[2], QY[3]));
        if (maxX < -scrW * 0.1f || minX > scrW * 1.1f || maxY < -scrH * 0.1f || minY > scrH * 1.1f) return;
        if (!begun) beginAtlas();
        float u0 = g.u0[vi], v0 = g.v0[vi], u1 = g.u1[vi], v1 = g.v1[vi];
        buf.vertex(WORLD_M, pox + QLX[0] * prx, poy + QLY[0] * puy, poz + QLX[0] * prz).texture(u0, v0).color(r, gr, b, a).next();
        buf.vertex(WORLD_M, pox + QLX[1] * prx, poy + QLY[1] * puy, poz + QLX[1] * prz).texture(u0, v1).color(r, gr, b, a).next();
        buf.vertex(WORLD_M, pox + QLX[2] * prx, poy + QLY[2] * puy, poz + QLX[2] * prz).texture(u1, v1).color(r, gr, b, a).next();
        buf.vertex(WORLD_M, pox + QLX[3] * prx, poy + QLY[3] * puy, poz + QLX[3] * prz).texture(u1, v0).color(r, gr, b, a).next();
        drawn++;
    }


    // vanilla-font text (letters the atlas does not have) goes through its own little buffer, drawn right after the atlas batch
    private static VertexConsumerProvider.Immediate legacyVc = null;
    private static boolean legacyUsed = false;
    private static VertexConsumerProvider.Immediate legacyVc() {
        if (legacyVc == null) legacyVc = VertexConsumerProvider.immediate(new BufferBuilder(2048));
        return legacyVc;
    }

    // ---------- main ----------
    private static final long T0 = System.nanoTime();
    private static long lastNanos = T0;
    private static float dt = 0.016f;

    // Every lyric line is born close to you, on the LEFT or RIGHT side of your view (randomly switching), a little above your crosshair.
    // It faces you when it is born and then stays exactly there (position and rotation), like an entity: blocks in front of it hide it.
    private static final float Z_MIN = 5.5f, Z_MAX = 9f;         // blocks in front of you (depth along your view direction) when it is born
    private static final float SIDE_GAP = 0.14f;                 // the middle of the screen this wide (0..1 of half the screen) stays clear of text
    private static final float EDGE_X = 0.96f, EDGE_Y = 0.90f;   // the text stays inside this part of the screen
    private static final float UP_MIN = 0.06f, UP_RANGE = 0.40f; // the bottom of the text starts this far above the crosshair; the centre may go this much higher
    private static final float SIDE_FLIP = 0.75f;                // chance that the next line is born on the other side (never 3 in a row on one side)
    private static final float STAND_OFF = 1.0f;                 // if a wall / tree is in the way the text is born this many blocks in front of it
    private static final float R_FLOOR = 2.6f;                   // ... but never closer to you than this
    private static final float LEAVE_T = 0.85f;                  // seconds a line needs to drift away
    private static int lastSide = 1, sideRun = 1;                // side (+1 right, -1 left) of the last line, and how many in a row

    private static final class Anchor { double x, y, z; float face; float hwB, hhB, k; }
    private static final java.util.HashMap<Integer, Anchor> ANCH = new java.util.HashMap<>();
    private static Lrc lastLrc = null;
    // song end: the last lines still play their leaving animation instead of vanishing
    private static boolean playing = false, ending = false;
    private static double lastT = 0, forceLeave = Double.MAX_VALUE;
    private static long endNs = 0;
    private static Lrc endLrc = null;
    private static int frameNo = 0;
    private static java.util.Random rng = new java.util.Random();
    private static String lastTitle = null, titleText = "♪", titlePlain = "♪";

    // per-frame context
    private static Lrc ctxLrc;
    // result of chunkInfo()
    private static double cTime, cSweep, cLeave;

    private static volatile String subText = null;            // the small plain subtitle for this frame (set by the world pass, drawn by the HUD pass)

    /** World pass (after everything else is drawn, before the post effect): the lyrics are drawn here, depth-tested against the world. */
    private static void worldPass(WorldRenderContext ctx) {
        subText = null;
        capture(ctx);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || !haveVP) { playing = false; ending = false; return; }
        long now = System.nanoTime();
        dt = Math.max(0.0005f, Math.min(0.05f, (now - lastNanos) / 1e9f));
        lastNanos = now;
        double t = SkyMusicClient.PLAYER.getTime();
        boolean fin = false;
        if (t >= 0) { playing = true; ending = false; lastT = t; endLrc = SkyMusicClient.lyrics; }
        else {
            if (playing) { playing = false; ending = true; endNs = now; }     // the song just ended (or was stopped)
            if (ending) {
                double el = (now - endNs) / 1e9;
                if (el > 1.9) ending = false; else { fin = true; t = lastT + el; }
            }
            if (!fin) { anchored = false; status = "no song playing"; return; }
        }
        if (mc.options.hudHidden) { status = "hidden (F1)"; return; }          // lyrics are part of the HUD: F1 hides them
        try {
            scrW = mc.getWindow().getScaledWidth();
            scrH = mc.getWindow().getScaledHeight();
            forceLeave = fin ? lastT : Double.MAX_VALUE;           // everything still on screen leaves now
            renderLyrics(mc, t, fin ? endLrc : SkyMusicClient.lyrics);
        } catch (Throwable e) {
            endAtlas();
            restoreWorldState();
            status = "error: " + e;
            if (!errorShown) { errorShown = true; SkyMusicClient.msg("Lyrics error (please report): " + e); }
        }
    }

    /** HUD pass: only the small plain subtitle (when you are not looking at the lyrics in the world). */
    private static void renderHud(DrawContext dc, float tickDelta) {
        String sub = subText;
        if (sub == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        dc.drawCenteredTextWithShadow(mc.textRenderer, Text.literal(sub), (int) (mc.getWindow().getScaledWidth() / 2f), (int) (mc.getWindow().getScaledHeight() * 0.12f), 0xFFFFFF);
    }

    /** chunk 0 = title card, chunk n = lyric line n-1 */
    private static String itemText(int c) {
        if (c == 0) return titleText;
        String s = ctxLrc.lines.get(c - 1).text();
        return s.isEmpty() ? "♪  ♫  ♪" : s;
    }

    /** when chunk c starts, how long its words take to light up and when it starts to leave (seconds of song time). false = not shown. */
    private static boolean chunkInfo(int c, int nLines) {
        String tx = itemText(c);
        int len = tx.codePointCount(0, tx.length());
        if (c == 0) {
            double first = ctxLrc != null ? ctxLrc.lines.get(0).time() : 7.0;
            if (ctxLrc != null && first < 1.2) return false;          // lyrics start right away, no room for a title card
            cTime = 0;
            cSweep = Math.max(0.6, Math.min(first * 0.7, 1.6));
            cLeave = Math.min(Math.min(first, cSweep + 3.5), forceLeave);
            return true;
        }
        Lrc.Line ln = ctxLrc.lines.get(c - 1);
        double next = c < nLines ? ctxLrc.lines.get(c).time() : ln.time() + 5.0;
        double gap = Math.max(0.3, next - ln.time());
        cTime = ln.time();
        // the words light up across the time the line is sung (the gap to the next line), but a short line in a long gap does not drag
        cSweep = Math.max(0.45, Math.min(gap * 0.88, Math.max(len * 0.09, 0.9)));
        cLeave = Math.min(cTime + Math.max(0.8, Math.min(gap, cSweep + 2.8)), forceLeave);   // leaves when the next line comes, or a bit after it was sung
        return true;
    }

    /** distance in degrees between two rectangles (negative = overlapping) */
    private static float rectSep(float y, float e, float hw, float hh, float oy, float oe, float ohw, float ohh) {
        return Math.max(Math.abs(y - oy) - (hw + ohw), Math.abs(e - oe) - (hh + ohh));
    }

    /** how far (degrees, as seen from where you stand now) a candidate spot is from an earlier line; large if that line is far away */
    private static float sepToAnchor(Anchor p, float y, float e, float hwD, float hhD) {
        if (p == null) return 99f;
        double dx = p.x - camX, dy = p.y - camY, dz = p.z - camZ;
        double dist = Math.max(0.5, Math.sqrt(dx * dx + dy * dy + dz * dz));
        float elAbs = (float) Math.toDegrees(Math.asin(dy / dist));
        float yawRel = wrapDeg((float) Math.toDegrees(Math.atan2(-dx, dz)) - camYaw) * (float) Math.cos(Math.toRadians(elAbs));
        float elRel = elAbs - (-camPitch);
        float hw = (float) Math.toDegrees(Math.atan(p.hwB / dist)), hh = (float) Math.toDegrees(Math.atan(p.hhB / dist));
        return rectSep(y, e, hwD, hhD, yawRel, elRel, hw, hh);
    }

    private static boolean solidAt(MinecraftClient mc, BlockPos pos) {
        net.minecraft.block.BlockState st = mc.world.getBlockState(pos);
        if (st.isAir()) return false;
        return !st.getCollisionShape(mc.world, pos).isEmpty() || !st.getFluidState().isEmpty();   // stone, trees, leaves, water ... not grass or flowers
    }

    /** how many spots of the sign (centre ax,ay,az, facing angle face) lie inside blocks (coarse grid: this runs when a line is born) */
    private static int solidHits(MinecraftClient mc, double ax, double ay, double az, float hw, float hh, float face) {
        if (mc.world == null) return 0;
        float rx = (float) Math.sin(face), rz = (float) -Math.cos(face);
        float nx = (float) Math.cos(face), nz = (float) Math.sin(face);
        int nw = Math.max(1, Math.min(4, (int) Math.ceil(hw / 1.8f))), nh = Math.max(1, Math.min(2, (int) Math.ceil(hh / 1.8f)));
        BlockPos.Mutable bp = new BlockPos.Mutable();
        int hits = 0;
        for (int i = -nw; i <= nw; i++)
            for (int j = -nh; j <= nh; j++)
                for (int d = -1; d <= 1; d++) {
                    double u = i * hw / nw, py = ay + j * hh / nh;
                    bp.set(ax + rx * u + nx * d * 0.6, py, az + rz * u + nz * d * 0.6);
                    if (solidAt(mc, bp) && ++hits >= 4) return hits;
                }
        return hits;
    }

    /** distance from a along the way to b to the first solid block, or -1 if the way is free (grass and flowers do not count) */
    private static double rayHit(MinecraftClient mc, Vec3d from, Vec3d to) {
        BlockHitResult h = mc.world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return h.getType() == HitResult.Type.MISS ? -1.0 : h.getPos().distanceTo(from);
    }

    /** is the point (x, y, z) hidden from the camera by a block? */
    private static boolean hiddenFrom(MinecraftClient mc, Vec3d cam, double x, double y, double z) {
        Vec3d p = new Vec3d(x, y, z);
        double d = rayHit(mc, cam, p);
        return d >= 0 && d < cam.distanceTo(p) - 0.35;
    }

    /**
     * The fixed place in the world where chunk c lives; picked the first time it is needed:
     *  - close to you (about 5.5 - 9 blocks ahead), on the left or right side of your view (randomly switching sides, never 3 in a row),
     *    a little above your crosshair, so it is never straight in front of you and you do not need to look up;
     *  - if a wall, tree or hill is in the way it is born closer, in front of it (same spot on your screen, just nearer and smaller);
     *  - the first spots that are free of blocks and not hidden win; otherwise the least bad one, and from the other side too.
     * It faces you when it is born and never turns after that. Because it is drawn with the depth buffer it can be hidden by
     * blocks later if you walk around.
     */
    private static Anchor anchorFor(MinecraftClient mc, int c, Layout L, float bias) {
        Anchor a = ANCH.get(c);
        if (a != null) return a;
        double feetY = mc.player.getY();
        Anchor p1 = ANCH.get(c - 1), p2 = ANCH.get(c - 2);
        Vec3d cam = new Vec3d(camX, camY, camZ);

        // camera axes (yaw 0 looks along +z, positive pitch looks down)
        double yr = Math.toRadians(camYaw), pr = Math.toRadians(camPitch);
        double cp = Math.cos(pr), sinP = Math.sin(pr);
        double fx = -Math.sin(yr) * cp, fy = -sinP, fz = Math.cos(yr) * cp;       // forward
        double rx = -Math.cos(yr), rz = -Math.sin(yr);                            // right (no vertical part)
        double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;               // up = right x forward

        float nyShift = (float) (Math.tan(Math.toRadians(bias)) / tanHY);          // /sky height moves the text up or down a bit
        int want = (sideRun >= 2 || rng.nextFloat() < SIDE_FLIP) ? -lastSide : lastSide;

        double bx = camX + fx * 6, by = camY + fy * 6, bz = camZ + fz * 6;
        float bk = 6f / (float) DIST, bhw = 2f, bhh = 1f, bface = 0f, bScore = -1e9f;
        int bSide = want;
        for (int tries = 0; tries < 30; tries++) {
            int sd = tries < 18 ? want : -want;                                    // the other side only if this side is full of blocks
            float z = Z_MIN + rng.nextFloat() * (Z_MAX - Z_MIN);                   // depth in front of you
            // size of the text on your screen does not depend on how far away it is; estimate it first to know how far to the side it must sit
            float kg = z * 1.3f / (float) DIST;
            float hwg = L.maxW * scaleOf(L) * kg * 0.5f * 1.15f + 0.4f, hhg = heightOf(L, 1f) * kg * 0.5f * 1.15f + 0.3f;
            float nhw = hwg / (z * tanHX), nhh = hhg / (z * tanHY);                // half size on the screen (0..1 = middle .. edge)
            float fit = 1f, room = EDGE_X - SIDE_GAP;
            if (2f * nhw > room) fit = Math.max(0.5f, room / (2f * nhw));          // very long line: make it a bit smaller so it fits beside the crosshair
            nhw *= fit; nhh *= fit;
            float xLo = SIDE_GAP + nhw, xHi = Math.max(xLo, EDGE_X - nhw);
            float nx = sd * (xLo + rng.nextFloat() * (xHi - xLo));
            float yLo = UP_MIN + nhh + nyShift, yHi = Math.min(EDGE_Y - nhh, yLo + UP_RANGE);
            if (yHi < yLo) yLo = yHi;
            float ny = yLo + rng.nextFloat() * (yHi - yLo);
            ny = Math.max(-EDGE_Y + nhh, Math.min(EDGE_Y - nhh, ny));

            // the point at that spot of your screen, z blocks in front of you
            double dx = fx + nx * tanHX * rx + ny * tanHY * ux;
            double dy = fy + ny * tanHY * uy;
            double dz = fz + nx * tanHX * rz + ny * tanHY * uz;
            double dl = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double R = z * dl;
            double ax = camX + dx * z, ay = camY + dy * z, az = camZ + dz * z;

            // something in the way? then be born in front of it (same direction, so same place on screen, just nearer)
            boolean pulled = false, jammed = false;
            double hd = rayHit(mc, cam, new Vec3d(ax, ay, az));
            if (hd >= 0 && hd < R + 0.6) {
                double R2 = hd - STAND_OFF;
                if (R2 < R_FLOOR) { R2 = R_FLOOR; jammed = true; }
                double q = R2 / R;
                ax = camX + (ax - camX) * q; ay = camY + (ay - camY) * q; az = camZ + (az - camZ) * q;
                R = R2; pulled = true;
            }
            float k = (float) R / (float) DIST * fit;
            float hw = L.maxW * scaleOf(L) * k * 0.5f * 1.15f + 0.4f;
            float hh = heightOf(L, 1f) * k * 0.5f * 1.15f + 0.3f;
            ay = Math.max(ay, feetY + hh + 0.4);                                    // never below the floor you stand on
            float face = (float) Math.atan2(camZ - az, camX - ax);                  // looks at you, for good

            int hits = solidHits(mc, ax, ay, az, hw, hh, face);
            float srx = (float) Math.sin(face), srz = (float) -Math.cos(face);
            int hidden = 0;                                                         // are the left / right / top / bottom of the sign hidden from you?
            if (hiddenFrom(mc, cam, ax + srx * hw * 0.9, ay, az + srz * hw * 0.9)) hidden++;
            if (hiddenFrom(mc, cam, ax - srx * hw * 0.9, ay, az - srz * hw * 0.9)) hidden++;
            if (hiddenFrom(mc, cam, ax, ay + hh * 0.9, az)) hidden++;
            if (hiddenFrom(mc, cam, ax, ay - hh * 0.9, az)) hidden++;

            float yo = (float) Math.toDegrees(Math.atan(nx * tanHX)), eo = (float) Math.toDegrees(Math.atan(ny * tanHY));
            float hwD = (float) Math.toDegrees(Math.atan(hw / R)), hhD = (float) Math.toDegrees(Math.atan(hh / R));
            float sc = Math.min(sepToAnchor(p1, yo, eo, hwD, hhD), sepToAnchor(p2, yo, eo, hwD, hhD));
            sc = Math.min(sc, 20f);
            float score = sc - hits * 30f - hidden * 25f - (jammed ? 60f : 0f) - 2f * Math.max(0f, Z_MIN * 1.3f - (float) R);
            if (sd != want) score -= 3f;
            if (score > bScore) { bScore = score; bx = ax; by = ay; bz = az; bk = k; bhw = hw; bhh = hh; bface = face; bSide = sd; }
            if (hits == 0 && hidden == 0 && !pulled && sc >= 5f) break;
        }
        sideRun = bSide == lastSide ? sideRun + 1 : 1;
        lastSide = bSide;
        a = new Anchor();
        a.x = bx; a.y = by; a.z = bz; a.face = bface; a.k = bk; a.hwB = bhw; a.hhB = bhh;
        ANCH.put(c, a);
        return a;
    }

    private static void renderLyrics(MinecraftClient mc, double t, Lrc lrc) {
        TextRenderer tr = mc.textRenderer;
        boolean atlas = useAtlas();
        boolean hasLyrics = lrc != null && !lrc.lines.isEmpty();
        int nLines = hasLyrics ? lrc.lines.size() : 0;
        drawn = 0;

        String ttl = SkyMusicClient.title;
        if (ttl == null) ttl = "";
        if (!ttl.equals(lastTitle)) {
            lastTitle = ttl;
            titleText = ttl.isEmpty() ? "♪" : "♪  " + ttl;
            titlePlain = ttl.isEmpty() ? "♪" : "♪ " + ttl;
            ANCH.clear();
        }
        Lrc use = hasLyrics ? lrc : null;
        if (use != lastLrc) { lastLrc = use; ANCH.clear(); rng = new java.util.Random(); }
        ctxLrc = use;
        float bias = (float) Math.toDegrees(ELEV - 0.45f);       // /sky height shifts where new lines are born, up or down

        double secs = (System.nanoTime() - T0) / 1e9;
        animSecs = secs;

        int idx = hasLyrics ? lrc.indexAt(t) : -1;
        int cur = idx + 1;
        String plain = null;
        boolean visible = false;                                   // is the line being sung on screen right now?
        for (int c = Math.max(0, cur - 5); c <= cur; c++) {          // oldest first, so the newest chunk is painted on top
            if (!chunkInfo(c, nLines)) continue;
            double tIn = t - cTime;
            double tLeave = t - cLeave;
            if (tIn < 0 || tLeave > LEAVE_T) continue;

            Layout L = layoutFor(itemText(c), tr, atlas);
            Anchor an = anchorFor(mc, c, L, bias);

            float spr = spring((float) tIn);                                     // springs up into place (a little overshoot)
            float ex = clamp01((float) (tLeave / LEAVE_T));
            float exS = smooth(ex);                                              // then drifts up and away ...
            float dimK = smooth(clamp01(ex * 2.2f));                             // ... dimming first,
            float softK = smooth(clamp01((ex - 0.05f) * 1.7f));                  // ... going out of focus,
            float outA = 1f - smooth(clamp01((ex - 0.30f) / 0.70f));             // ... and fading out
            float bob = (float) Math.sin(secs * 0.8 + c * 1.7) * 0.05f;          // barely floating
            float near = Math.max(0.3f, Math.min(1.5f, an.k * (float) DIST / 10f));   // lines born closer to you are smaller: their little movements are too
            double rx = an.x - camX, ry = an.y - camY + (bob - (1f - spr) * 0.30 + exS * 1.25) * near, rz = an.z - camZ;
            float scaleK = (0.90f + 0.10f * spr) * (1f - 0.07f * exS);
            float sBlocks = scaleOf(L) * an.k * scaleK;
            float rightX = (float) Math.sin(an.face), rightZ = (float) -Math.cos(an.face);
            drawChunk(tr, L, rx, ry, rz, rightX, rightZ, sBlocks, (float) tIn, (float) cSweep, (float) tLeave, outA, dimK, softK);
            if (c == cur) {
                plain = c == 0 ? titlePlain : itemText(c);
                visible = project(rx, ry, rz, PC) && PC[0] > scrW * 0.04f && PC[0] < scrW * 0.96f && PC[1] > scrH * 0.04f && PC[1] < scrH * 0.96f;
            }
        }
        endAtlas();                           // all lyric glyphs go out in one draw call
        if (legacyUsed) { legacyUsed = false; legacyVc().draw(); restoreWorldState(); }   // then the vanilla-font fallback text (rare)

        // small plain subtitle when you are not looking at the floating lyrics (or always, /sky subtitle on); drawn later by the HUD pass
        int sm = subtitleMode;
        if (plain != null && (sm == 1 || (sm == 2 && !visible))) subText = plain;
        if ((frameNo++ & 15) == 0)
            status = "playing, t=" + String.format("%.1f", t) + ", quads drawn=" + drawn + ", on screen=" + visible
                + ", font=" + (atlas ? "baked atlas" : (customFont ? "vanilla (atlas missing)" : "vanilla"));
    }

    /**
     * Draws one lyric line as an upright sign in the world. (rx, ry, rz) = its centre relative to the camera, (rightX, rightZ) = which way
     * "right" points, s = blocks per layout px. tIn = seconds since the line started (words light up as it is sung), sweep = seconds the
     * singing of the line takes, tLeave = seconds since it started leaving (negative = not leaving yet), lineA = overall opacity,
     * dimK / softK = how far the line has dimmed / gone out of focus.
     */
    private static void drawChunk(TextRenderer tr, Layout L, double rx, double ry, double rz, float rightX, float rightZ, float s,
                                  float tIn, float sweep, float tLeave, float lineA, float dimK, float softK) {
        if (lineA < 0.01f) return;
        setPlane(rx, ry, rz, rightX, rightZ, s);
        if (c0w <= 0.05f) return;
        float sw = Math.max(0.2f, sweep);
        for (int pass = 0; pass < 2; pass++) {                           // pass 0: soft shadow + glow behind, pass 1: the letters
            for (int r = 0; r < L.rows; r++) {
                float rowY = (r - (L.rows - 1) / 2f) * ROW_GAP;
                float x0 = -L.rowW[r] / 2f;
                for (Seg sg : L.segs[r]) {
                    float p = smooth(clamp01((tIn - sg.f0 * sw) / Math.max(0.16f, (sg.f1 - sg.f0) * sw * 1.25f)));   // 0 = not sung yet, 1 = sung
                    float sl = smooth(clamp01((tLeave - sg.idx * 0.035f) / 0.7f));                                    // leaving, word by word
                    float wordA = lineA * (1f - 0.5f * sl);
                    float bt = clamp01(p * (1f - 0.65f * dimK));                                                      // brightness
                    float cr = lerp(0.74f, 1f, bt), cg = lerp(0.82f, 1f, bt), cb = lerp(0.98f, 0.985f, bt);
                    float segCx = x0 + sg.x + sg.w / 2f;
                    float onset0 = sg.f0 * sw, span = (sg.f1 - sg.f0) * sw * 0.8f;     // the letters of a piece are sung one after the other
                    if (sg.legacy) {                                     // letters the atlas does not have: vanilla font (moves as one piece)
                        if (pass == 0) continue;
                        letterMotion(sg.base, L.total, tIn, onset0, sl, p, dimK);
                        float pcy = rowY + mOff;
                        float sharpA = wordA * mA * (0.42f + 0.58f * bt);
                        if (!sp(segCx, pcy)) continue;                   // behind you
                        int a = (int) (255 * sharpA);
                        if (a < 8) continue;                             // tiny alpha would be treated as opaque by vanilla
                        // vanilla text is laid out in px (x right, y down); this matrix puts those px onto the sign in the world
                        AFF.set(prx, 0f, prz, 0f, 0f, puy, 0f, 0f, pnx, 0f, pnz, 0f,
                                pox + segCx * prx, poy + pcy * puy, poz + segCx * prz, 1f);
                        MT.set(WORLD_M).mul(AFF).scale(LEG * mSx, LEG * mSy, 1f);
                        tr.draw(sg.ot, -sg.lw / 2f, -4f, rgb(cr, cg, cb, a), true, MT, legacyVc(), TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                        legacyUsed = true;
                        drawn++;
                        continue;
                    }
                    for (int i = 0; i < sg.cp.length; i++) {
                        LyricFont.Glyph g = LyricFont.get(sg.cp[i]);
                        letterMotion(sg.base + i, L.total, tIn, onset0 + span * i / Math.max(1, sg.n), sl, p, dimK);
                        float pen = x0 + sg.x + sg.gx[i];
                        float foot = pen + g.adv * 0.5f;                          // the letter stays planted on its own foot
                        float base = rowY + BASE + mOff;
                        float a = wordA * mA;
                        if (pass == 0) {
                            float glowA = a * (0.60f * (float) Math.sin(Math.PI * p) + 0.30f * p * (1f - dimK));
                            float shA = a * 0.34f * (0.6f + 0.4f * bt);
                            glyphQuad(g, 2, pen, base, foot, mSx, mSy, mLean, 0.03f, 0.05f, 0.13f, shA, 1.6f);
                            glyphQuad(g, 2, pen, base, foot, mSx, mSy, mLean, 0.58f, 0.76f, 1f, glowA, 0f);
                        } else {
                            float sharpA = a * (0.42f + 0.58f * bt);
                            glyphQuad(g, 0, pen, base, foot, mSx, mSy, mLean, cr, cg, cb, sharpA * (1f - softK), 0f);
                            if (softK > 0.02f) glyphQuad(g, 1, pen, base, foot, mSx, mSy, mLean, cr, cg, cb, sharpA * softK, 0f);
                        }
                    }
                }
            }
        }
    }
}
