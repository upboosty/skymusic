package dev.skymusic;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * Tags and embedded cover art of a song file. Pure Java (no Minecraft classes), only reads the tag part of the file, never the audio:
 *  - FLAC: VORBIS_COMMENT (title / artist / album) and PICTURE blocks (front cover preferred)
 *  - MP3 (and any file that starts with an ID3v2 tag): TIT2 / TPE1 / TALB / APIC (ID3v2.2, 2.3 and 2.4)
 *  - otherwise a picture next to the song with the same name (song.png / song.jpg)
 */
final class TrackInfo {
    String title, artist, album;
    byte[] picture;          // jpg / png ... bytes of the cover, or null
    int pictureType = -1;    // ID3 / FLAC picture type of the chosen picture (3 = front cover)

    private static final int MAX_BLOCK = 48 << 20;

    static TrackInfo read(Path file, Path songDir) {
        TrackInfo t = new TrackInfo();
        try { t.readTags(file); } catch (Throwable ignored) { }
        if (t.picture == null) {
            try { t.picture = sidecar(file, songDir); } catch (Throwable ignored) { }
        }
        return t;
    }

    private void readTags(Path file) throws IOException {
        try (RandomAccessFile f = new RandomAccessFile(file.toFile(), "r")) {
            long pos = 0;
            byte[] head = new byte[10];
            f.readFully(head);
            if (head[0] == 'I' && head[1] == 'D' && head[2] == '3') {
                int size = synchsafe(head, 6);
                long tagEnd = 10L + size + ((head[5] & 0x10) != 0 ? 10 : 0);
                if (size > 0 && size <= MAX_BLOCK) {
                    byte[] tag = new byte[size];
                    f.seek(10);
                    f.readFully(tag);
                    id3(head, tag);
                }
                pos = tagEnd;
            }
            f.seek(pos);
            byte[] sig = new byte[4];
            if (f.read(sig) == 4 && sig[0] == 'f' && sig[1] == 'L' && sig[2] == 'a' && sig[3] == 'C') flac(f);
        }
    }

    // ---------------------------------------------------------------- FLAC
    private void flac(RandomAccessFile f) throws IOException {
        long len = f.length();
        boolean last = false;
        int guard = 0;
        while (!last && guard++ < 256) {
            int h = f.read();
            if (h < 0) return;
            last = (h & 0x80) != 0;
            int type = h & 0x7F;
            int size = (f.read() << 16) | (f.read() << 8) | f.read();
            long here = f.getFilePointer();
            if (size < 0 || here + size > len) return;
            if ((type == 4 || type == 6) && size <= MAX_BLOCK) {
                byte[] b = new byte[size];
                f.readFully(b);
                if (type == 4) vorbisComment(b);
                else flacPicture(b);
            } else {
                f.seek(here + size);
            }
        }
    }

    private void vorbisComment(byte[] b) {
        ByteBuffer bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN);
        if (bb.remaining() < 8) return;
        int vendor = bb.getInt();
        if (vendor < 0 || vendor > bb.remaining() - 4) return;
        bb.position(bb.position() + vendor);
        int n = bb.getInt();
        String albumArtist = null;
        for (int i = 0; i < n && bb.remaining() >= 4; i++) {
            int l = bb.getInt();
            if (l < 0 || l > bb.remaining()) break;
            String s = new String(b, bb.position(), l, StandardCharsets.UTF_8);
            bb.position(bb.position() + l);
            int eq = s.indexOf('=');
            if (eq <= 0) continue;
            String k = s.substring(0, eq).toUpperCase(Locale.ROOT), v = s.substring(eq + 1).trim();
            if (v.isEmpty()) continue;
            switch (k) {
                case "TITLE" -> { if (title == null) title = v; }
                case "ARTIST" -> { if (artist == null) artist = v; }
                case "ALBUMARTIST" -> albumArtist = v;
                case "ALBUM" -> { if (album == null) album = v; }
                default -> { }
            }
        }
        if (artist == null) artist = albumArtist;
    }

    private void flacPicture(byte[] b) {
        try {
            ByteBuffer bb = ByteBuffer.wrap(b);                       // big endian
            int type = bb.getInt();
            int mimeLen = bb.getInt();
            if (mimeLen < 0 || mimeLen > bb.remaining()) return;
            String mime = new String(b, bb.position(), mimeLen, StandardCharsets.ISO_8859_1);
            bb.position(bb.position() + mimeLen);
            int descLen = bb.getInt();
            if (descLen < 0 || descLen > bb.remaining()) return;
            bb.position(bb.position() + descLen + 16);                // description, width, height, depth, colours
            int dataLen = bb.getInt();
            if (dataLen <= 0 || dataLen > bb.remaining() || mime.equals("-->")) return;
            byte[] data = new byte[dataLen];
            bb.get(data);
            offer(type, data);
        } catch (RuntimeException ignored) { }
    }

    /** keep the best picture: front cover first, then "other", then the first one */
    private void offer(int type, byte[] data) {
        int rank = type == 3 ? 3 : (type == 0 ? 2 : 1);
        int have = pictureType < 0 ? 0 : (pictureType == 3 ? 3 : (pictureType == 0 ? 2 : 1));
        if (picture == null || rank > have) { picture = data; pictureType = type; }
    }

    // ---------------------------------------------------------------- ID3v2
    private static int synchsafe(byte[] b, int o) {
        return ((b[o] & 0x7F) << 21) | ((b[o + 1] & 0x7F) << 14) | ((b[o + 2] & 0x7F) << 7) | (b[o + 3] & 0x7F);
    }

    private void id3(byte[] head, byte[] tag) {
        int ver = head[3] & 0xFF, flags = head[5] & 0xFF;
        if (ver < 2 || ver > 4) return;
        if ((flags & 0x80) != 0 && ver < 4) tag = unsync(tag);              // whole-tag unsynchronisation (2.2 / 2.3)
        int p = 0;
        if (ver >= 3 && (flags & 0x40) != 0 && tag.length >= 4) {         // extended header
            int es = ver == 4 ? synchsafe(tag, 0) : (be32(tag, 0) + 4);
            if (es > 0 && es < tag.length) p = es;
        }
        int idLen = ver == 2 ? 3 : 4, hdr = ver == 2 ? 6 : 10;
        while (p + hdr <= tag.length) {
            if (tag[p] == 0) break;                                        // padding
            String id = new String(tag, p, idLen, StandardCharsets.ISO_8859_1);
            int size = ver == 2 ? ((tag[p + 3] & 0xFF) << 16 | (tag[p + 4] & 0xFF) << 8 | (tag[p + 5] & 0xFF))
                    : (ver == 4 ? synchsafe(tag, p + 4) : be32(tag, p + 4));
            int fl = ver == 2 ? 0 : (tag[p + 8] & 0xFF) << 8 | (tag[p + 9] & 0xFF);
            int bodyStart = p + hdr;
            if (size < 0 || bodyStart + size > tag.length) break;
            byte[] body = java.util.Arrays.copyOfRange(tag, bodyStart, bodyStart + size);
            p = bodyStart + size;
            if (ver == 4) {
                if ((fl & 0x0002) != 0) body = unsync(body);               // per-frame unsynchronisation
                if ((fl & 0x0001) != 0 && body.length > 4) body = java.util.Arrays.copyOfRange(body, 4, body.length);   // data length indicator
                if ((fl & 0x000C) != 0) continue;                          // compressed / encrypted: skip
            } else if (ver == 3 && (fl & 0x00C0) != 0) continue;
            switch (id) {
                case "TIT2", "TT2" -> { String s = text(body); if (s != null && title == null) title = s; }
                case "TPE1", "TP1" -> { String s = text(body); if (s != null && artist == null) artist = s; }
                case "TALB", "TAL" -> { String s = text(body); if (s != null && album == null) album = s; }
                case "APIC" -> apic(body, false);
                case "PIC" -> apic(body, true);
                default -> { }
            }
        }
    }

    private static int be32(byte[] b, int o) {
        return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF);
    }

    private static byte[] unsync(byte[] b) {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(b.length);
        for (int i = 0; i < b.length; i++) {
            o.write(b[i]);
            if ((b[i] & 0xFF) == 0xFF && i + 1 < b.length && b[i + 1] == 0) i++;
        }
        return o.toByteArray();
    }

    private static Charset charset(int enc) {
        return switch (enc) {
            case 1 -> StandardCharsets.UTF_16;                              // with byte order mark
            case 2 -> StandardCharsets.UTF_16BE;
            case 3 -> StandardCharsets.UTF_8;
            default -> StandardCharsets.ISO_8859_1;
        };
    }

    private static String text(byte[] body) {
        if (body.length < 2) return null;
        String s = new String(body, 1, body.length - 1, charset(body[0] & 0xFF));
        int z = s.indexOf('\0');                                           // several values are separated by NUL: take the first
        if (z >= 0) s = s.substring(0, z);
        s = s.trim();
        return s.isEmpty() ? null : s;
    }

    private void apic(byte[] b, boolean v22) {
        if (b.length < 8) return;
        int enc = b[0] & 0xFF, p = 1;
        if (v22) {
            p += 3;                                                        // 3-letter image format ("PNG", "JPG")
        } else {
            while (p < b.length && b[p] != 0) p++;                         // MIME type
            p++;
        }
        if (p >= b.length) return;
        int type = b[p++] & 0xFF;
        boolean wide = enc == 1 || enc == 2;                               // description ends with 00 (or 00 00 for UTF-16)
        if (wide) { while (p + 1 < b.length && !(b[p] == 0 && b[p + 1] == 0)) p += 2; p += 2; }
        else { while (p < b.length && b[p] != 0) p++; p++; }
        if (p >= b.length) return;
        offer(type, java.util.Arrays.copyOfRange(b, p, b.length));
    }

    // ---------------------------------------------------------------- picture next to the song
    private static byte[] sidecar(Path audio, Path dir) throws IOException {
        if (dir == null) return null;
        String n = audio.getFileName().toString();
        int dot = n.lastIndexOf('.');
        String stem = dot < 0 ? n : n.substring(0, dot);
        String want = norm(stem);
        try (Stream<Path> s = Files.list(dir)) {
            List<Path> all = s.filter(p -> {
                String l = p.getFileName().toString().toLowerCase(Locale.ROOT);
                return l.endsWith(".png") || l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".bmp");
            }).toList();
            for (Path p : all) {
                String x = p.getFileName().toString();
                int d = x.lastIndexOf('.');
                if (norm(d < 0 ? x : x.substring(0, d)).equals(want)) {
                    if (Files.size(p) <= MAX_BLOCK) return Files.readAllBytes(p);
                }
            }
        }
        return null;
    }

    private static String norm(String s) { return s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{Nd}]", ""); }
}
