package dev.skymusic;

/**
 * Turns a decoded cover (RGBA bytes) into a small square texture and finds the album colour. Pure Java, runs on the loader thread.
 * Pixels are packed the way Minecraft's NativeImage wants them: 0xAABBGGRR.
 */
final class CoverArt {
    static final int MAX = 192;      // the cover texture is at most this many pixels wide

    int size;
    int[] abgr;
    float[] accent = {0.80f, 0.82f, 1.00f};     // bright album colour (progress bar, glow)
    float[] accent2 = {0.22f, 0.20f, 0.42f};    // deep version of it (placeholder, tint)
    boolean real;

    /** centre-crop to a square and box-filter down to MAX */
    static CoverArt fromRgba(byte[] rgba, int w, int h) {
        if (w < 1 || h < 1 || rgba.length < w * h * 4) throw new IllegalArgumentException("bad image");
        int side = Math.min(w, h), ox = (w - side) / 2, oy = (h - side) / 2;
        int n = Math.min(MAX, side);
        CoverArt c = new CoverArt();
        c.size = n;
        c.abgr = new int[n * n];
        c.real = true;
        for (int y = 0; y < n; y++) {
            int y0 = oy + (int) ((long) y * side / n), y1 = Math.max(y0 + 1, oy + (int) ((long) (y + 1) * side / n));
            for (int x = 0; x < n; x++) {
                int x0 = ox + (int) ((long) x * side / n), x1 = Math.max(x0 + 1, ox + (int) ((long) (x + 1) * side / n));
                long r = 0, g = 0, b = 0;
                int cnt = 0;
                for (int yy = y0; yy < y1; yy++) {
                    int row = (yy * w + x0) * 4;
                    for (int xx = x0; xx < x1; xx++, row += 4) {
                        int a = rgba[row + 3] & 0xFF;                      // transparent parts count as black
                        r += (rgba[row] & 0xFF) * a / 255;
                        g += (rgba[row + 1] & 0xFF) * a / 255;
                        b += (rgba[row + 2] & 0xFF) * a / 255;
                        cnt++;
                    }
                }
                c.abgr[y * n + x] = 0xFF000000 | ((int) (b / cnt) << 16) | ((int) (g / cnt) << 8) | (int) (r / cnt);
            }
        }
        c.findAccent();
        return c;
    }

    /** a nice gradient cover for songs without one; the colours come from the name so a song always gets the same one */
    static CoverArt generated(String seed) {
        int hsh = seed == null ? 7 : seed.hashCode();
        float h1 = ((hsh >>> 3) & 0x3FF) / 1024f;
        float h2 = (h1 + 0.09f + ((hsh >>> 14) & 0xFF) / 255f * 0.10f) % 1f;
        CoverArt c = new CoverArt();
        int n = 96;
        c.size = n;
        c.abgr = new int[n * n];
        float[] a = hsv(h1, 0.62f, 0.62f), b = hsv(h2, 0.75f, 0.20f);
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                float t = (x + y) / (2f * (n - 1));
                float dx = (x - n * 0.32f) / n, dy = (y - n * 0.30f) / n;
                float glow = (float) Math.exp(-(dx * dx + dy * dy) * 9.0) * 0.30f;
                float rr = a[0] + (b[0] - a[0]) * t + glow, gg = a[1] + (b[1] - a[1]) * t + glow, bb = a[2] + (b[2] - a[2]) * t + glow;
                c.abgr[y * n + x] = pack(rr, gg, bb);
            }
        }
        float[] ac = hsv(h1, 0.45f, 1.0f), ac2 = hsv(h1, 0.75f, 0.42f);
        c.accent = ac;
        c.accent2 = ac2;
        return c;
    }

    private static int pack(float r, float g, float b) {
        int ri = Math.max(0, Math.min(255, (int) (r * 255f))), gi = Math.max(0, Math.min(255, (int) (g * 255f))), bi = Math.max(0, Math.min(255, (int) (b * 255f)));
        return 0xFF000000 | (bi << 16) | (gi << 8) | ri;
    }

    static float[] hsv(float h, float s, float v) {
        h = (h % 1f + 1f) % 1f;
        float hh = h * 6f;
        int i = (int) Math.floor(hh);
        float f = hh - i, p = v * (1f - s), q = v * (1f - s * f), t = v * (1f - s * (1f - f));
        return switch (i % 6) {
            case 0 -> new float[]{v, t, p};
            case 1 -> new float[]{q, v, p};
            case 2 -> new float[]{p, v, t};
            case 3 -> new float[]{p, q, v};
            case 4 -> new float[]{t, p, v};
            default -> new float[]{v, p, q};
        };
    }

    /** the most "colourful" hue of the cover, brightened for the progress bar, and a deep version for the glass tint */
    private void findAccent() {
        final int BINS = 24;
        double[] wsum = new double[BINS], rs = new double[BINS], gs = new double[BINS], bs = new double[BINS];
        double mr = 0, mg = 0, mb = 0;
        int cnt = 0;
        for (int i = 0; i < abgr.length; i += 2) {
            int p = abgr[i];
            float r = (p & 0xFF) / 255f, g = ((p >> 8) & 0xFF) / 255f, b = ((p >> 16) & 0xFF) / 255f;
            mr += r; mg += g; mb += b; cnt++;
            float mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
            float s = mx <= 0f ? 0f : (mx - mn) / mx;
            double w = s * s * (0.25 + mx);                                 // vivid and not too dark
            if (w < 0.01) continue;
            float hue;
            float d = mx - mn;
            if (mx == r) hue = ((g - b) / d) / 6f; else if (mx == g) hue = (2f + (b - r) / d) / 6f; else hue = (4f + (r - g) / d) / 6f;
            hue = (hue % 1f + 1f) % 1f;
            int bin = Math.min(BINS - 1, (int) (hue * BINS));
            wsum[bin] += w; rs[bin] += r * w; gs[bin] += g * w; bs[bin] += b * w;
        }
        int best = 0;
        double total = 0;
        for (int i = 0; i < BINS; i++) {
            total += wsum[i];
            double cur = wsum[i] + 0.5 * (wsum[(i + 1) % BINS] + wsum[(i + BINS - 1) % BINS]);
            double bc = wsum[best] + 0.5 * (wsum[(best + 1) % BINS] + wsum[(best + BINS - 1) % BINS]);
            if (cur > bc) best = i;
        }
        float r, g, b;
        float sat;
        if (total / Math.max(1, cnt) < 0.004 || wsum[best] <= 0) {         // (almost) grey cover: a soft white-blue
            float lum = (float) ((mr + mg + mb) / (3.0 * Math.max(1, cnt)));
            r = g = b = lum;
            sat = 0f;
        } else {
            r = (float) (rs[best] / wsum[best]); g = (float) (gs[best] / wsum[best]); b = (float) (bs[best] / wsum[best]);
            float mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
            sat = mx <= 0 ? 0 : (mx - mn) / mx;
        }
        float mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        float hue = 0f;
        float d = mx - mn;
        if (d > 1e-4f) {
            if (mx == r) hue = ((g - b) / d) / 6f; else if (mx == g) hue = (2f + (b - r) / d) / 6f; else hue = (4f + (r - g) / d) / 6f;
        }
        if (sat < 0.05f) { accent = new float[]{0.84f, 0.88f, 1.0f}; accent2 = new float[]{0.20f, 0.24f, 0.36f}; return; }
        accent = hsv(hue, Math.max(0.32f, Math.min(0.78f, sat * 0.85f)), 1.0f);
        accent2 = hsv(hue, Math.min(0.90f, Math.max(0.45f, sat)), 0.42f);
    }
}
