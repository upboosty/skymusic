package dev.skymusic;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.CameraSubmersionType;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Giant Apple-Music-style lyrics floating in the sky.
 *
 * Look: real 3D letters (Impact, extruded from baked outlines, see MeshFont / tools/gen_text3d.py), every word starts dim and lights up
 * as it is sung (tiny lift), lines spring in from below, then dim, fade and drift up when they are done.
 *
 * Speed: the whole lyric text is ONE batch of coloured triangles (one draw call). Every letter is a solid: front face, side walls and
 * (when seen from behind) back face, moved by the jelly animation with one small affine transform per letter.
 * Each lyric line is a physical object floating in the world, drawn in the WORLD pass with the depth buffer on, so it behaves like an entity / block:
 * trees, houses and hills hide it when they are in front of it. A line is born once, within 6.9 blocks of the player, in front of / beside the player
 * (or elsewhere around if the front is blocked), at face height or a little above (1.6 - 2.2 blocks above the feet), in free space. At birth it turns to
 * face the player (upright), and from then on its position, turn and size (one fixed world scale for every line) never change: perspective alone makes it
 * look bigger when you come closer. Only its letters animate and its opacity fades. (F1 still hides it; the plain HUD subtitle is separate.)
 * The letters are lit by the world: sky / block light where the sign hangs, time of day, weather, dimension, sun / moon direction on the walls.
 * Letters that are not in the 3D font fall back to the flat vanilla font.
 */
public class SkyRenderer {
    public static volatile boolean customFont = true;
    /** 0 = never, 1 = always, 2 = auto: a small plain subtitle only while the sky lyrics are out of view */
    public static volatile int subtitleMode = 2;
    public static volatile String status = "not rendered yet";
    /** /sky size <percent>: size of the lyric lines (1 = default) */
    public static volatile float SIZE = 1f;

    private static final float ROW_GAP = 26f;       // layout px between rows (the layout thinks in a 20 px font)
    private static final float BASE = 6f;           // baseline is this far below the visual middle of a row
    private static final float SPACE_W = 6.0f;      // width of a space
    private static final float DEPTH = 6.0f;        // thickness of the letters (layout px; a capital is about 14.7 px high)
    private static final float LEG = 2.1f;          // vanilla font (8 px) -> layout px, for letters the atlas does not have
    private static final double DIST = 70;          // radius of the lyric dome (blocks)
    public static volatile float ELEV = 0.45f;       // elevation of the lyric block centre in radians (~26 degrees up), /sky height <deg>
    private static boolean anchored = false;
    private static boolean errorShown = false;

    // camera matrices captured at the end of the world render, used by the HUD pass
    private static final Matrix4f VP = new Matrix4f();
    private static boolean haveVP = false;
    private static float camYaw = 0, camPitch = 0;
    private static double camX = 0, camY = 0, camZ = 0;
    private static float scrW = 1, scrH = 1;

    public static void init() {
        MeshFont.load();
        WorldRenderEvents.LAST.register(SkyRenderer::worldPass);       // the lyrics are drawn here, with the depth buffer
        HudRenderCallback.EVENT.register(SkyRenderer::renderHud);      // only the small subtitle is drawn here
    }

    public static void recheckFont() { LAYOUTS.clear(); }

    private static final Matrix4f WORLD_M = new Matrix4f();             // camera rotation of this frame: camera-relative world -> eye space
    private static float tanHX = 1.5f, tanHY = 0.7f;                    // tangent of the half field of view (horizontal / vertical)

    private static void capture(WorldRenderContext ctx) {
        Matrix4f proj = ctx.projectionMatrix();
        WORLD_M.set(ctx.matrixStack().peek().getPositionMatrix());
        VP.set(proj).mul(WORLD_M);
        camYaw = ctx.camera().getYaw();
        camPitch = ctx.camera().getPitch();
        camX = ctx.camera().getPos().x; camY = ctx.camera().getPos().y; camZ = ctx.camera().getPos().z;
        float m00 = Math.abs(proj.m00()), m11 = Math.abs(proj.m11());
        if (m00 > 1e-4f && m11 > 1e-4f) { tanHX = 1f / m00; tanHY = 1f / m11; }
        haveVP = true;
    }

    private static boolean useAtlas() { return customFont && MeshFont.ok; }

    // ---------- layout of one lyric line ----------
    /** one animated piece of a line: a short word, or a part of a long word */
    private static final class Seg {
        float x, w;                 // start and width inside its row (layout px)
        float f0, f1;               // the share of the line's sweep during which it lights up (0..1)
        int idx, n;                 // running number in the line, number of letters
        int base;                   // number of the first letter of this piece in the whole line (for the jelly wave)
        boolean legacy;             // contains letters the atlas does not have -> vanilla font
        int[] cp; float[] gx;       // atlas glyphs: code points and pen x from the segment start
        OrderedText ot; float lw;   // vanilla: the text and its vanilla width
    }
    private static final class Layout {
        Seg[][] segs; float[] rowW; int rows; float maxW = 1f; int total = 1;
    }

    // layouts are cached by text; the carousel draws up to four lines at once
    private static final java.util.HashMap<String, Layout> LAYOUTS = new java.util.HashMap<>();
    private static boolean layoutAtlas = true;
    /** maxRowPx = the widest a row may be (layout px) at the fixed world scale: longer lines get more rows instead of smaller letters */
    private static Layout layoutFor(String text, TextRenderer tr, boolean atlas, float maxRowPx) {
        if (atlas != layoutAtlas || LAYOUTS.size() > 64) { LAYOUTS.clear(); layoutAtlas = atlas; }
        String key = ((int) (maxRowPx / 6f)) + "|" + text;
        Layout l = LAYOUTS.get(key);
        if (l == null) {
            int len = text.trim().codePointCount(0, text.trim().length());
            Layout best = null;
            for (int k = Math.min(5, Math.max(1, (int) Math.ceil(len / 21.0))); k <= 6; k++) {
                best = build(wrap(text, k), tr, atlas);
                if (best.maxW <= maxRowPx) break;
            }
            l = best;
            LAYOUTS.put(key, l);
        }
        return l;
    }

    private static Layout build(String[] rows, TextRenderer tr, boolean atlas) {
        Layout L = new Layout();
        L.rows = rows.length;
        L.segs = new Seg[rows.length][];
        L.rowW = new float[rows.length];
        List<Seg> all = new ArrayList<>();
        int total = 0;
        for (int r = 0; r < rows.length; r++) {
            List<Seg> list = new ArrayList<>();
            float cx = 0;
            boolean first = true;
            for (String word : rows[r].trim().split("\\s+")) {
                if (word.isEmpty()) continue;
                if (!first) cx += SPACE_W;
                first = false;
                int[] cps = word.codePoints().toArray();
                int pieces = cps.length > 6 ? (int) Math.ceil(cps.length / 4.0) : 1;     // long words light up in parts
                int per = (int) Math.ceil(cps.length / (double) pieces);
                for (int a = 0; a < cps.length; a += per) {
                    int b = Math.min(cps.length, a + per);
                    Seg s = new Seg();
                    s.x = cx; s.n = b - a;
                    boolean okAtlas = atlas;
                    for (int k = a; k < b && okAtlas; k++) {
                        if (MeshFont.get(cps[k]) == null) okAtlas = false;
                    }
                    if (okAtlas) {
                        s.cp = Arrays.copyOfRange(cps, a, b);
                        s.gx = new float[s.n];
                        float px = 0;
                        for (int k = 0; k < s.n; k++) { s.gx[k] = px; px += MeshFont.get(s.cp[k]).adv + MeshFont.TRACK; }
                        s.w = px;
                    } else {
                        s.legacy = true;
                        Text t = Text.literal(new String(cps, a, b - a));
                        s.ot = t.asOrderedText();
                        s.lw = tr.getWidth(t);
                        s.w = s.lw * LEG;
                    }
                    cx += s.w;
                    list.add(s); all.add(s); total += s.n;
                }
            }
            L.segs[r] = list.toArray(new Seg[0]);
            L.rowW[r] = cx;
            L.maxW = Math.max(L.maxW, cx);
        }
        float acc = 0; int i = 0;
        for (Seg s : all) {                                   // when each piece lights up: longer pieces take longer
            s.f0 = acc / Math.max(1, total);
            s.base = (int) acc;
            acc += s.n;
            s.f1 = acc / Math.max(1, total);
            s.idx = i++;
        }
        L.total = Math.max(1, total);
        return L;
    }

    private static String[] wrap(String s, int k) {
        s = s.trim();
        int len = s.codePointCount(0, s.length());
        if (k <= 1) return new String[]{s};
        String[] words = s.split("\\s+");
        int target = (int) Math.ceil(len / (double) k);
        List<String> rows = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : words) {
            if (cur.length() > 0 && cur.length() + 1 + w.length() > target && rows.size() < k - 1) {
                rows.add(cur.toString()); cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        rows.add(cur.toString());
        return rows.toArray(new String[0]);
    }

    // ---------- helpers ----------
    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static float easeOutCubic(float x) { float u = 1f - x; return 1f - u * u * u; }
    private static float smooth(float x) { return x * x * (3f - 2f * x); }
    private static float lerp(float a, float b, float f) { return a + (b - a) * f; }
    private static float wrapDeg(float d) { return ((d % 360f) + 540f) % 360f - 180f; }
    private static int rgb(float r, float g, float b, int a) {
        return (a << 24) | ((int) (clamp01(r) * 255) << 16) | ((int) (clamp01(g) * 255) << 8) | (int) (clamp01(b) * 255);
    }
    // ---------- jelly motion ----------
    private static final double ENTER_Z = 0.40, ENTER_W = 14.0;     // springy entrance of every letter (damping ratio, rad/s)
    private static final float ENTER_DROP = 22f;                    // letters fly up from this far below (layout px)
    private static final float ENTER_VN = (float) peakVel(ENTER_Z, ENTER_W);
    private static double animSecs = 0;
    private static float sPos, sVel;                                // result of springPV()

    private static double peakVel(double z, double w) {
        double wd = w * Math.sqrt(1.0 - z * z), k = z * w, t = Math.atan(wd / k) / wd;
        return w * w / wd * Math.exp(-k * t) * Math.sin(wd * t);
    }

    /** underdamped spring 0 -> 1 with its own damping ratio z and frequency w; sPos = position, sVel = velocity (1/s) */
    private static void springPV(float t, double z, double w) {
        if (t <= 0f) { sPos = 0f; sVel = 0f; return; }
        double wd = w * Math.sqrt(1.0 - z * z), k = z * w;
        if (t > 9.0 / k) { sPos = 1f; sVel = 0f; return; }
        double e = Math.exp(-k * t), c = Math.cos(wd * t), sn = Math.sin(wd * t);
        sPos = (float) (1.0 - e * (c + (k / wd) * sn));
        sVel = (float) (e * (w * w / wd) * sn);
    }

    /** damped jelly shake: starts at 0 without a jolt, about 0.7 at the first swing, gone after ~1 s */
    private static float wobble(float t) {
        if (t <= 0f || t > 1.7f) return 0f;
        float ramp = t >= 0.04f ? 1f : smooth(t / 0.04f);
        return ramp * (float) (Math.exp(-5.2 * t) * Math.sin(21.0 * t));
    }

    /** the sideways part of the shake (slower, so it does not move in lock step with the squash) */
    private static float sway(float t) {
        if (t <= 0f || t > 1.7f) return 0f;
        float ramp = t >= 0.05f ? 1f : smooth(t / 0.05f);
        return ramp * (float) (Math.exp(-4.6 * t) * Math.sin(17.0 * t));
    }

    // what letterMotion() hands back: scale, lean (sideways shift of the top per unit of height), vertical offset (down = +), opacity
    private static float mSx, mSy, mLean, mOff, mA;

    /**
     * Jelly motion of one letter. gi / total = its number in the line (the wave runs along the line), tIn = seconds since the line
     * was born, onset = when this letter is sung, sl = how far it has left (0..1), p = how sung it is (0..1), dimK = line dimming.
     * Entrance: springs up from below, stretches while it flies and squashes when it lands. Sung: hops up and shakes like jelly.
     * Leaving: stretches a little while it drifts up. Lit letters breathe very slightly.
     */
    private static void letterMotion(int gi, int total, float tIn, float onset, float sl, float p, float dimK) {
        float stag = Math.min(0.026f, 0.38f / Math.max(1, total));
        float te = tIn - gi * stag;
        springPV(te, ENTER_Z, ENTER_W);
        float e = sPos, v = sVel / ENTER_VN;
        if (v < 0f) v *= 2.4f;                                 // the way back down is slower: exaggerate it so the landing really squashes
        float sy = 1f + 0.26f * v, sx = 1f - 0.17f * v;
        float off = (1f - e) * ENTER_DROP;
        mA = smooth(clamp01(te / 0.20f));

        float ts = tIn - onset;
        float wv = wobble(ts);
        sy *= 1f + 0.20f * wv;  sx *= 1f - 0.13f * wv;
        mLean = ((gi & 1) == 0 ? 1f : -1f) * 0.12f * sway(ts);
        springPV(ts, 0.50, 15.0);
        off -= 3.2f * sPos;                                    // sung letters hop up a little and settle with a bounce

        float ev = (float) Math.sin(Math.PI * sl);             // leaving: stretch while drifting up
        sy *= 1f + 0.14f * ev;  sx *= 1f - 0.09f * ev;
        off -= sl * 5f;

        float idleK = p * (1f - dimK) * (1f - sl) * mA;        // lit letters breathe, just barely
        sy *= 1f + 0.014f * (float) Math.sin(animSecs * 3.4 + gi * 0.65) * idleK;
        sx *= 1f - 0.009f * (float) Math.sin(animSecs * 3.4 + gi * 0.65) * idleK;
        off += 0.5f * (float) Math.sin(animSecs * 2.3 + gi * 0.9) * idleK;
        mSx = sx; mSy = sy; mOff = off;
    }


    // ---------- projection ----------
    private static final Vector4f V4 = new Vector4f();
    private static final float[] PC = new float[2];
    private static final Matrix4f AFF = new Matrix4f(), MT = new Matrix4f();

    /** world point (relative to the camera) -> GUI-scaled screen coordinates; false if behind the camera */
    private static boolean project(double x, double y, double z, float[] out) {
        V4.set((float) x, (float) y, (float) z, 1f);
        VP.transform(V4);
        if (V4.w <= 0.05f) return false;
        out[0] = (V4.x / V4.w * 0.5f + 0.5f) * scrW;
        out[1] = (0.5f - V4.y / V4.w * 0.5f) * scrH;
        return true;
    }

    // the plane of the sign being drawn, in clip space: point(x, y) = C0 + x * CX + y * CY  (x right, y down, in layout px)
    private static float c0x, c0y, c0w, cxx, cxy, cxw, cyx, cyy, cyw;
    private static float SX, SY;
    // the same plane in camera-relative world coordinates: point(x, y) = O + x * (prx, pry, prz) + y * (pux, puy, puz); pn = normal (toward you at birth)
    private static float pox, poy, poz, prx, pry, prz, pux, puy, puz, pnx, pny, pnz;

    /** (nx, ny, nz) = unit normal of the sign: it points from the sign to where you stood when it was born, so the sign looks straight at you */
    private static void setPlane(double rx, double ry, double rz, float nx, float ny, float nz, float s) {
        float hl = (float) Math.sqrt(nx * nx + nz * nz);
        float rX, rZ;                                          // right = up x normal: always level, so the text is never rolled
        if (hl < 1e-3f) { rX = (float) -Math.cos(Math.toRadians(camYaw)); rZ = (float) -Math.sin(Math.toRadians(camYaw)); }
        else { rX = nz / hl; rZ = -nx / hl; }
        float dX = -rZ * ny, dY = rZ * nx - rX * nz, dZ = rX * ny;      // down = right x normal
        pox = (float) rx; poy = (float) ry; poz = (float) rz;
        prx = rX * s; pry = 0f; prz = rZ * s;
        pux = dX * s; puy = dY * s; puz = dZ * s;
        pnx = nx * s; pny = ny * s; pnz = nz * s;
        V4.set((float) rx, (float) ry, (float) rz, 1f); VP.transform(V4); c0x = V4.x; c0y = V4.y; c0w = V4.w;
        V4.set(prx, pry, prz, 0f); VP.transform(V4); cxx = V4.x; cxy = V4.y; cxw = V4.w;
        V4.set(pux, puy, puz, 0f); VP.transform(V4); cyx = V4.x; cyy = V4.y; cyw = V4.w;
    }

    /** sign plane point -> GUI screen coordinates in SX, SY; false if behind the camera */
    private static boolean sp(float x, float y) {
        float w = c0w + x * cxw + y * cyw;
        if (w <= 0.05f) return false;
        float inv = 1f / w;
        SX = ((c0x + x * cxx + y * cyx) * inv * 0.5f + 0.5f) * scrW;
        SY = (0.5f - (c0y + x * cxy + y * cyy) * inv * 0.5f) * scrH;
        return true;
    }

    // ---------- the one triangle batch ----------
    private static BufferBuilder buf;
    private static boolean begun = false;
    private static int drawn = 0;

    private static void beginAtlas() {
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();                  // the text is a real object in the world: blocks and entities in front of it hide it
        RenderSystem.depthFunc(515);                     // GL_LEQUAL
        RenderSystem.depthMask(!ghostMode);              // and the solid letters hide each other and what is behind them (not while you are inside the text)
        RenderSystem.disableCull();
        buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        begun = true;
    }

    private static void endAtlas() {
        if (!begun) return;
        begun = false;
        try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch (Throwable ignored) { }
        restoreWorldState();
    }

    /** the state the world renderer expects after us */
    private static void restoreWorldState() {
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
    }

    // The sign in eye space (camera looks down -z): origin, and the sign's right / down / toward-you axes (each one layout px long)
    private static float eOx, eOy, eOz, eRx, eRy, eRz, eUx, eUy, eUz, eNx, eNy, eNz, eS;
    private static boolean frontToYou;
    private static float ghostK = 0f;
    private static boolean ghostMode = false;          // you are inside / right next to the text: see-through, both sides, no depth writes
    private static float thickMul = 1f;                // letters are made thicker when the text is tiny in the world (close to you)

    private static void setEye() {
        Matrix4f m = WORLD_M;
        eOx = m.m00() * pox + m.m10() * poy + m.m20() * poz + m.m30();
        eOy = m.m01() * pox + m.m11() * poy + m.m21() * poz + m.m31();
        eOz = m.m02() * pox + m.m12() * poy + m.m22() * poz + m.m32();
        eRx = m.m00() * prx + m.m10() * pry + m.m20() * prz;  eRy = m.m01() * prx + m.m11() * pry + m.m21() * prz;  eRz = m.m02() * prx + m.m12() * pry + m.m22() * prz;
        eUx = m.m00() * pux + m.m10() * puy + m.m20() * puz;  eUy = m.m01() * pux + m.m11() * puy + m.m21() * puz;  eUz = m.m02() * pux + m.m12() * puy + m.m22() * puz;
        eNx = m.m00() * pnx + m.m10() * pny + m.m20() * pnz;  eNy = m.m01() * pnx + m.m11() * pny + m.m21() * pnz;  eNz = m.m02() * pnx + m.m12() * pny + m.m22() * pnz;
        eS = (float) Math.sqrt(prx * prx + pry * pry + prz * prz);
        frontToYou = eNx * -eOx + eNy * -eOy + eNz * -eOz > 0f;           // are you on the side the letters face?
    }

    // one letter: eye position of a glyph point (vx, vy, vz) = P + vx * A + vy * B + vz * C
    private static float lPx, lPy, lPz, lAx, lAy, lAz, lBx, lBy, lBz, lCx, lCy, lCz;

    private static void vtx(float vx, float vy, float vz, float r, float g, float b, float a) {
        buf.vertex(lPx + vx * lAx + vy * lBx + vz * lCx, lPy + vx * lAy + vy * lBy + vz * lCy, lPz + vx * lAz + vy * lBz + vz * lCz)
            .color(r, g, b, a).next();
    }

    /**
     * One solid letter. pen = pen x and base = baseline y on the sign plane (already including the letter's own bounce), pvx = x of the
     * letter's foot (middle of its advance). The letter is squashed / stretched by sx, sy about its foot (so it stays planted like jelly),
     * lean shifts the top sideways. (r, g, b, a) = colour of the front face; the walls are the same colour, shaded.
     */
    private static void meshGlyph(MeshFont.Glyph g, float pen, float base, float pvx, float sx, float sy, float lean,
                                  float r, float gr, float b, float a) {
        if (a < 0.012f) return;
        float zs = Math.max(0.5f, Math.min(1.5f, 0.5f * (sx + sy))) * thickMul;       // thickness follows the squash, a little
        float h = DEPTH * 0.5f;
        // layout point of glyph point (vx, vy):  x = pvx + (pen + vx - pvx) * sx - lean * sy * vy,  y = base + vy * sy,  z = vz * zs
        float ox = pvx + (pen - pvx) * sx;
        lPx = eOx + ox * eRx + base * eUx;  lPy = eOy + ox * eRy + base * eUy;  lPz = eOz + ox * eRz + base * eUz;
        lAx = sx * eRx;  lAy = sx * eRy;  lAz = sx * eRz;
        lBx = sy * (eUx - lean * eRx);  lBy = sy * (eUy - lean * eRy);  lBz = sy * (eUz - lean * eRz);
        lCx = zs * eNx;  lCy = zs * eNy;  lCz = zs * eNz;
        // skip letters that are surely off screen or behind you
        float cvx = g.adv * 0.5f, cvy = -7f;
        float cx = lPx + cvx * lAx + cvy * lBx, cy = lPy + cvx * lAy + cvy * lBy, cz = lPz + cvx * lAz + cvy * lBz;
        float rad = 22f * eS * Math.max(1f, Math.max(sx, sy)) + 0.5f;
        if (cz > rad) return;
        float depth = Math.max(0.01f, -cz);
        if (Math.abs(cx) - rad > depth * tanHX * 1.15f || Math.abs(cy) - rad > depth * tanHY * 1.15f) return;
        if (!begun) beginAtlas();
        float[] t = g.tri;
        if (frontToYou || ghostMode) {                                     // front face (the one you see)
            float k = FRONT_AMB + FRONT_DIFF * Math.max(0f, lLz);
            float fr = r * k, fg = gr * k, fb = b * k;
            for (int i = 0; i < t.length; i += 2) vtx(t[i], t[i + 1], h, fr, fg, fb, a);
        }
        if (!frontToYou || ghostMode) {                                    // back face, darker (you walked around the sign; or you are inside it and see both)
            float k = 0.5f;
            float fr = r * k, fg = gr * k, fb = b * k;
            for (int i = 0; i < t.length; i += 2) vtx(t[i], t[i + 1], -h, fr, fg, fb, a);
        }
        float[] sg = g.seg;                                                // side walls, shaded by which way each edge faces the sun / moon
        for (int i = 0; i < sg.length; i += 8) {
            float x0 = sg[i], y0 = sg[i + 1], x1 = sg[i + 2], y1 = sg[i + 3];
            float s0 = WALL_AMB + WALL_DIFF * Math.max(0f, sg[i + 4] * lLx + sg[i + 5] * lLy);
            float s1 = WALL_AMB + WALL_DIFF * Math.max(0f, sg[i + 6] * lLx + sg[i + 7] * lLy);
            vtx(x0, y0, h, r * s0, gr * s0, b * s0, a);
            vtx(x0, y0, -h, r * s0, gr * s0, b * s0, a);
            vtx(x1, y1, -h, r * s1, gr * s1, b * s1, a);
            vtx(x0, y0, h, r * s0, gr * s0, b * s0, a);
            vtx(x1, y1, -h, r * s1, gr * s1, b * s1, a);
            vtx(x1, y1, h, r * s1, gr * s1, b * s1, a);
        }
        drawn += g.nTri + g.nSeg * 2;
    }

    // vanilla-font text (letters the 3D font does not have) goes through its own little buffer, drawn right after the letter batch
    private static VertexConsumerProvider.Immediate legacyVc = null;
    private static boolean legacyUsed = false;
    private static VertexConsumerProvider.Immediate legacyVc() {
        if (legacyVc == null) legacyVc = VertexConsumerProvider.immediate(new BufferBuilder(2048));
        return legacyVc;
    }

    // ---------- main ----------
    private static final long T0 = System.nanoTime();
    private static long lastNanos = T0;
    private static float dt = 0.016f;

    // Every lyric line is a real object in the world. It is born once, near the player, and after that NOTHING about it changes: not its
    // position, not its turn, not its size. The size is the same fixed number for every line (WORLD_PX); how big it looks is left to
    // Minecraft's normal perspective (closer = bigger, farther = smaller).
    private static final float WORLD_PX = 0.016f;                // SIZE OF THE TEXT: blocks per layout px, the same for EVERY line, for its whole life (a capital letter is ~0.24 blocks tall, a row of text ~0.42). /sky size scales lines born afterwards.
    private static final float MAX_ROW_BLOCKS = 4.4f;            // a row is at most this wide (blocks, at the default size): longer lines wrap onto more rows instead of getting smaller letters
    private static final double MAX_DIST = 6.9;                  // a line is never born farther than this from the player (blocks, straight line from the eyes)
    private static final float Y_MIN = 1.6f, Y_SPAN = 0.6f;      // the middle of the text is born 1.6 - 2.2 blocks above the player's FEET (face height or a little above)
    private static final float Y_CAP = 0.25f;                    // ... and may be lifted at most this much above that range (to clear a slope / a block under it)
    private static final float CLEAR_BELOW = 0.85f;              // free space kept between the bottom of the text and the ground under it: never at floor level
    private static final float MARGIN_X = 0.35f, MARGIN_Y = 0.25f; // no block closer than this to the text (beside it / above it / below it)
    private static final float MIN_THICK = 0.07f;                // the letters are never thinner than this many blocks (so there is an inside to walk into)
    private static final float SIDE_FLIP = 0.75f;                // chance that the next line is born on the other side (never 3 in a row on one side)
    private static final float LEAVE_T = 0.85f;                  // seconds a line needs to fade away
    private static int lastSide = 1, sideRun = 1;                // side (+1 right, -1 left) of the last line, and how many in a row

    /** a lyric line's fixed place in the world: centre (x, y, z), the way it faces (nx, nz = horizontal, from the sign to the player at birth), s = blocks per layout px */
    private static final class Anchor { Layout L; double x, y, z; float face, nx, ny, nz; float hwB, hhB, s; float er = 1f, eg = 1f, eb = 1f, ds = 0f; boolean envOk = false; }
    private static final java.util.HashMap<Integer, Anchor> ANCH = new java.util.HashMap<>();
    private static Lrc lastLrc = null;
    // song end: the last lines still play their leaving animation instead of vanishing
    private static boolean playing = false, ending = false;
    private static double lastT = 0, forceLeave = Double.MAX_VALUE;
    private static long endNs = 0;
    private static Lrc endLrc = null;
    private static int frameNo = 0;
    private static java.util.Random rng = new java.util.Random();
    private static String lastTitle = null, titleText = "♪", titlePlain = "♪";

    // per-frame context
    private static Lrc ctxLrc;
    // result of chunkInfo()
    private static double cTime, cSweep, cLeave;

    // ---------- environment light: the text is lit like everything else in the world ----------
    private static float tickD = 0f;
    private static final float FRONT_AMB = 0.84f, FRONT_DIFF = 0.16f;   // brightness of the front face: always readable, a little brighter when the sun / moon shines on it
    private static final float WALL_AMB = 0.50f, WALL_DIFF = 0.46f;     // brightness of the side walls: darker, brighter on the side that faces the sun / moon
    private static final float EMIT = 0.35f;                            // sung letters glow a little by themselves (how much they ignore the surrounding darkness)
    private static final float LEGIBLE = 0.36f;                         // the darkest the text gets (the lyrics must stay readable at night / in caves)
    private static float wLx, wLy, wLz, dsFrame, skyMulNow, floorK, envGamma;
    private static boolean lavaNow;
    private static final float[] skyTint = new float[3], mediumTint = new float[3];
    private static float curEnvR = 1f, curEnvG = 1f, curEnvB = 1f, curDs = 0f, lLx, lLy, lLz;   // light for the sign being drawn (lL* = light direction in the sign's own axes, scaled by its strength)

    /** vanilla's light level curve */
    private static float lightCurve(int level) { float f = level / 15f; return f / (4f - 3f * f); }

    /** things that are the same for every sign this frame: time of day, weather, dimension, what you look through */
    private static void frameLight(MinecraftClient mc) {
        ClientWorld w = mc.world;
        float td = tickD;
        boolean hasSky = w.getDimension().hasSkyLight();
        float rain = w.getRainGradient(td), thunder = w.getThunderGradient(td);
        float ang = w.getSkyAngle(td) * (float) (Math.PI * 2);
        float sxv = -(float) Math.sin(ang), syv = (float) Math.cos(ang);       // direction of the sun (the moon is opposite)
        boolean flash = w.getLightningTicksLeft() > 0;
        skyMulNow = flash ? 1f : w.getSkyBrightness(td);                       // vanilla: 1 at noon, 0.2 at night, less in rain / thunder
        float ambient = w.getDimension().ambientLight();
        boolean brighten = w.getDimensionEffects().shouldBrightenLighting();   // the End
        float dusk = 0f;
        if (hasSky) {
            float ws = smooth(clamp01((syv + 0.1f) / 0.3f));                   // sun light: from just under the horizon to well above it
            float wm = 0.4f * smooth(clamp01((0.1f - syv) / 0.3f));            // moon light: weaker
            float k = ws - wm;
            float sg = k >= 0f ? 1f : -1f;
            wLx = sxv * sg; wLy = syv * sg; wLz = 0f;
            dsFrame = Math.abs(k) * (1f - 0.75f * rain - 0.1f * thunder);
            dusk = smooth(clamp01(1f - Math.abs(syv - 0.02f) / 0.28f));
        } else {                                                                // nether, end, dimensions without a sky: a soft light from above
            wLx = 0.35f; wLy = 0.85f; wLz = 0.4f;
            dsFrame = 0.35f;
        }
        float night = hasSky ? clamp01((1f - skyMulNow) / 0.8f) : 0f;
        float tr = lerp(1f, 0.70f, night), tg = lerp(1f, 0.80f, night), tb = 1f;           // moonlight is blue
        tr = lerp(tr, 1.00f, dusk * 0.55f); tg = lerp(tg, 0.74f, dusk * 0.55f); tb = lerp(tb, 0.52f, dusk * 0.55f);   // golden / red hour
        float gray = 0.3f * tr + 0.59f * tg + 0.11f * tb;
        float wet = rain * 0.45f;
        tr = lerp(tr, gray, wet); tg = lerp(tg, gray, wet); tb = lerp(tb, gray, wet);       // rain washes the colour out
        if (flash) { tr = 1f; tg = 1f; tb = 1f; }
        skyTint[0] = tr; skyTint[1] = tg; skyTint[2] = tb;
        envGamma = clamp01(mc.options.getGamma().getValue().floatValue());                  // the game's brightness setting
        floorK = LEGIBLE + ambient + (brighten ? 0.25f : 0f);
        if (mc.player != null && mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) floorK = 0.9f;
        mediumTint[0] = 1f; mediumTint[1] = 1f; mediumTint[2] = 1f;
        lavaNow = false;
        CameraSubmersionType st = mc.gameRenderer.getCamera().getSubmersionType();
        if (st == CameraSubmersionType.WATER) { mediumTint[0] = 0.55f; mediumTint[1] = 0.80f; mediumTint[2] = 1f; }
        else if (st == CameraSubmersionType.LAVA) lavaNow = true;
    }

    /** the light at the sign: sky light and block light of the spot where it hangs (so caves, shade under trees and torches count), eased over time */
    private static void updateEnv(MinecraftClient mc, Anchor an) {
        ClientWorld w = mc.world;
        BlockPos bp = BlockPos.ofFloored(an.x, an.y, an.z), up = bp.up();
        int sk = Math.max(w.getLightLevel(LightType.SKY, bp), w.getLightLevel(LightType.SKY, up));
        int bl = Math.max(w.getLightLevel(LightType.BLOCK, bp), w.getLightLevel(LightType.BLOCK, up));
        float skyT = lightCurve(sk) * skyMulNow;
        float b = lightCurve(bl);
        float r = skyTint[0] * skyT + b;                                             // block light is warm when weak, white when strong (vanilla)
        float g = skyTint[1] * skyT + b * ((b * 0.6f + 0.4f) * 0.6f + 0.4f);
        float bb = skyTint[2] * skyT + b * (b * b * 0.6f + 0.4f);
        r = Math.min(1f, r); g = Math.min(1f, g); bb = Math.min(1f, bb);
        r = lerp(r, 1f - (float) Math.pow(1f - r, 4), envGamma);                     // brightness slider of the game
        g = lerp(g, 1f - (float) Math.pow(1f - g, 4), envGamma);
        bb = lerp(bb, 1f - (float) Math.pow(1f - bb, 4), envGamma);
        r = Math.max(r, floorK * lerp(1f, skyTint[0], 0.8f));
        g = Math.max(g, floorK * lerp(1f, skyTint[1], 0.8f));
        bb = Math.max(bb, floorK * lerp(1f, skyTint[2], 0.8f));
        r *= mediumTint[0]; g *= mediumTint[1]; bb *= mediumTint[2];
        if (lavaNow) { r = 1f; g = 0.78f; bb = 0.5f; }
        float ds = dsFrame * (sk / 15f);                                             // sun / moon only shine where the sky is open
        if (!an.envOk) { an.er = r; an.eg = g; an.eb = bb; an.ds = ds; an.envOk = true; }
        else {
            float k = 1f - (float) Math.exp(-dt * 5f);
            an.er += (r - an.er) * k; an.eg += (g - an.eg) * k; an.eb += (bb - an.eb) * k; an.ds += (ds - an.ds) * k;
        }
    }

    private static volatile String subText = null;            // the small plain subtitle for this frame (set by the world pass, drawn by the HUD pass)

    /** World pass (after everything else is drawn, before the post effect): the lyrics are drawn here, depth-tested against the world. */
    private static void worldPass(WorldRenderContext ctx) {
        subText = null;
        capture(ctx);
        tickD = ctx.tickDelta();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || !haveVP) { playing = false; ending = false; return; }
        long now = System.nanoTime();
        dt = Math.max(0.0005f, Math.min(0.05f, (now - lastNanos) / 1e9f));
        lastNanos = now;
        double t = SkyMusicClient.PLAYER.getTime();
        boolean fin = false;
        if (t >= 0) { playing = true; ending = false; lastT = t; endLrc = SkyMusicClient.lyrics; }
        else {
            if (playing) { playing = false; ending = true; endNs = now; }     // the song just ended (or was stopped)
            if (ending) {
                double el = (now - endNs) / 1e9;
                if (el > 1.9) ending = false; else { fin = true; t = lastT + el; }
            }
            if (!fin) { anchored = false; status = "no song playing"; return; }
        }
        if (mc.options.hudHidden) { status = "hidden (F1)"; return; }          // lyrics are part of the HUD: F1 hides them
        try {
            scrW = mc.getWindow().getScaledWidth();
            scrH = mc.getWindow().getScaledHeight();
            forceLeave = fin ? lastT : Double.MAX_VALUE;           // everything still on screen leaves now
            renderLyrics(mc, t, fin ? endLrc : SkyMusicClient.lyrics);
        } catch (Throwable e) {
            endAtlas();
            restoreWorldState();
            status = "error: " + e;
            if (!errorShown) { errorShown = true; SkyMusicClient.msg("Lyrics error (please report): " + e); }
        }
    }

    /** HUD pass: only the small plain subtitle (when you are not looking at the lyrics in the world). */
    private static void renderHud(DrawContext dc, float tickDelta) {
        String sub = subText;
        if (sub == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        dc.drawCenteredTextWithShadow(mc.textRenderer, Text.literal(sub), (int) (mc.getWindow().getScaledWidth() / 2f), (int) (mc.getWindow().getScaledHeight() * 0.12f), 0xFFFFFF);
    }

    /** chunk 0 = title card, chunk n = lyric line n-1 */
    private static String itemText(int c) {
        if (c == 0) return titleText;
        String s = ctxLrc.lines.get(c - 1).text();
        return s.isEmpty() ? "♪  ♫  ♪" : s;
    }

    /** when chunk c starts, how long its words take to light up and when it starts to leave (seconds of song time). false = not shown. */
    private static boolean chunkInfo(int c, int nLines) {
        String tx = itemText(c);
        int len = tx.codePointCount(0, tx.length());
        if (c == 0) {
            double first = ctxLrc != null ? ctxLrc.lines.get(0).time() : 7.0;
            if (ctxLrc != null && first < 1.2) return false;          // lyrics start right away, no room for a title card
            cTime = 0;
            cSweep = Math.max(0.6, Math.min(first * 0.7, 1.6));
            cLeave = Math.min(Math.min(first, cSweep + 3.5), forceLeave);
            return true;
        }
        Lrc.Line ln = ctxLrc.lines.get(c - 1);
        double next = c < nLines ? ctxLrc.lines.get(c).time() : ln.time() + 5.0;
        double gap = Math.max(0.3, next - ln.time());
        cTime = ln.time();
        // the words light up across the time the line is sung (the gap to the next line), but a short line in a long gap does not drag
        cSweep = Math.max(0.45, Math.min(gap * 0.88, Math.max(len * 0.09, 0.9)));
        cLeave = Math.min(cTime + Math.max(0.8, Math.min(gap, cSweep + 2.8)), forceLeave);   // leaves when the next line comes, or a bit after it was sung
        return true;
    }

    /** distance in degrees between two rectangles (negative = overlapping) */
    private static float rectSep(float y, float e, float hw, float hh, float oy, float oe, float ohw, float ohh) {
        return Math.max(Math.abs(y - oy) - (hw + ohw), Math.abs(e - oe) - (hh + ohh));
    }

    /** how far (degrees, as seen from where you stand now) a candidate spot is from an earlier line; large if that line is far away */
    private static float sepToAnchor(Anchor p, float y, float e, float hwD, float hhD) {
        if (p == null) return 99f;
        double dx = p.x - camX, dy = p.y - camY, dz = p.z - camZ;
        double dist = Math.max(0.5, Math.sqrt(dx * dx + dy * dy + dz * dz));
        float elAbs = (float) Math.toDegrees(Math.asin(dy / dist));
        float yawRel = wrapDeg((float) Math.toDegrees(Math.atan2(-dx, dz)) - camYaw) * (float) Math.cos(Math.toRadians(elAbs));
        float elRel = elAbs - (-camPitch);
        float hw = (float) Math.toDegrees(Math.atan(p.hwB / dist)), hh = (float) Math.toDegrees(Math.atan(p.hhB / dist));
        return rectSep(y, e, hwD, hhD, yawRel, elRel, hw, hh);
    }

    private static boolean solidAt(MinecraftClient mc, BlockPos pos) {
        net.minecraft.block.BlockState st = mc.world.getBlockState(pos);
        if (st.isAir()) return false;
        return !st.getCollisionShape(mc.world, pos).isEmpty();   // stone, trees, leaves, fences ... not grass, flowers or water
    }

    /**
     * How many sample points of a thin upright box lie inside solid blocks (0 = the text fits without touching anything).
     * The box is centred on (ax, ay, az), hw / hh = half width / half height, (nx, nz) = the way it faces (the box is thin along that axis).
     * Samples are at most ~0.5 block apart, so nothing as thin as a fence post slips through. This only runs when a line is born.
     */
    private static int boxHits(MinecraftClient mc, double ax, double ay, double az, float hw, float hh, float nx, float nz) {
        if (mc.world == null) return 0;
        float rx = nz, rz = -nx;                                  // the sign's right
        int nu = Math.max(1, (int) Math.ceil(2f * hw / 0.5f)), nv = Math.max(1, (int) Math.ceil(2f * hh / 0.5f));
        BlockPos.Mutable bp = new BlockPos.Mutable();
        int hits = 0;
        for (int i = 0; i <= nu; i++) {
            double u = -hw + 2.0 * hw * i / nu;
            for (int j = 0; j <= nv; j++) {
                double v = -hh + 2.0 * hh * j / nv;
                for (int d = -1; d <= 1; d++) {
                    bp.set(ax + rx * u + nx * d * 0.45, ay + v, az + rz * u + nz * d * 0.45);
                    if (solidAt(mc, bp) && ++hits >= 6) return hits;
                }
            }
        }
        return hits;
    }

    /** distance from a along the way to b to the first solid block, or -1 if the way is free (grass and flowers do not count) */
    private static double rayHit(MinecraftClient mc, Vec3d from, Vec3d to) {
        BlockHitResult h = mc.world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return h.getType() == HitResult.Type.MISS ? -1.0 : h.getPos().distanceTo(from);
    }

    /** is the point (x, y, z) hidden from the camera by a block? */
    private static boolean hiddenFrom(MinecraftClient mc, Vec3d cam, double x, double y, double z) {
        Vec3d p = new Vec3d(x, y, z);
        double d = rayHit(mc, cam, p);
        return d >= 0 && d < cam.distanceTo(p) - 0.35;
    }

    /**
     * The fixed place in the world where chunk c lives; picked ONCE, the first time it is needed:
     *  - "in front of the player" means the way the player's HEAD turns, flat: looking down at the floor (or up) changes nothing, so the text is
     *    never put on the floor or on the block you are looking at;
     *  - a little to the left or right of that direction (10 - 38 degrees), 2.8 - 6.9 blocks away; never farther than MAX_DIST from the eyes;
     *  - its middle is 1.6 - 2.2 blocks above the player's feet, and is lifted if there is a slope / block under it so that the bottom of the
     *    text is always well above the ground;
     *  - the spot must be free of solid blocks (collision check around the whole text with a margin) and, preferably, in sight (raycasts
     *    from the eyes). If the front is blocked (a wall) the search widens: sides, then all around including behind the player, then closer;
     *    the best valid spot wins. It may lie beyond a thin obstruction if that is where free space is;
     *  - it turns to face the player exactly once, now (upright: only left / right, never tilted), and then keeps that turn for ever.
     * Its size is the one fixed WORLD_PX (times /sky size at this moment); it is stored with the line and never changes.
     * Because it is drawn with the depth buffer it can be hidden by blocks later if you walk around.
     */
    private static Anchor anchorFor(MinecraftClient mc, int c, Layout L) {
        Anchor a = ANCH.get(c);
        if (a != null) return a;
        Anchor p1 = ANCH.get(c - 1), p2 = ANCH.get(c - 2);
        var pl = mc.player;

        final float s = WORLD_PX * SIZE;                                                   // the physical scale of this line, for its whole life
        final float hw = 0.5f * L.maxW * s + 0.05f, hh = 0.5f * L.rows * ROW_GAP * s + 0.05f;   // half width / half height of the text, in blocks

        double ex = pl.getX(), ez = pl.getZ(), eyeY = pl.getEyeY(), feetY = pl.getY();
        Vec3d eye = new Vec3d(ex, eyeY, ez);
        double yr = Math.toRadians(pl.getYaw());
        double fX = -Math.sin(yr), fZ = Math.cos(yr), rX = -Math.cos(yr), rZ = -Math.sin(yr);   // where the player faces (flat) and the player's right

        float hBias = Math.max(-0.4f, Math.min(0.8f, (float) (Math.tan(ELEV - 0.45f) * 6.0)));   // /sky height nudges the whole height range (0 by default)
        double yLo = feetY + Y_MIN + hBias, yCap = yLo + Y_SPAN + Y_CAP;
        double dyMax = Math.max(Math.abs(yLo - eyeY), Math.abs(yCap - eyeY));
        double dMax = Math.sqrt(Math.max(1.0, MAX_DIST * MAX_DIST - dyMax * dyMax));          // horizontal reach that keeps the straight-line distance within MAX_DIST
        int want = (sideRun >= 2 || rng.nextFloat() < SIDE_FLIP) ? -lastSide : lastSide;

        // fallback if nothing at all could be evaluated: straight ahead, face height
        double bx = ex + fX * 2.5, by = feetY + Y_MIN + 0.3 + hBias, bz = ez + fZ * 2.5;
        float bnx = (float) -fX, bnz = (float) -fZ, bScore = -1e9f;
        int bSide = want;
        final float[] tierPen = {0f, 6f, 14f, 30f};
        for (int tries = 0; tries < 84; tries++) {
            // tier 0: ahead, slightly to a side. 1: more to the sides. 2: anywhere around (also behind you). 3: anywhere, close.
            int tier = tries < 24 ? 0 : tries < 44 ? 1 : tries < 64 ? 2 : 3;
            int sd = tier == 0 ? (tries < 12 ? want : -want) : (rng.nextBoolean() ? 1 : -1);
            float angD = tier == 0 ? 10f + 28f * rng.nextFloat() : tier == 1 ? 38f + 80f * rng.nextFloat() : 180f * rng.nextFloat();
            double d = tier == 0 ? (tries < 12 ? 3.8 + 2.2 * rng.nextFloat() : tries < 18 ? 2.8 + 1.0 * rng.nextFloat() : 6.0 + 0.9 * rng.nextFloat())
                     : tier == 1 ? 3.0 + 3.5 * rng.nextFloat() : tier == 2 ? 2.5 + 3.5 * rng.nextFloat() : 1.3 + 1.7 * rng.nextFloat();
            d = Math.min(d, dMax);
            double ang = Math.toRadians(angD) * sd;
            double dirX = fX * Math.cos(ang) + rX * Math.sin(ang), dirZ = fZ * Math.cos(ang) + rZ * Math.sin(ang);   // flat direction from the player to the spot
            float nnx = (float) -dirX, nnz = (float) -dirZ;                                  // the sign faces back to the player (horizontal only: upright)
            float rgx = nnz, rgz = -nnx;                                                     // the sign's right
            double ax = ex + dirX * d, az = ez + dirZ * d;
            double ay = yLo + Y_SPAN * rng.nextFloat();

            // never near the floor: find the ground under the middle and both ends of the text, and lift the text if it would be too low
            boolean grounded = false;
            double gY = 0;
            for (int e = -1; e <= 1; e++) {
                double gx = ax + rgx * e * hw * 0.8, gz = az + rgz * e * hw * 0.8;
                double gd = rayHit(mc, new Vec3d(gx, ay, gz), new Vec3d(gx, ay - 9.0, gz));
                if (gd >= 0) { double g = ay - gd; if (!grounded || g > gY) { gY = g; grounded = true; } }
            }
            if (grounded && ay < gY + hh + CLEAR_BELOW) ay = gY + hh + CLEAR_BELOW;
            if (ay > yCap) continue;                                                         // a cliff / inside a hill: not here

            int hits = boxHits(mc, ax, ay, az, hw + MARGIN_X, hh + MARGIN_Y, nnx, nnz);
            float score = -tierPen[tier] - 100f * hits;

            // how far (degrees, as seen from where you look now) it is from the two earlier lines, so lines do not pile up on each other
            double cdx = ax - camX, cdy = ay - camY, cdz = az - camZ;
            double cdist = Math.max(0.5, Math.sqrt(cdx * cdx + cdy * cdy + cdz * cdz));
            float elAbs = (float) Math.toDegrees(Math.asin(cdy / cdist));
            float yo = wrapDeg((float) Math.toDegrees(Math.atan2(-cdx, cdz)) - camYaw) * (float) Math.cos(Math.toRadians(elAbs)), eo = elAbs + camPitch;
            float hwD = (float) Math.toDegrees(Math.atan(hw / cdist)), hhD = (float) Math.toDegrees(Math.atan(hh / cdist));
            float sc = Math.min(Math.min(sepToAnchor(p1, yo, eo, hwD, hhD), sepToAnchor(p2, yo, eo, hwD, hhD)), 20f);

            boolean visC = false;
            int vis = 0;
            if (hits == 0) {                                                                 // only a free spot is worth the raycasts: can the player see it?
                visC = !hiddenFrom(mc, eye, ax, ay, az);
                if (visC) vis++;
                if (!hiddenFrom(mc, eye, ax + rgx * hw * 0.8, ay, az + rgz * hw * 0.8)) vis++;
                if (!hiddenFrom(mc, eye, ax - rgx * hw * 0.8, ay, az - rgz * hw * 0.8)) vis++;
                score += 8f * vis + (visC ? 10f : 0f);
            }
            score -= 5f * Math.max(0f, 3.4f - (float) d) + 3f * Math.max(0f, (float) d - 6.2f);   // not too close, not too far (small text)
            score += Math.min(sc, 12f);
            if (score > bScore) { bScore = score; bx = ax; by = ay; bz = az; bnx = nnx; bnz = nnz; bSide = sd; }
            if (hits == 0 && visC && vis >= 2 && sc >= 2f) break;                            // free, in sight, not on top of the last lines: take it
        }
        sideRun = bSide == lastSide ? sideRun + 1 : 1;
        lastSide = bSide;
        a = new Anchor();
        a.L = L;
        a.x = bx; a.y = by; a.z = bz;
        a.nx = bnx; a.ny = 0f; a.nz = bnz;
        a.face = (float) Math.atan2(bnz, bnx);
        a.s = s; a.hwB = hw; a.hhB = hh;
        ANCH.put(c, a);
        return a;
    }

    private static void renderLyrics(MinecraftClient mc, double t, Lrc lrc) {
        TextRenderer tr = mc.textRenderer;
        boolean atlas = useAtlas();
        boolean hasLyrics = lrc != null && !lrc.lines.isEmpty();
        int nLines = hasLyrics ? lrc.lines.size() : 0;
        drawn = 0;

        String ttl = SkyMusicClient.title;
        if (ttl == null) ttl = "";
        if (!ttl.equals(lastTitle)) {
            lastTitle = ttl;
            titleText = ttl.isEmpty() ? "♪" : "♪  " + ttl;
            titlePlain = ttl.isEmpty() ? "♪" : "♪ " + ttl;
            ANCH.clear();
        }
        Lrc use = hasLyrics ? lrc : null;
        if (use != lastLrc) { lastLrc = use; ANCH.clear(); rng = new java.util.Random(); }
        ctxLrc = use;

        double secs = (System.nanoTime() - T0) / 1e9;
        animSecs = secs;

        // size: ONE fixed world scale for every line (WORLD_PX); the widest row (in layout px) follows from it. Nothing here depends on the camera.
        float maxRowPx = MAX_ROW_BLOCKS / (WORLD_PX * SIZE);

        frameLight(mc);

        int idx = hasLyrics ? lrc.indexAt(t) : -1;
        int cur = idx + 1;
        String plain = null;
        boolean visible = false;                                   // is the line being sung on screen right now?
        for (int c = Math.max(0, cur - 5); c <= cur; c++) {          // oldest first, so the newest chunk is painted on top
            if (!chunkInfo(c, nLines)) continue;
            double tIn = t - cTime;
            double tLeave = t - cLeave;
            if (tIn < 0 || tLeave > LEAVE_T) continue;

            Anchor an = ANCH.get(c);
            Layout L = an != null ? an.L : layoutFor(itemText(c), tr, atlas, maxRowPx);   // the wrapping is decided once, when the line is born and stays with it
            if (an == null) an = anchorFor(mc, c, L);
            updateEnv(mc, an);
            curEnvR = an.er; curEnvG = an.eg; curEnvB = an.eb;
            curDs = an.ds;

            float ex = clamp01((float) (tLeave / LEAVE_T));
            float dimK = smooth(clamp01(ex * 2.2f));                             // when a line is done it dims first,
            float softK = smooth(clamp01((ex - 0.05f) * 1.7f));                  // ... goes out of focus,
            float outA = 1f - smooth(clamp01((ex - 0.30f) / 0.70f));             // ... and fades out (opacity only: it never moves or changes size)
            double rx = an.x - camX, ry = an.y - camY, rz = an.z - camZ;         // the fixed world position, relative to the camera of this frame
            float sBlocks = an.s;                                                // the fixed world scale of this line (the same for every line)
            thickMul = Math.max(1f, Math.min(6f, MIN_THICK / Math.max(1e-6f, DEPTH * sBlocks)));
            drawChunk(tr, L, rx, ry, rz, an.nx, an.ny, an.nz, sBlocks, (float) tIn, (float) cSweep, (float) tLeave, outA, dimK, softK);
            if (c == cur) {
                plain = c == 0 ? titlePlain : itemText(c);
                visible = project(rx, ry, rz, PC) && PC[0] > scrW * 0.04f && PC[0] < scrW * 0.96f && PC[1] > scrH * 0.04f && PC[1] < scrH * 0.96f;
            }
        }
        endAtlas();                           // all lyric glyphs go out in one draw call
        if (legacyUsed) { legacyUsed = false; legacyVc().draw(); restoreWorldState(); }   // then the vanilla-font fallback text (rare)

        // small plain subtitle when you are not looking at the floating lyrics (or always, /sky subtitle on); drawn later by the HUD pass
        int sm = subtitleMode;
        if (plain != null && (sm == 1 || (sm == 2 && !visible))) subText = plain;
        if ((frameNo++ & 15) == 0)
            status = "playing, t=" + String.format("%.1f", t) + ", quads drawn=" + drawn + ", on screen=" + visible
                + ", font=" + (atlas ? "3D mesh font" : (customFont ? "vanilla (text3d.bin missing)" : "vanilla"));
    }

    /**
     * Draws one lyric line as an upright sign in the world. (rx, ry, rz) = its centre relative to the camera, (rightX, rightZ) = which way
     * "right" points, s = blocks per layout px. tIn = seconds since the line started (words light up as it is sung), sweep = seconds the
     * singing of the line takes, tLeave = seconds since it started leaving (negative = not leaving yet), lineA = overall opacity,
     * dimK / softK = how far the line has dimmed / gone out of focus.
     */
    private static void drawChunk(TextRenderer tr, Layout L, double rx, double ry, double rz, float nx, float ny, float nz, float s,
                                  float tIn, float sweep, float tLeave, float lineA, float dimK, float softK) {
        if (lineA < 0.01f) return;
        setPlane(rx, ry, rz, nx, ny, nz, s);
        setEye();                                                     // (no early exit when the middle is behind you: the letters around you must stay)
        if (eS < 1e-6f) return;
        // where are you relative to the sign (layout px: x right, y down, z toward the side the letters face)? close to it / inside it -> see-through
        {
            float vx = -eOx, vy = -eOy, vz = -eOz, s2 = eS * eS;
            float cxp = (vx * eRx + vy * eRy + vz * eRz) / s2, cyp = (vx * eUx + vy * eUy + vz * eUz) / s2, czp = (vx * eNx + vy * eNy + vz * eNz) / s2;
            float exo = Math.max(0f, Math.abs(cxp) - (L.maxW * 0.5f + 8f)), eyo = Math.max(0f, Math.abs(cyp) - (L.rows * ROW_GAP * 0.5f + 8f));
            float ezo = Math.max(0f, Math.abs(czp) * thickMul - DEPTH * 0.5f * thickMul);
            float dBlocks = (float) Math.sqrt(exo * exo + eyo * eyo + ezo * ezo) * eS;
            ghostK = 1f - smooth(clamp01((dBlocks - 0.10f) / 0.80f));
        }
        boolean gh = ghostK > 0.02f;
        if (begun && gh != ghostMode) endAtlas();                     // the solid and the see-through letters go out in separate draw calls
        ghostMode = gh;
        // the sun / moon (or the soft light from above) in the sign's own axes: x right, y down, z toward the side the letters face
        lLx = (wLx * prx + wLy * pry + wLz * prz) / eS * curDs;
        lLy = (wLx * pux + wLy * puy + wLz * puz) / eS * curDs;
        lLz = (wLx * pnx + wLy * pny + wLz * pnz) / eS * curDs;
        float sw = Math.max(0.2f, sweep);
        {
            for (int r = 0; r < L.rows; r++) {
                float rowY = (r - (L.rows - 1) / 2f) * ROW_GAP;
                float x0 = -L.rowW[r] / 2f;
                for (Seg sg : L.segs[r]) {
                    float p = smooth(clamp01((tIn - sg.f0 * sw) / Math.max(0.16f, (sg.f1 - sg.f0) * sw * 1.25f)));   // 0 = not sung yet, 1 = sung
                    float sl = smooth(clamp01((tLeave - sg.idx * 0.035f) / 0.7f));                                    // leaving, word by word
                    float wordA = lineA * (1f - 0.5f * sl) * (1f - 0.55f * ghostK);   // never fully gone, even when you stand inside it
                    float bt = clamp01(p * (1f - 0.65f * dimK));                                                      // brightness
                    float cr = lerp(0.74f, 1f, bt), cg = lerp(0.82f, 1f, bt), cb = lerp(0.98f, 0.985f, bt);      // flat vanilla-font fallback
                    float em = EMIT * bt;                                                                          // sung letters shine a little by themselves
                    float er = lerp(curEnvR, 1f, em), eg = lerp(curEnvG, 1f, em), eb = lerp(curEnvB, 1f, em);       // light of the place the sign hangs in
                    cr *= er; cg *= eg; cb *= eb;
                    float mr = lerp(0.46f, 1f, bt) * er, mg = lerp(0.54f, 1f, bt) * eg, mb = lerp(0.70f, 1f, bt) * eb;   // 3D letters: dim blue-grey -> white
                    float segCx = x0 + sg.x + sg.w / 2f;
                    float onset0 = sg.f0 * sw, span = (sg.f1 - sg.f0) * sw * 0.8f;     // the letters of a piece are sung one after the other
                    if (sg.legacy) {                                     // letters the 3D font does not have: flat vanilla font (moves as one piece)
                        letterMotion(sg.base, L.total, tIn, onset0, sl, p, dimK);
                        float pcy = rowY + mOff;
                        float sharpA = wordA * mA * (0.42f + 0.58f * bt);
                        if (!sp(segCx, pcy)) continue;                   // behind you
                        int a = (int) (255 * sharpA);
                        if (a < 8) continue;                             // tiny alpha would be treated as opaque by vanilla
                        // vanilla text is laid out in px (x right, y down); this matrix puts those px onto the sign in the world
                        AFF.set(prx, pry, prz, 0f, pux, puy, puz, 0f, pnx, pny, pnz, 0f,
                                pox + segCx * prx, poy + pcy * puy, poz + segCx * prz, 1f);
                        MT.set(WORLD_M).mul(AFF).scale(LEG * mSx, LEG * mSy, 1f);
                        tr.draw(sg.ot, -sg.lw / 2f, -4f, rgb(cr, cg, cb, a), true, MT, legacyVc(), TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                        legacyUsed = true;
                        drawn++;
                        continue;
                    }
                    for (int i = 0; i < sg.cp.length; i++) {
                        MeshFont.Glyph g = MeshFont.get(sg.cp[i]);
                        letterMotion(sg.base + i, L.total, tIn, onset0 + span * i / Math.max(1, sg.n), sl, p, dimK);
                        float pen = x0 + sg.x + sg.gx[i];
                        float foot = pen + g.adv * 0.5f;                          // the letter stays planted on its own foot
                        float base = rowY + BASE + mOff;
                        meshGlyph(g, pen, base, foot, mSx, mSy, mLean, mr, mg, mb, wordA * mA);
                    }
                }
            }
        }
    }
}
