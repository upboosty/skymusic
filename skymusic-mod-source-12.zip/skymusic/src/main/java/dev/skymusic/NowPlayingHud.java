package dev.skymusic;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.TextureUtil;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.GlUniform;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.file.Path;

/**
 * "Now Playing" widget in the top right corner: album cover (from the FLAC / MP3 tags), title, artist, progress bar, time, duration.
 *
 * Look: real-time liquid glass. The widget is ONE quad drawn by the core shader assets/skymusic/shaders/core/glass.fsh. Before it is drawn,
 * the few pixels of the screen behind the widget are copied into a small texture (a few hundred x ~100 px, no full-screen pass), and the
 * shader refracts and frosts that copy at the curved rim, adds the specular rim light, bevel, sheen and glint, the drop shadow, the cover,
 * the glowing progress bar and the equalizer. The text on top is vanilla text. If the shader cannot be loaded (or the GL copy fails on some
 * device) the widget silently falls back to a flat translucent panel; the first reason is shown by /sky debug.
 *
 * Time: the bar uses AudioPlayer.getPosition(), which is the same steady clock that drives the lyrics (without the manual /sky sync offset).
 */
public final class NowPlayingHud {
    private NowPlayingHud() {}

    private static volatile boolean enabled = true;
    private static volatile boolean forceFlat = false;
    private static String flatWhy = "";

    // ---- track (set by begin() on the main thread, filled in by the loader thread) ----
    private record Loaded(int gen, String title, String artist, CoverArt art) {}
    private static volatile int gen = 0;
    private static volatile Loaded loaded;
    private static String title = "", artist = "";
    private static Identifier coverId;
    private static int coverSeq = 0, coverN = 192;
    private static boolean hasCover = false, dropCover = false;

    // ---- animation state ----
    private static float appear = 0f, shown = 0f, playK = 0f, loadingK = 0f, coverMix = 0f, topOff = 0f;
    private static double lastPos = 0, lastDur = 0;
    private static long lastNs = 0;
    private static final long T0 = System.nanoTime();
    private static final float[] eq = {2.2f, 2.2f, 2.2f, 2.2f};
    private static final float[] acc = {0.80f, 0.82f, 1.00f}, acc2 = {0.22f, 0.20f, 0.42f};
    private static final float[] accT = {0.80f, 0.82f, 1.00f}, acc2T = {0.22f, 0.20f, 0.42f};

    // ---- GL objects ----
    private static ShaderProgram prog;
    private static boolean progFailed = false, glassBroken = false;
    private static int glFrames = 0;
    private static int btex = 0, btW = 0, btH = 0;

    // ---- layout (GUI units) ----
    private static final float H = 50f, M = 12f, COVER = 30f, PAD = 6f, MARGIN_R = 6f, MARGIN_T = 6f;

    public static void init() {
        HudRenderCallback.EVENT.register(NowPlayingHud::render);
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(
            new SimpleSynchronousResourceReloadListener() {
                @Override public Identifier getFabricId() { return new Identifier("skymusic", "nowplaying"); }
                @Override public void reload(ResourceManager rm) {
                    if (prog != null) { try { prog.close(); } catch (Throwable ignored) {} prog = null; }
                    progFailed = false;
                }
            });
    }

    public static LiteralArgumentBuilder<FabricClientCommandSource> node() {
        LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("hud");
        root.then(ClientCommandManager.literal("on").executes(c -> { enabled = true; SkyMusicClient.msg("Now Playing widget: on"); return 1; }));
        root.then(ClientCommandManager.literal("off").executes(c -> { enabled = false; SkyMusicClient.msg("Now Playing widget: off"); return 1; }));
        root.then(ClientCommandManager.literal("glass").executes(c -> {
            forceFlat = false; progFailed = false; glassBroken = false; glFrames = 0;
            SkyMusicClient.msg("Now Playing widget: liquid glass (falls back to flat by itself if the device cannot do it)"); return 1; }));
        root.then(ClientCommandManager.literal("flat").executes(c -> { forceFlat = true; SkyMusicClient.msg("Now Playing widget: flat (no shader)"); return 1; }));
        root.then(ClientCommandManager.literal("info").executes(c -> { SkyMusicClient.msg("Now Playing widget: " + status()); return 1; }));
        return root;
    }

    public static String status() {
        String look = forceFlat ? "flat (forced)" : (glassBroken || progFailed) ? "flat (" + flatWhy + ")" : "liquid glass";
        return (enabled ? "on" : "off") + ", " + look + ", " + (hasCover ? "cover loaded" : "no cover yet");
    }

    // ------------------------------------------------------------------ track loading
    /** a new song starts: forget the old one and load tags + cover on a background thread */
    public static void begin(Path file, Path dir) {
        final int g = ++gen;
        loaded = null;
        String n = file.getFileName().toString();
        int dot = n.lastIndexOf('.');
        final String stem = dot < 0 ? n : n.substring(0, dot);
        title = stem;
        artist = "";
        hasCover = false;
        dropCover = true;
        coverMix = 0f;
        lastPos = 0; lastDur = 0; shown = 0f;
        Thread t = new Thread(() -> {
            try {
                TrackInfo info = TrackInfo.read(file, dir);
                String ti = info.title, ar = info.artist;
                if (ti == null || ar == null) {                           // "Artist - Title" in the file name
                    int i = stem.indexOf(" - ");
                    if (i > 0 && i + 3 < stem.length()) {
                        if (ar == null) ar = stem.substring(0, i).trim();
                        if (ti == null) ti = stem.substring(i + 3).trim();
                    }
                }
                if (ti == null) ti = stem;
                if (ar == null) ar = "";
                CoverArt art = null;
                if (info.picture != null) {
                    try { art = decode(info.picture); } catch (Throwable ignored) {}
                }
                if (art == null) art = CoverArt.generated(ti + "|" + ar);
                if (g == gen) loaded = new Loaded(g, ti, ar, art);
            } catch (Throwable ignored) {
                if (g == gen) loaded = new Loaded(g, stem, "", CoverArt.generated(stem));
            }
        }, "skymusic-cover");
        t.setDaemon(true);
        t.start();
    }

    /** the song stopped: the widget fades out by itself */
    public static void end() {
        gen++;
        loaded = null;
    }

    /** jpg / png / bmp ... -> small square RGBA (stb_image is part of Minecraft's LWJGL) */
    private static CoverArt decode(byte[] data) {
        ByteBuffer in = MemoryUtil.memAlloc(data.length);
        try (MemoryStack stack = MemoryStack.stackPush()) {
            in.put(data).flip();
            IntBuffer w = stack.mallocInt(1), h = stack.mallocInt(1), ch = stack.mallocInt(1);
            if (!STBImage.stbi_info_from_memory(in, w, h, ch)) throw new IllegalStateException("unknown image format");
            if ((long) w.get(0) * h.get(0) > 40_000_000L) throw new IllegalStateException("cover too large");
            ByteBuffer px = STBImage.stbi_load_from_memory(in, w, h, ch, 4);
            if (px == null) throw new IllegalStateException("cannot decode cover");
            try {
                byte[] rgba = new byte[w.get(0) * h.get(0) * 4];
                px.get(rgba);
                return CoverArt.fromRgba(rgba, w.get(0), h.get(0));
            } finally {
                STBImage.stbi_image_free(px);
            }
        } finally {
            MemoryUtil.memFree(in);
        }
    }

    private static void destroyCover(MinecraftClient mc) {
        if (coverId != null) { mc.getTextureManager().destroyTexture(coverId); coverId = null; }
        dropCover = false;
    }

    private static void consumeLoaded(MinecraftClient mc) {
        Loaded l = loaded;
        if (l == null || l.gen() != gen) return;
        loaded = null;
        title = l.title();
        artist = l.artist();
        CoverArt a = l.art();
        try {
            NativeImage img = new NativeImage(NativeImage.Format.RGBA, a.size, a.size, false);
            for (int y = 0; y < a.size; y++) for (int x = 0; x < a.size; x++) img.setColor(x, y, a.abgr[y * a.size + x]);
            NativeImageBackedTexture tex = new NativeImageBackedTexture(img);
            Identifier id = new Identifier("skymusic", "cover/" + (++coverSeq));
            mc.getTextureManager().registerTexture(id, tex);
            GlStateManager._bindTexture(tex.getGlId());
            GlStateManager._texParameter(3553, 10241, 9729);     // smooth, no mipmaps
            GlStateManager._texParameter(3553, 10240, 9729);
            GlStateManager._texParameter(3553, 10242, 33071);    // clamp to edge
            GlStateManager._texParameter(3553, 10243, 33071);
            if (coverId != null) mc.getTextureManager().destroyTexture(coverId);
            coverId = id;
            coverN = a.size;
            hasCover = true;
        } catch (Throwable t) {
            hasCover = false;
        }
        System.arraycopy(a.accent, 0, accT, 0, 3);
        System.arraycopy(a.accent2, 0, acc2T, 0, 3);
    }

    private static void release(MinecraftClient mc) {
        destroyCover(mc);
        hasCover = false;
        if (btex != 0) { GlStateManager._deleteTexture(btex); btex = 0; btW = 0; btH = 0; }
    }

    // ------------------------------------------------------------------ drawing
    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : Math.min(v, hi); }
    private static float ease(float k) { float u = 1f - clamp(k, 0f, 1f); return 1f - u * u * u; }

    private static void render(DrawContext dc, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (now - lastNs) / 1e9f);
        lastNs = now;
        AudioPlayer pl = SkyMusicClient.PLAYER;
        boolean active = pl.isActive() || pl.isLoading();
        if (dropCover) destroyCover(mc);
        if (active) consumeLoaded(mc);

        boolean show = enabled && active && mc.player != null && !mc.options.hudHidden && !mc.options.debugEnabled;
        appear += ((show ? 1f : 0f) - appear) * (1f - (float) Math.exp(-dt * (show ? 8f : 6f)));
        if (!show && appear < 0.004f) {
            appear = 0f;
            if (!active && (coverId != null || btex != 0)) release(mc);
            return;
        }

        // ---- time: the lyrics clock ----
        double pos = pl.getPosition(), dur = pl.duration;
        if (pos >= 0) { lastPos = pos; lastDur = dur; }
        double uPos = pos >= 0 ? pos : lastPos, uDur = pos >= 0 ? dur : lastDur;
        float target = uDur > 0 ? (float) Math.max(0, Math.min(1, uPos / uDur)) : 0f;
        shown += (target - shown) * (1f - (float) Math.exp(-dt * 22f));
        if (Math.abs(target - shown) < 0.0003f) shown = target;
        playK += ((pos >= 0 && !pl.isPaused() ? 1f : 0f) - playK) * (1f - (float) Math.exp(-dt * 7f));
        loadingK += ((uDur <= 0 && pl.isLoading() ? 1f : 0f) - loadingK) * (1f - (float) Math.exp(-dt * 8f));
        coverMix += ((hasCover ? 1f : 0f) - coverMix) * (1f - (float) Math.exp(-dt * 5f));
        float ck = 1f - (float) Math.exp(-dt * 5f);
        for (int i = 0; i < 3; i++) { acc[i] += (accT[i] - acc[i]) * ck; acc2[i] += (acc2T[i] - acc2[i]) * ck; }
        float time = (float) (((now - T0) / 1e9) % 1000.0);
        for (int i = 0; i < 4; i++) {
            float ph = time * (4.2f + i * 1.37f) + i * 2.1f;
            float a = 0.5f + 0.5f * (float) (Math.sin(ph) * 0.6 + Math.sin(ph * 2.3 + i) * 0.4);
            float tg = 2.2f + (11f - 2.2f) * a * playK;
            eq[i] += (tg - eq[i]) * (1f - (float) Math.exp(-dt * 16f));
        }

        // ---- layout: top right, below the effect icons if there are any ----
        var win = mc.getWindow();
        float scale = (float) win.getScaleFactor();
        int fbW = win.getFramebufferWidth(), fbH = win.getFramebufferHeight();
        float guiW = fbW / scale;
        float W = clamp(guiW * 0.60f, 116f, 168f);
        boolean ben = false, harm = false;
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            if (!e.shouldShowIcon()) continue;
            if (e.getEffectType().isBeneficial()) ben = true; else harm = true;
        }
        topOff += (((ben ? 25f : 0f) + (harm ? 25f : 0f)) - topOff) * (1f - (float) Math.exp(-dt * 10f));
        float e = ease(appear);
        float bx = guiW - MARGIN_R - W + (1f - e) * 16f;
        float by = MARGIN_T + topOff - (1f - e) * 10f;
        float A = clamp(appear * 1.2f, 0f, 1f);
        if (A < 0.01f) return;

        dc.draw();                                                         // everything the game drew before us must be on screen first
        boolean glass = !forceFlat && drawGlass(dc, mc, bx, by, W, scale, fbW, fbH, A, time);
        if (!glass) drawFlat(dc, bx, by, W, A);
        drawTexts(dc, mc.textRenderer, bx, by, W, A, uPos, uDur, time);
    }

    // ---- liquid glass ----
    private static ShaderProgram program(MinecraftClient mc) {
        if (prog != null) return prog;
        if (progFailed) return null;
        try {
            prog = new ShaderProgram(mc.getResourceManager(), "skymusic:glass", VertexFormats.POSITION);
        } catch (Throwable t) {
            progFailed = true;
            flatWhy = "shader failed: " + t.getMessage();
            SkyMusicClient.msg("Now Playing: liquid glass shader could not start, using the flat look (" + t.getMessage() + ")");
            return null;
        }
        return prog;
    }

    private static void setU(String n, float a, float b, float c, float d) {
        GlUniform u = prog.getUniform(n);
        if (u != null) u.set(a, b, c, d);
    }

    private static void ensureBackdrop(int w, int h) {
        if (btex != 0 && w == btW && h == btH) return;
        if (btex == 0) btex = TextureUtil.generateTextureId();
        GlStateManager._activeTexture(GL13.GL_TEXTURE0);
        GlStateManager._bindTexture(btex);
        GlStateManager._texParameter(3553, 10241, 9729);
        GlStateManager._texParameter(3553, 10240, 9729);
        GlStateManager._texParameter(3553, 10242, 33071);
        GlStateManager._texParameter(3553, 10243, 33071);
        GlStateManager._texImage2D(3553, 0, GL11.GL_RGBA8, w, h, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, (IntBuffer) null);
        btW = w; btH = h;
    }

    private static boolean drawGlass(DrawContext dc, MinecraftClient mc, float bx, float by, float W, float scale, int fbW, int fbH, float A, float time) {
        if (glassBroken) return false;
        ShaderProgram sp = program(mc);
        if (sp == null) return false;

        // the part of the screen behind the widget (and its shadow), in real pixels
        int qx0 = (int) Math.floor((bx - M) * scale), qy0 = (int) Math.floor((by - M) * scale);
        int qx1 = (int) Math.ceil((bx + W + M) * scale), qy1 = (int) Math.ceil((by + H + M) * scale);
        int cx0 = Math.max(0, qx0), cy0 = Math.max(0, qy0), cx1 = Math.min(fbW, qx1), cy1 = Math.min(fbH, qy1);
        int bw = cx1 - cx0, bh = cy1 - cy0;
        if (bw <= 0 || bh <= 0) return true;                              // completely off screen
        int texW = (int) Math.ceil((W + 2 * M) * scale) + 2, texH = (int) Math.ceil((H + 2 * M) * scale) + 2;
        if (bw > texW || bh > texH) return true;

        boolean check = glFrames < 4;
        if (check) { for (int i = 0; i < 8 && GL11.glGetError() != 0; i++) { /* drop errors that are not ours */ } }
        ensureBackdrop(texW, texH);
        GlStateManager._activeTexture(GL13.GL_TEXTURE0);
        GlStateManager._bindTexture(btex);
        GL11.glCopyTexSubImage2D(GL11.GL_TEXTURE_2D, 0, 0, texH - bh, cx0, fbH - cy1, bw, bh);
        if (check) {
            int err = GL11.glGetError();
            glFrames++;
            if (err != 0) {
                glassBroken = true;
                flatWhy = "screen copy failed, GL error " + err;
                SkyMusicClient.msg("Now Playing: this device cannot copy the screen for the glass, using the flat look (GL error " + err + ")");
                return false;
            }
        }

        setU("Quad", cx0 / scale, cy0 / scale, texW / scale, texH / scale);
        setU("Body", bx + W / 2f, by + H / 2f, W / 2f, H / 2f);
        setU("BodyP", 12f, 1f / scale, time, A);
        setU("CoverR", bx + PAD + COVER / 2f, by + PAD + COVER / 2f, COVER / 2f, 7f);
        setU("BarR", bx + W / 2f, by + 39.4f, (W - 16f) / 2f, 1.3f);
        setU("BarP", shown, playK, loadingK, coverMix);
        setU("EqA", bx + W - 8f - 11.4f, by + 13f, 1.8f, 1.4f);
        setU("EqH", eq[0], eq[1], eq[2], eq[3]);
        setU("Accent", acc[0], acc[1], acc[2], 1f);
        setU("Accent2", acc2[0], acc2[1], acc2[2], 1f);

        RenderSystem.setShader(() -> prog);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        if (coverId != null) RenderSystem.setShaderTexture(0, coverId); else RenderSystem.setShaderTexture(0, btex);
        RenderSystem.setShaderTexture(1, btex);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        Matrix4f m = dc.getMatrices().peek().getPositionMatrix();
        float x0 = cx0 / scale, y0 = cy0 / scale, x1 = cx1 / scale, y1 = cy1 / scale;
        BufferBuilder bb = Tessellator.getInstance().getBuffer();
        bb.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION);
        bb.vertex(m, x0, y1, 0f).next();
        bb.vertex(m, x1, y1, 0f).next();
        bb.vertex(m, x1, y0, 0f).next();
        bb.vertex(m, x0, y0, 0f).next();
        BufferRenderer.drawWithGlobalProgram(bb.end());
        return true;
    }

    // ---- flat fallback (no shader) ----
    private static int argb(float a, float r, float g, float b) {
        return (Math.round(clamp(a, 0f, 1f) * 255f) << 24) | (Math.round(clamp(r, 0f, 1f) * 255f) << 16) | (Math.round(clamp(g, 0f, 1f) * 255f) << 8) | Math.round(clamp(b, 0f, 1f) * 255f);
    }

    private static void rrect(DrawContext dc, int x0, int y0, int x1, int y1, int r, int col) {
        r = Math.max(0, Math.min(r, Math.min((x1 - x0) / 2, (y1 - y0) / 2)));
        if (r == 0) { dc.fill(x0, y0, x1, y1, col); return; }
        dc.fill(x0, y0 + r, x1, y1 - r, col);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(Math.max(0.0, r * r - dy * dy)));
            dc.fill(x0 + inset, y0 + i, x1 - inset, y0 + i + 1, col);
            dc.fill(x0 + inset, y1 - i - 1, x1 - inset, y1 - i, col);
        }
    }

    private static void drawFlat(DrawContext dc, float bx, float by, float W, float A) {
        int x0 = Math.round(bx), y0 = Math.round(by), x1 = Math.round(bx + W), y1 = Math.round(by + H);
        rrect(dc, x0 - 1, y0 - 1, x1 + 1, y1 + 2, 11, argb(0.18f * A, 0f, 0f, 0f));
        rrect(dc, x0, y0, x1, y1, 10, argb(0.80f * A, 0.07f + acc2[0] * 0.12f, 0.08f + acc2[1] * 0.12f, 0.11f + acc2[2] * 0.12f));
        dc.fill(x0 + 10, y0, x1 - 10, y0 + 1, argb(0.30f * A, 1f, 1f, 1f));
        int cx = Math.round(bx + PAD), cy = Math.round(by + PAD), cs = Math.round(COVER);
        rrect(dc, cx, cy, cx + cs, cy + cs, 6, argb(A, acc2[0] * 1.2f, acc2[1] * 1.2f, acc2[2] * 1.2f));
        if (coverId != null && hasCover) {
            RenderSystem.enableBlend();
            RenderSystem.setShaderColor(1f, 1f, 1f, A * coverMix);
            int n = coverN;
            dc.drawTexture(coverId, cx + 1, cy + 1, cs - 2, cs - 2, 0f, 0f, n, n, n, n);
            RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        }
        int bl = Math.round(bx + 8f), br = Math.round(bx + W - 8f), bm = Math.round(by + 39.4f);
        rrect(dc, bl, bm - 1, br, bm + 2, 1, argb(0.25f * A, 1f, 1f, 1f));
        int fw = Math.round((br - bl) * shown);
        if (fw > 1) rrect(dc, bl, bm - 1, bl + fw, bm + 2, 1, argb(A, acc[0] * 0.6f + 0.4f, acc[1] * 0.6f + 0.4f, acc[2] * 0.6f + 0.4f));
        int ex = Math.round(bx + W - 8f - 11.4f), ey = Math.round(by + 13f);
        for (int i = 0; i < 4; i++) {
            int h = Math.max(2, Math.round(eq[i])), x = ex + i * 3;
            dc.fill(x, ey - h / 2, x + 2, ey - h / 2 + h, argb(0.9f * A, 0.93f, 0.94f, 1f));
        }
    }

    // ---- text (vanilla font, on top of the glass) ----
    private static String fmt(double sec) {
        int s = (int) Math.max(0, Math.floor(sec));
        return s >= 3600 ? String.format("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60) : String.format("%d:%02d", s / 60, s % 60);
    }

    private static float marquee(float overflow, float t, float phase) {
        if (overflow <= 0.5f) return 0f;
        float travel = overflow / 14f, pause = 1.6f, cyc = 2f * pause + 2f * travel;
        float u = (t + phase) % cyc, k;
        if (u < pause) k = 0f;
        else if (u < pause + travel) k = (u - pause) / travel;
        else if (u < 2f * pause + travel) k = 1f;
        else k = 1f - (u - 2f * pause - travel) / travel;
        k = k * k * (3f - 2f * k);
        return -overflow * k;
    }

    private static void text(DrawContext dc, TextRenderer tr, Text t, float x, float y, float sc, int rgb, float alpha) {
        int a = Math.round(clamp(alpha, 0f, 1f) * 255f);
        if (a < 8) return;
        MatrixStack ms = dc.getMatrices();
        ms.push();
        ms.translate(x, y, 0f);
        ms.scale(sc, sc, 1f);
        dc.drawText(tr, t, 0, 0, (a << 24) | rgb, true);
        ms.pop();
    }

    private static void drawTexts(DrawContext dc, TextRenderer tr, float bx, float by, float W, float A, double pos, double dur, float time) {
        float x0 = bx + PAD + COVER + 6f, x1 = bx + W - 8f - 11.4f - 5f, avail = x1 - x0;
        Text ti = Text.literal(title).formatted(Formatting.BOLD);
        String ar = artist.isEmpty() ? "Unknown artist" : artist;
        Text at = Text.literal(ar);
        float tw = tr.getWidth(ti), aw = tr.getWidth(at) * 0.86f;
        dc.enableScissor((int) Math.floor(x0), (int) Math.floor(by + 4f), (int) Math.ceil(x1), (int) Math.ceil(by + 17.5f));
        text(dc, tr, ti, x0 + marquee(tw - avail, time, 0f), by + 7f, 1f, 0xFFFFFF, A);
        dc.disableScissor();
        dc.enableScissor((int) Math.floor(x0), (int) Math.floor(by + 17.5f), (int) Math.ceil(x1), (int) Math.ceil(by + 29f));
        text(dc, tr, at, x0 + marquee(aw - avail, time, 2.3f), by + 18.6f, 0.86f, 0xBFC3D2, A * 0.95f);
        dc.disableScissor();
        String cur = fmt(pos), tot = dur > 0 ? fmt(dur) : "-:--";
        text(dc, tr, Text.literal(cur), bx + 8f, by + 42.4f, 0.68f, 0xC9CDDB, A * 0.9f);
        text(dc, tr, Text.literal(tot), bx + W - 8f - tr.getWidth(tot) * 0.68f, by + 42.4f, 0.68f, 0xC9CDDB, A * 0.9f);
    }
}
