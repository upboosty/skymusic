#version 150
// Sky Music liquid-glass Now Playing widget. The whole widget (shadow, glass, cover, progress bar, equalizer) is ONE quad.
// Sampler0 = album cover, Sampler1 = a copy of the few pixels of the screen behind the widget (refracted + blurred = the glass).
// All sizes are in GUI units, y points down.
uniform sampler2D Sampler0;
uniform sampler2D Sampler1;
uniform vec4 ColorModulator;
uniform vec4 Quad;      // x, y, w, h of the quad = of the backdrop copy
uniform vec4 Body;      // centre x, y, half width, half height of the glass
uniform vec4 BodyP;     // corner radius, GUI units per real pixel, time (s), opacity
uniform vec4 CoverR;    // centre x, y, half size, corner radius of the cover
uniform vec4 BarR;      // centre x, y, half width, half height of the progress track
uniform vec4 BarP;      // played part 0..1, playing 0..1, loading 0..1, has cover 0..1
uniform vec4 EqA;       // equalizer: left x, centre y, bar width, gap
uniform vec4 EqH;       // equalizer: bar heights
uniform vec4 Accent;    // album colour (bright) rgb, glow strength
uniform vec4 Accent2;   // second album colour rgb, cover fade-in 0..1
in vec2 pos;
out vec4 fragColor;

float sdRound(vec2 p, vec2 hs, float r) {
    vec2 q = abs(p) - hs + vec2(r);
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}
float cover01(float d, float px) { return 1.0 - smoothstep(-px * 0.8, px * 0.8, d); }

vec3 backdrop(vec2 gp) {
    vec2 uv = vec2((gp.x - Quad.x) / Quad.z, 1.0 - (gp.y - Quad.y) / Quad.w);
    return texture(Sampler1, uv).rgb;
}
// small frosted-glass blur: 9 taps
vec3 frost(vec2 gp, float r) {
    vec3 s = backdrop(gp) * 0.24;
    s += backdrop(gp + vec2(r, 0.0)) * 0.095;
    s += backdrop(gp + vec2(-r, 0.0)) * 0.095;
    s += backdrop(gp + vec2(0.0, r)) * 0.095;
    s += backdrop(gp + vec2(0.0, -r)) * 0.095;
    s += backdrop(gp + vec2(r, r) * 0.7071) * 0.095;
    s += backdrop(gp + vec2(-r, r) * 0.7071) * 0.095;
    s += backdrop(gp + vec2(r, -r) * 0.7071) * 0.095;
    s += backdrop(gp + vec2(-r, -r) * 0.7071) * 0.095;
    return s;
}
float capsule(vec2 c, vec2 hs, float px) { return cover01(sdRound(pos - c, hs, min(hs.x, hs.y)), px); }

void main() {
    float px = BodyP.y;
    float T = BodyP.z;
    float A = BodyP.w;
    vec2 hs = Body.zw;
    float R = BodyP.x;
    vec2 p = pos - Body.xy;
    float d = sdRound(p, hs, R);
    if (d > 13.0) discard;

    float mask = cover01(d, px);
    // soft drop shadow (a little lower than the glass)
    float sh = (1.0 - smoothstep(-3.0, 11.0, sdRound(p - vec2(0.0, 2.8), hs, R))) * 0.46;
    vec3 shCol = vec3(0.0, 0.0, 0.02) + Accent.rgb * 0.05;

    vec3 col = shCol;
    if (mask > 0.0) {
        // ---- the curved edge of the glass: how far from the rim, and which way the rim faces ----
        float bevel = 10.0;
        float e = clamp(-d / bevel, 0.0, 1.0);
        float eps = 0.8;
        vec2 g = vec2(sdRound(p + vec2(eps, 0.0), hs, R) - sdRound(p - vec2(eps, 0.0), hs, R),
                      sdRound(p + vec2(0.0, eps), hs, R) - sdRound(p - vec2(0.0, eps), hs, R));
        g = g / max(length(g), 0.0001);                       // outward normal
        float lens = pow(1.0 - e, 2.3);                       // bends the light strongly at the rim, not at all in the middle
        vec2 disp = -g * lens * 9.0;

        // ---- what the glass shows: the screen behind it, bent and frosted, with a little colour fringing at the rim ----
        vec3 base = frost(pos + disp, 2.4);
        float fr = lens * 0.9;
        base.r = mix(base.r, backdrop(pos + disp * 1.16).r, fr);
        base.b = mix(base.b, backdrop(pos + disp * 0.84).b, fr);
        float lum = dot(base, vec3(0.299, 0.587, 0.114));
        vec3 glass = mix(vec3(lum), base, 1.4);               // vivid
        glass = glass * 0.47 + vec3(0.040, 0.044, 0.060);     // smoked
        float gl0 = dot(glass, vec3(0.299, 0.587, 0.114));
        glass *= mix(1.0, min(1.0, 0.36 / max(gl0, 0.001)), 0.75);   // bright sky / snow behind the glass never washes the white text out
        glass = mix(glass, Accent2.rgb * 0.5 + Accent.rgb * 0.18, 0.20);   // tinted by the album
        float ty = (p.y + hs.y) / (2.0 * hs.y);               // 0 top .. 1 bottom
        glass += vec3(0.05) * (1.0 - ty) * (1.0 - ty);
        glass *= 1.0 - 0.10 * ty;

        // album glow behind the cover
        float cd = length(pos - CoverR.xy) / (CoverR.z * 2.4);
        glass += Accent.rgb * Accent.a * 0.26 * exp(-cd * cd);

        // ---- light: from the top left ----
        vec2 L = normalize(vec2(-0.55, -0.83));
        float facing = dot(g, L);
        float rw = max(1.2, px * 1.7);
        float rim = 1.0 - smoothstep(0.0, rw, -d);
        float rimL = rim * (0.62 * smoothstep(0.0, 1.0, facing) + 0.30 * smoothstep(0.0, 1.0, -facing) + 0.10);
        glass += vec3(1.0) * rimL;
        glass += vec3(0.95, 0.97, 1.0) * pow(1.0 - e, 3.0) * (0.07 + 0.16 * max(facing, 0.0));   // lit bevel
        glass -= vec3(0.06) * pow(1.0 - e, 2.0) * max(-facing, 0.0);                           // shaded bevel
        // big soft sheen on the upper half + a small bright caustic in the top-left corner
        float sheen = (1.0 - smoothstep(0.0, 0.60, ty)) * (1.0 - smoothstep(0.55, 1.0, abs(p.x) / hs.x)) * 0.075;
        vec2 bq = (p - vec2(-hs.x + R * 0.95, -hs.y + R * 0.85)) / (R * 0.65);
        float blob = exp(-dot(bq, bq)) * 0.20;
        // a slow glint that sweeps across now and then
        float sw = dot(p, normalize(vec2(1.0, -0.42)));
        float cyc = fract(T * 0.105);
        float gs = mix(-hs.x * 1.5, hs.x * 1.5, cyc);
        float gq = (sw - gs) / (hs.y * 0.5);
        float glint = exp(-gq * gq) * 0.11 * smoothstep(0.0, 0.12, e);
        glass += vec3(1.0) * (sheen + blob + glint);

        // ---- cover ----
        vec2 cp = pos - CoverR.xy;
        float dc = sdRound(cp, vec2(CoverR.z), CoverR.w);
        glass *= 1.0 - 0.34 * (1.0 - smoothstep(-1.0, 5.5, sdRound(cp - vec2(0.0, 1.7), vec2(CoverR.z), CoverR.w))) * (1.0 - cover01(dc, px));
        float cm = cover01(dc, px);
        if (cm > 0.0) {
            vec2 cuv = cp / (2.0 * CoverR.z) + 0.5;
            vec3 art = texture(Sampler0, cuv).rgb;
            vec3 ph = mix(Accent.rgb * 0.7, Accent2.rgb * 0.5, clamp(cuv.x * 0.6 + cuv.y * 0.8, 0.0, 1.0));
            vec3 cc = mix(ph, art, BarP.w);
            cc = mix(vec3(dot(cc, vec3(0.299, 0.587, 0.114))), cc, 1.12);
            cc += vec3(1.0) * 0.13 * (1.0 - smoothstep(0.0, 0.9, (cuv.x + cuv.y) * 0.62));    // gloss on the corner
            float crim = 1.0 - smoothstep(0.0, max(1.0, px * 1.5), -dc);
            cc += vec3(1.0) * crim * (0.16 + 0.22 * max(dot(normalize(cp + vec2(0.001)), L), 0.0));
            glass = mix(glass, cc, cm * Accent2.a);
        }

        // ---- progress bar ----
        float tm = capsule(BarR.xy, BarR.zw, px);
        float left = BarR.x - BarR.z;
        float u = (pos.x - left) / (2.0 * BarR.z);
        vec3 track = mix(glass * 0.62, vec3(0.80, 0.82, 0.92), 0.30);
        track += vec3(1.0) * 0.10 * (1.0 - smoothstep(0.0, BarR.w * 1.6, pos.y - (BarR.y - BarR.w)));   // lit upper edge of the groove
        glass = mix(glass, track, tm);
        float sq = (u - fract(T * 0.7)) / 0.16;
        float shim = BarP.z * exp(-sq * sq) * 0.55;
        glass += (Accent.rgb * 0.5 + 0.5) * shim * tm;
        float fw = 2.0 * BarR.z * BarP.x;
        if (fw > 0.05) {
            float fh = min(BarR.w, fw * 0.5);
            float fm = cover01(sdRound(pos - vec2(left + fw * 0.5, BarR.y), vec2(fw * 0.5, BarR.w), fh), px);
            float k = clamp((pos.x - left) / max(fw, 1.0), 0.0, 1.0);
            vec3 fc = mix(Accent.rgb * 0.55 + vec3(0.42), vec3(1.0), smoothstep(0.0, 1.0, k));
            fc *= 0.80 + 0.20 * BarP.y;
            fc += vec3(1.0) * 0.18 * (1.0 - smoothstep(0.0, BarR.w * 1.5, pos.y - (BarR.y - BarR.w)));
            glass = mix(glass, fc, fm);
            // glowing head
            vec2 hp = pos - vec2(left + fw, BarR.y);
            float hr = length(hp);
            float halo = exp(-(hr * hr) / (2.0 * 4.2 * 4.2)) * 0.50 * BarP.y;
            glass += (Accent.rgb * 0.6 + 0.4) * halo;
            float knob = cover01(hr - BarR.w * 1.35, px);
            glass = mix(glass, vec3(1.0), knob * (0.55 + 0.45 * BarP.y));
        }

        // ---- equalizer ----
        float st = EqA.z + EqA.w;
        float eq = capsule(vec2(EqA.x + EqA.z * 0.5, EqA.y), vec2(EqA.z * 0.5, EqH.x * 0.5), px);
        eq = max(eq, capsule(vec2(EqA.x + st + EqA.z * 0.5, EqA.y), vec2(EqA.z * 0.5, EqH.y * 0.5), px));
        eq = max(eq, capsule(vec2(EqA.x + 2.0 * st + EqA.z * 0.5, EqA.y), vec2(EqA.z * 0.5, EqH.z * 0.5), px));
        eq = max(eq, capsule(vec2(EqA.x + 3.0 * st + EqA.z * 0.5, EqA.y), vec2(EqA.z * 0.5, EqH.w * 0.5), px));
        glass = mix(glass, vec3(0.93, 0.94, 1.0), eq * 0.92);

        // tiny dither against banding in the dark gradients
        float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
        glass += vec3((n - 0.5) / 255.0);
        col = glass;
    }
    float a = clamp(mask + sh * (1.0 - mask), 0.0, 1.0);
    vec3 rgb = (col * mask + shCol * sh * (1.0 - mask)) / max(a, 0.0001);
    fragColor = vec4(rgb, a * A) * ColorModulator;
}
