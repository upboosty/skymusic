#version 150
// Sky Music liquid-glass Now Playing widget: vertex stage (one quad, GUI coordinates).
in vec3 Position;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
out vec2 pos;
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    pos = Position.xy;
}
