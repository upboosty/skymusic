package dev.skymusic;

import net.minecraft.util.Identifier;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;

/**
 * Metrics of the baked lyric atlas (assets/skymusic/font/lyrics_atlas.txt, made by tools/gen_lyric_font.py).
 * Every glyph exists as 0 = sharp, 1 = soft (light blur, "out of focus"), 2 = glow (big blur, halo / soft shadow).
 * All lengths are converted to the layout unit of SkyRenderer ("px of a 20 px font").
 */
final class LyricFont {
    static final Identifier TEX = new Identifier("skymusic", "textures/font/lyrics_atlas.png");
    static boolean ok = false;

    static final class Glyph {
        float adv;                                       // pen advance
        final boolean[] has = new boolean[3];
        final float[] u0 = new float[3], v0 = new float[3], u1 = new float[3], v1 = new float[3];
        final float[] ox = new float[3], oy = new float[3];   // top-left of the quad, from the pen origin on the baseline (y down)
        final float[] w = new float[3], h = new float[3];     // size of the quad
    }

    private static final HashMap<Integer, Glyph> GLYPHS = new HashMap<>();
    static Glyph get(int cp) { return GLYPHS.get(cp); }

    static void load() {
        try (InputStream in = LyricFont.class.getResourceAsStream("/assets/skymusic/font/lyrics_atlas.txt")) {
            if (in == null) return;
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            float aw = 1f, ah = 1f, unit = 20f / 84f;
            String ln;
            while ((ln = r.readLine()) != null) {
                ln = ln.trim();
                if (ln.isEmpty() || ln.charAt(0) == '#') continue;
                String[] p = ln.split("\\s+");
                if (p[0].equals("atlas")) {
                    aw = Float.parseFloat(p[1]); ah = Float.parseFloat(p[2]);
                    unit = 20f / Float.parseFloat(p[3]);
                    continue;
                }
                Glyph g = new Glyph();
                int cp = Integer.parseInt(p[0]);
                g.adv = Float.parseFloat(p[1]) * unit;
                for (int v = 0; v < 3; v++) {
                    String s = p[2 + v];
                    if (s.equals("-")) continue;
                    String[] q = s.split(",");
                    float x = Float.parseFloat(q[0]), y = Float.parseFloat(q[1]), w = Float.parseFloat(q[2]), h = Float.parseFloat(q[3]);
                    float ox = Float.parseFloat(q[4]), oy = Float.parseFloat(q[5]), k = Float.parseFloat(q[6]);
                    g.has[v] = true;
                    g.u0[v] = x / aw; g.v0[v] = y / ah; g.u1[v] = (x + w) / aw; g.v1[v] = (y + h) / ah;
                    g.ox[v] = ox * unit; g.oy[v] = oy * unit; g.w[v] = w * k * unit; g.h[v] = h * k * unit;
                }
                GLYPHS.put(cp, g);
            }
            ok = GLYPHS.size() > 40;
        } catch (Throwable e) {
            ok = false;
        }
    }
}
