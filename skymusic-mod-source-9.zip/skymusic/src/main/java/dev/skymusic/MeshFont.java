package dev.skymusic;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.util.HashMap;

/**
 * The 3D lyric font: flat letter outlines baked by tools/gen_text3d.py (assets/skymusic/font/text3d.bin).
 * SkyRenderer extrudes them into solid letters. All lengths here are in the layout unit of SkyRenderer ("px of a 20 px font"),
 * y points DOWN from the baseline.
 */
final class MeshFont {
    /** size of 1 em in layout px. Impact's capital letters are 0.79 em high, so 18.6 gives capitals about 14.7 px high */
    static final float EM = 18.6f;
    /** extra space between letters (layout px) */
    static final float TRACK = 0.9f;
    static boolean ok = false;

    static final class Glyph {
        float adv;        // advance (layout px, without TRACK)
        float[] tri;      // front face: 6 floats per triangle (x0 y0 x1 y1 x2 y2)
        float[] seg;      // outline edges: 8 floats per edge (x0 y0 x1 y1 n0x n0y n1x n1y); n = direction the side wall faces at that end (x right, y down)
        float[] gn;       // per edge: 2 floats, the unit normal of the flat side wall pointing out of the letter (0, 0 = degenerate edge); lets LyricMesh skip the walls that face away from you
        int nTri, nSeg;
    }

    private static final HashMap<Integer, Glyph> GLYPHS = new HashMap<>();

    static Glyph get(int cp) { return GLYPHS.get(cp); }

    static void load() {
        GLYPHS.clear();
        ok = false;
        try (InputStream raw = MeshFont.class.getResourceAsStream("/assets/skymusic/font/text3d.bin")) {
            if (raw == null) return;
            DataInputStream in = new DataInputStream(new BufferedInputStream(raw));
            if (in.readInt() != 0x33444654) return;
            int count = in.readInt();
            final float q = EM / 8192f;
            for (int i = 0; i < count; i++) {
                int cp = in.readInt();
                Glyph g = new Glyph();
                g.adv = in.readFloat() * EM;
                g.nTri = in.readShort();
                g.nSeg = in.readShort();
                g.tri = new float[g.nTri * 6];
                for (int k = 0; k < g.tri.length; k++) g.tri[k] = in.readShort() * q;
                g.seg = new float[g.nSeg * 8];
                g.gn = new float[g.nSeg * 2];
                for (int k = 0; k < g.nSeg; k++) {
                    float x0 = in.readShort() * q, y0 = in.readShort() * q, x1 = in.readShort() * q, y1 = in.readShort() * q;
                    float n0x = in.readByte() / 127f, n0y = in.readByte() / 127f, n1x = in.readByte() / 127f, n1y = in.readByte() / 127f;
                    int o = k * 8;
                    g.seg[o] = x0; g.seg[o + 1] = y0; g.seg[o + 2] = x1; g.seg[o + 3] = y1;
                    g.seg[o + 4] = n0x; g.seg[o + 5] = n0y; g.seg[o + 6] = n1x; g.seg[o + 7] = n1y;
                    float ex = x1 - x0, ey = y1 - y0, len = (float) Math.sqrt(ex * ex + ey * ey);
                    if (len > 1e-5f) {                                   // the wall is flat: its true normal is the edge turned by 90 degrees, on the side the baked smooth normals point to
                        float gx = ey / len, gy = -ex / len;
                        if (gx * (n0x + n1x) + gy * (n0y + n1y) < 0f) { gx = -gx; gy = -gy; }
                        g.gn[k * 2] = gx; g.gn[k * 2 + 1] = gy;
                    }
                }
                GLYPHS.put(cp, g);
            }
            ok = !GLYPHS.isEmpty();
        } catch (Throwable t) {
            GLYPHS.clear();
            ok = false;
        }
    }
}
