package dev.skymusic;

/**
 * Motion of ONE lyric letter. Pure math (no Minecraft classes), so tools/LyricPreview.java runs exactly this code offline.
 *
 * Every letter is a piece of jelly. It
 *  - ENTERS like a card that is stood up: it springs up from below, tilts up to face you and rolls straight, stretching while it flies
 *    and squashing when it lands (underdamped spring, so it overshoots a little and settles),
 *  - is SUNG with a hop, a wobble (squash / stretch / sway / a little roll), a short swell and a small pop toward you,
 *  - LEAVES word by word: it stretches, shrinks a little, rolls, leans back and drifts up into the mist,
 *  - and BREATHES while it is lit (a very slow wave runs along the line).
 * Every term starts at 0 without a jolt (no letter ever jumps), everything is a function of time (the same at any frame rate), and
 * nothing here allocates or calls more than a handful of sin / exp per letter (settled letters take the early outs).
 *
 * Results are left in the static fields below (one letter at a time, render thread only).
 */
final class LyricMotion {
    private LyricMotion() {}

    // ---- results of letter() ----
    /** scale across / along the letter (1 = normal) */
    static float sx = 1f, sy = 1f;
    /** sideways shift of the top per unit of height (shear) */
    static float lean;
    /** turn in the plane of the sign, radians, + = clockwise seen from the front */
    static float roll;
    /** turn about the horizontal axis through the letter's foot, radians, + = the top leans away from you */
    static float tilt;
    /** vertical offset in layout px, down = + */
    static float yoff;
    /** offset toward you in layout px (the letters are solids: they pop out of the sign a little) */
    static float zoff;
    /** opacity from the entrance (0..1) */
    static float alpha;
    /** 0..1: a short brightness pop at the moment the letter is sung */
    static float flash;
    /** 0..1: the glow behind the letter (rises when it is sung, fades over about a second) */
    static float bloom;

    // ---- tuning ----
    private static final double ENTER_Z = 0.40, ENTER_W = 14.0;      // springy entrance of every letter (damping ratio, rad/s)
    static final float ENTER_DROP = 22f;                             // letters fly up from this far below (layout px)
    private static final float ENTER_VN = (float) peakVel(ENTER_Z, ENTER_W);
    private static final float TILT_IN = 0.55f;                      // radians: a new letter lies back this far and stands up
    private static final float ROLL_IN = 0.20f;                      // radians: and starts rolled this far (alternating per letter) and straightens
    private static final float ZPOP = 3.0f;                          // layout px a sung letter pops toward you (it overshoots a little)
    private static final float MAX_ANGLE = 0.85f;                    // the polynomial sin / cos in LyricMesh are exact enough up to here

    private static float sPos, sVel;                                  // result of springPV()

    // ---- small helpers ----
    private static float sm(float x) { x = x < 0f ? 0f : (x > 1f ? 1f : x); return x * x * (3f - 2f * x); }

    /** a fixed random number 0..1 for every letter number (so the line never moves in lock step) */
    private static final float[] RND = new float[256];
    static {
        for (int i = 0; i < 256; i++) RND[i] = MistTrail.hash(i, 77);
    }

    /** sin(phase + step * i) for every letter number i with one sin / cos per frame instead of one per letter */
    private static final class Wave {
        private final float[] s = new float[256], c = new float[256];
        private float bs, bc;
        Wave(double step) { for (int i = 0; i < 256; i++) { s[i] = (float) Math.sin(step * i); c[i] = (float) Math.cos(step * i); } }
        void frame(double phase) { bs = (float) Math.sin(phase); bc = (float) Math.cos(phase); }
        float at(int i) { i &= 255; return bs * c[i] + bc * s[i]; }
    }
    private static final Wave W_BREATH = new Wave(0.65), W_BOB = new Wave(0.9), W_WAVE = new Wave(-0.42), W_ROLL = new Wave(0.8);

    /** call once per frame with the animation clock (seconds) */
    static void frame(double animSecs) {
        W_BREATH.frame(animSecs * 3.4);
        W_BOB.frame(animSecs * 2.3);
        W_WAVE.frame(animSecs * 1.9);
        W_ROLL.frame(animSecs * 1.7);
    }

    // ---- springs ----
    private static double peakVel(double z, double w) {
        double wd = w * Math.sqrt(1.0 - z * z), k = z * w, t = Math.atan(wd / k) / wd;
        return w * w / wd * Math.exp(-k * t) * Math.sin(wd * t);
    }

    /** underdamped spring 0 -> 1 with its own damping ratio z and frequency w; sPos = position, sVel = velocity (1/s) */
    private static void springPV(float t, double z, double w) {
        if (t <= 0f) { sPos = 0f; sVel = 0f; return; }
        double wd = w * Math.sqrt(1.0 - z * z), k = z * w;
        if (t > 9.0 / k) { sPos = 1f; sVel = 0f; return; }
        double e = Math.exp(-k * t), c = Math.cos(wd * t), sn = Math.sin(wd * t);
        sPos = (float) (1.0 - e * (c + (k / wd) * sn));
        sVel = (float) (e * (w * w / wd) * sn);
    }

    /** damped jelly shake: starts at 0 without a jolt, about 0.7 at the first swing, gone after ~1 s */
    private static float wobble(float t) {
        if (t <= 0f || t > 1.7f) return 0f;
        float ramp = t >= 0.04f ? 1f : sm(t / 0.04f);
        return ramp * (float) (Math.exp(-5.2 * t) * Math.sin(21.0 * t));
    }

    /** the sideways part of the shake (slower, so it does not move in lock step with the squash) */
    private static float sway(float t) {
        if (t <= 0f || t > 1.7f) return 0f;
        float ramp = t >= 0.05f ? 1f : sm(t / 0.05f);
        return ramp * (float) (Math.exp(-4.6 * t) * Math.sin(17.0 * t));
    }

    /** 0..1: how white a letter that is sung at `onset` is by now (it appears slightly before the onset and is white a moment later) */
    static float lit(float tIn, float onset) { return sm((tIn - onset + 0.10f) / 0.38f); }

    /** 0..1: the glow of a letter that was sung `ts` seconds ago (rises in 70 ms, fades over about a second) */
    static float bloomAt(float ts) {
        return ts > 0f && ts < 1.0f ? sm(ts / 0.07f) * (1f - sm((ts - 0.05f) / 0.95f)) : 0f;
    }

    /**
     * Motion of one letter. gi = its number in the line (the wave runs along the line), tIn = seconds since the line was born,
     * onset = when this letter is sung, sl = how far it has left (0..1), p = how sung its word is (0..1), dimK = line dimming (0..1).
     */
    static void letter(int gi, float tIn, float onset, float sl, float p, float dimK) {
        final float sgn = (gi & 1) == 0 ? 1f : -1f;
        final float var = 0.7f + 0.6f * RND[gi & 255];

        // ---- entrance: springs up from below, stood up like a card, stretches while it flies and squashes when it lands
        float te = tIn - (onset - 0.22f);                       // a letter appears when it is about to be sung (not all at once with the line)
        springPV(te, ENTER_Z, ENTER_W);
        float e = sPos, v = sVel / ENTER_VN;
        if (v < 0f) v *= 2.4f;                                  // the way back down is slower: exaggerate it so the landing really squashes
        float syy = 1f + 0.26f * v, sxx = 1f - 0.17f * v;
        float off = (1f - e) * ENTER_DROP;
        float tl = TILT_IN * (1f - e);                          // overshoots with the spring: the letter leans toward you a hair, then settles
        float ro = sgn * var * ROLL_IN * (1f - e);
        alpha = sm(te / 0.20f);

        // ---- sung: wobble, sway, hop, pop toward you, a short swell
        float ts = tIn - onset;
        float wv = wobble(ts);
        syy *= 1f + 0.20f * wv;  sxx *= 1f - 0.13f * wv;
        float swy = sway(ts);
        float ln = sgn * 0.12f * swy;
        ro += sgn * var * 0.060f * swy;                         // the sway is also a real wiggle, not only a shear
        springPV(ts, 0.50, 15.0);
        off -= 3.2f * sPos;                                     // sung letters hop up a little and settle with a bounce
        float zo = ZPOP * sPos;                                 // ... and pop out of the sign the same way
        if (ts > 0f && ts < 0.42f) {                            // a short swell, like the word being emphasised
            float sw = 1f + 0.055f * (float) Math.sin(Math.PI * ts / 0.42);
            sxx *= sw; syy *= sw;
        }

        // ---- leaving: stretch while drifting up, shrink a little, roll, lean back into the mist
        if (sl > 0f) {
            float ev = (float) Math.sin(Math.PI * sl);
            syy *= 1f + 0.14f * ev;  sxx *= 1f - 0.09f * ev;
            float shr = 1f - 0.10f * sm(sl);
            sxx *= shr; syy *= shr;
            off -= sl * 7f;
            ro += sgn * var * 0.22f * sl * sl;
            tl += 0.30f * sl;
            zo -= 3.5f * sl;
        }

        // ---- idle: lit letters breathe, just barely, and a very slow wave runs along the line
        float idleK = p * (1f - dimK) * (1f - sl) * alpha;
        if (idleK > 0.001f) {
            float br = W_BREATH.at(gi);
            syy *= 1f + 0.014f * br * idleK;
            sxx *= 1f - 0.009f * br * idleK;
            off += (0.5f * W_BOB.at(gi) + 0.8f * W_WAVE.at(gi)) * idleK;
            ro += 0.011f * W_ROLL.at(gi) * idleK;
        }

        // ---- the brightness pop and the glow that follow the singing
        float fl = ts > 0f && ts < 0.55f ? sm(ts / 0.04f) * (1f - sm((ts - 0.03f) / 0.52f)) : 0f;
        float live = (1f - sl) * (1f - dimK);
        flash = fl * live;
        bloom = bloomAt(ts) * live;

        sx = sxx; sy = syy; lean = ln;
        roll = ro > MAX_ANGLE ? MAX_ANGLE : (ro < -MAX_ANGLE ? -MAX_ANGLE : ro);
        tilt = tl > MAX_ANGLE ? MAX_ANGLE : (tl < -MAX_ANGLE ? -MAX_ANGLE : tl);
        yoff = off;
        zoff = zo;
    }
}
