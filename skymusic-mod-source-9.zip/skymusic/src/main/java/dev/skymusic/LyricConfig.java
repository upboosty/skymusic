package dev.skymusic;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

/**
 * Everything about the size, the spawn distance and the look of the lyric mist that you may want to tweak, in ONE place:
 * config/skymusic-lyrics.properties (created with the defaults and explanations the first time the game starts).
 * Edit the file and run /sky config reload, or use the /sky trail ... commands, which save the file for you.
 */
public final class LyricConfig {
    private LyricConfig() {}

    // ---- text size ----
    /** blocks per layout px: THE size of the text, the same for every line. A capital letter is about 14.7 px high, a row of text is 26 px. */
    public static volatile float scale = 0.034f;
    /** widest row in blocks (at /sky size 100); longer lines wrap onto more rows instead of shrinking */
    public static volatile float wrapWidth = 8.5f;

    // ---- where lines are born ----
    /** preferred distance band (blocks from the player) */
    public static volatile float spawnNear = 6.5f, spawnFar = 10.0f;
    /** hard limit: a line is never born farther than this from the player's eyes */
    public static volatile float spawnLimit = 12.0f;
    /** the middle of the text is born this many blocks above the player's FEET (+ a random 0..heightSpan) */
    public static volatile float heightMin = 1.6f, heightSpan = 0.6f;

    // ---- mist trail ----
    public static volatile boolean trailEnabled = true;
    public static volatile boolean trailPuffs = true;
    /** soft glow behind the letters (a bloom that follows the singing, and the light behind each row), 0..1 (0 = off) */
    public static volatile float glow = 0.5f;
    /** twinkling sparkles that fly off every letter when it is sung */
    public static volatile boolean sparkles = true;
    /** peak opacity of a wisp, 0..1 */
    public static volatile float trailOpacity = 0.70f;
    /** radius and thickness multiplier */
    public static volatile float trailSize = 1.0f;
    /** animation speed multiplier */
    public static volatile float trailSpeed = 1.0f;
    /** how many loops it makes around the row */
    public static volatile float trailCurl = 1.0f;
    /** wisps per row, 1..4 (more = fuller and slower) */
    public static volatile int trailLayers = 3;

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("skymusic-lyrics.properties"); }

    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : Math.min(v, hi); }

    private static float f(Properties p, String key, float def, float lo, float hi) {
        try { String v = p.getProperty(key); if (v != null) return clamp(Float.parseFloat(v.trim()), lo, hi); } catch (Exception ignored) {}
        return def;
    }

    private static boolean b(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : v.trim().equalsIgnoreCase("true");
    }

    /** reads the file (and writes it with the defaults if it does not exist yet) */
    public static void load() {
        Path f = file();
        try {
            if (Files.exists(f)) {
                Properties p = new Properties();
                try (var in = Files.newBufferedReader(f)) { p.load(in); }
                scale = f(p, "scale", scale, 0.005f, 0.2f);
                wrapWidth = f(p, "wrapWidth", wrapWidth, 2f, 40f);
                spawnNear = f(p, "spawnNear", spawnNear, 1f, 60f);
                spawnFar = Math.max(spawnNear + 0.5f, f(p, "spawnFar", spawnFar, 1.5f, 80f));
                spawnLimit = Math.max(spawnFar, f(p, "spawnLimit", spawnLimit, 2f, 100f));
                heightMin = f(p, "heightMin", heightMin, 0.5f, 6f);
                heightSpan = f(p, "heightSpan", heightSpan, 0f, 4f);
                trailEnabled = b(p, "trail", trailEnabled);
                trailPuffs = b(p, "trailPuffs", trailPuffs);
                glow = f(p, "glow", glow, 0f, 1f);
                sparkles = b(p, "sparkles", sparkles);
                trailOpacity = f(p, "trailOpacity", trailOpacity, 0f, 1f);
                trailSize = f(p, "trailSize", trailSize, 0.2f, 3f);
                trailSpeed = f(p, "trailSpeed", trailSpeed, 0.1f, 4f);
                trailCurl = f(p, "trailCurl", trailCurl, 0.2f, 3f);
                trailLayers = (int) clamp(f(p, "trailLayers", trailLayers, 1f, 4f), 1f, 4f);
            } else {
                save();
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            Files.createDirectories(file().getParent());
            Files.writeString(file(), template());
        } catch (Exception ignored) {}
    }

    private static String n(float v) { return String.format(Locale.ROOT, "%.3f", v).replaceAll("0+$", "0").replaceAll("\\.$", ".0"); }

    private static String template() {
        return "# Sky Music: lyric text size, spawn distance and the mist trail.\n"
             + "# Edit, save, then run  /sky config reload  in the game (or restart). Delete the file to get the defaults back.\n"
             + "\n"
             + "# --- text size -------------------------------------------------------------------------------------------\n"
             + "# Blocks per layout pixel: THE size of the text, the same for every line (a capital is ~14.7 px high, a row 26 px).\n"
             + "# 0.034 = capitals ~0.5 blocks tall, rows ~0.9 blocks apart. 0.016 was the old, smaller size.\n"
             + "scale=" + n(scale) + "\n"
             + "# Widest row in blocks. Longer lines wrap onto more rows (the letters never shrink).\n"
             + "wrapWidth=" + n(wrapWidth) + "\n"
             + "\n"
             + "# --- where lines are born (blocks from the player) --------------------------------------------------------\n"
             + "# Preferred distance band. Bigger text wants more distance; keep the two scaled together.\n"
             + "spawnNear=" + n(spawnNear) + "\n"
             + "spawnFar=" + n(spawnFar) + "\n"
             + "# Hard limit: never born farther than this from your eyes.\n"
             + "spawnLimit=" + n(spawnLimit) + "\n"
             + "# Height of the middle of the text above your FEET: heightMin + random(0..heightSpan). Eyes are at 1.62.\n"
             + "heightMin=" + n(heightMin) + "\n"
             + "heightSpan=" + n(heightSpan) + "\n"
             + "\n"
             + "# --- mist trail ----------------------------------------------------------------------------------------\n"
             + "trail=" + trailEnabled + "\n"
             + "# Soft cloud puffs along the wisps (turn off for a thinner, cheaper trail).\n"
             + "trailPuffs=" + trailPuffs + "\n"
             + "# Soft glow: a bloom behind every letter that follows the singing, and light behind each row, 0..1 (0 = off).\n"
             + "glow=" + n(glow) + "\n"
             + "# Twinkling sparkles that fly off every letter as it is sung (off = a little cheaper). Only at the higher performance steps.\n"
             + "sparkles=" + sparkles + "\n"
             + "# Peak opacity of a wisp, 0..1.\n"
             + "trailOpacity=" + n(trailOpacity) + "\n"
             + "# Radius / thickness multiplier (1 = default).\n"
             + "trailSize=" + n(trailSize) + "\n"
             + "# Animation speed multiplier (1 = default, 0.5 = twice as slow).\n"
             + "trailSpeed=" + n(trailSpeed) + "\n"
             + "# How many loops it makes around the row (1 = default).\n"
             + "trailCurl=" + n(trailCurl) + "\n"
             + "# Wisps per row, 1..4 (the performance step lowers this automatically on weak devices).\n"
             + "trailLayers=" + trailLayers + "\n";
    }

    // ------------------------------------------------------------------ commands
    /** /sky trail on | off | opacity <0-100> | size <20-300> | speed <20-400> | layers <1-4> | puffs on | off | sparkles on | off | glow <0-100> */
    public static LiteralArgumentBuilder<FabricClientCommandSource> trailNode() {
        LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("trail");
        root.then(ClientCommandManager.literal("on").executes(c -> { trailEnabled = true; save(); SkyMusicClient.msg("Mist trail: on"); return 1; }));
        root.then(ClientCommandManager.literal("off").executes(c -> { trailEnabled = false; save(); SkyMusicClient.msg("Mist trail: off"); return 1; }));
        root.then(ClientCommandManager.literal("puffs")
            .then(ClientCommandManager.literal("on").executes(c -> { trailPuffs = true; save(); SkyMusicClient.msg("Mist puffs: on"); return 1; }))
            .then(ClientCommandManager.literal("off").executes(c -> { trailPuffs = false; save(); SkyMusicClient.msg("Mist puffs: off"); return 1; })));
        root.then(ClientCommandManager.literal("sparkles")
            .then(ClientCommandManager.literal("on").executes(c -> { sparkles = true; save(); SkyMusicClient.msg("Letter sparkles: on"); return 1; }))
            .then(ClientCommandManager.literal("off").executes(c -> { sparkles = false; save(); SkyMusicClient.msg("Letter sparkles: off"); return 1; })));
        root.then(ClientCommandManager.literal("glow").then(ClientCommandManager.argument("percent", FloatArgumentType.floatArg(0, 100))
            .executes(c -> { glow = FloatArgumentType.getFloat(c, "percent") / 100f; save(); SkyMusicClient.msg("Letter glow: " + Math.round(glow * 100) + "% (default 50)"); return 1; })));
        root.then(ClientCommandManager.literal("opacity").then(ClientCommandManager.argument("percent", FloatArgumentType.floatArg(0, 100))
            .executes(c -> { trailOpacity = FloatArgumentType.getFloat(c, "percent") / 100f; save(); SkyMusicClient.msg("Mist opacity: " + Math.round(trailOpacity * 100) + "% (default 70)"); return 1; })));
        root.then(ClientCommandManager.literal("size").then(ClientCommandManager.argument("percent", FloatArgumentType.floatArg(20, 300))
            .executes(c -> { trailSize = FloatArgumentType.getFloat(c, "percent") / 100f; save(); SkyMusicClient.msg("Mist size: " + Math.round(trailSize * 100) + "% (default 100)"); return 1; })));
        root.then(ClientCommandManager.literal("speed").then(ClientCommandManager.argument("percent", FloatArgumentType.floatArg(20, 400))
            .executes(c -> { trailSpeed = FloatArgumentType.getFloat(c, "percent") / 100f; save(); SkyMusicClient.msg("Mist speed: " + Math.round(trailSpeed * 100) + "% (default 100)"); return 1; })));
        root.then(ClientCommandManager.literal("layers").then(ClientCommandManager.argument("n", IntegerArgumentType.integer(1, 4))
            .executes(c -> { trailLayers = IntegerArgumentType.getInteger(c, "n"); save(); SkyMusicClient.msg("Mist wisps per row: " + trailLayers + " (default 3)"); return 1; })));
        return root;
    }

    /** /sky config reload | info */
    public static LiteralArgumentBuilder<FabricClientCommandSource> configNode() {
        LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("config");
        root.then(ClientCommandManager.literal("reload").executes(c -> { load(); SkyMusicClient.msg("Lyric config reloaded: " + summary() + " (applies to lines born from now on)"); return 1; }));
        root.then(ClientCommandManager.literal("info").executes(c -> { SkyMusicClient.msg(summary() + "  file: " + file()); return 1; }));
        return root;
    }

    public static String summary() {
        return "scale " + n(scale) + ", wrap " + n(wrapWidth) + " blocks, spawn " + n(spawnNear) + "-" + n(spawnFar) + " (max " + n(spawnLimit) + "), trail "
            + (trailEnabled ? "on" : "off") + " sparkles " + (sparkles ? "on" : "off") + " opacity " + Math.round(trailOpacity * 100) + "% size " + Math.round(trailSize * 100) + "% speed " + Math.round(trailSpeed * 100) + "% layers " + trailLayers;
    }
}
