package dev.skymusic;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Giant animated lyrics floating in the sky: custom bundled font, letters pop in one by one,
 * a karaoke colour sweep follows the song, the active letter bumps, old line floats away, next line previews below.
 *
 * Rendering: every glyph is positioned on an imaginary sky sphere around the camera, projected to the screen with the
 * world camera matrices, and drawn through the normal 2D text path (same path as the hotbar numbers / chat). That path
 * works everywhere; the old in-world text path depends on culling, fog, depth and camera maths all being right.
 * (Side effect: the lyrics are part of the HUD, so F1 hides them.)
 */
public class SkyRenderer {
    public static volatile boolean customFont = true;
    /** 0 = never, 1 = always, 2 = auto: a small plain subtitle only while the sky lyrics are out of view */
    public static volatile int subtitleMode = 2;
    public static volatile String status = "not rendered yet";

    private static final Identifier FONT_ID = new Identifier("skymusic", "lyrics");
    private static final Style CUSTOM = Style.EMPTY.withFont(FONT_ID);

    private static final float ROW_GAP = 26f;       // text-space px between rows (font size 20)
    private static final float GLYPH_MID = 10f;     // about half a glyph's height
    private static final float MAX_SCALE = 0.26f;   // world units per text px (short lines)
    private static final float TARGET_W = 40f;      // max line width in blocks
    private static final double DIST = 70;          // radius of the lyric dome (blocks)
    public static volatile float ELEV = 0.45f;       // elevation of the lyric block centre in radians (~26 degrees up), /sky height <deg>
    private static boolean anchored = false;
    private static float anchorYaw = 0;
    private static int lastSlot = -99;
    private static boolean errorShown = false;

    // camera matrices captured at the end of the world render, used by the HUD pass
    private static final Matrix4f VP = new Matrix4f();
    private static boolean haveVP = false;
    private static float camYaw = 0, camPitch = 0;
    private static double camX = 0, camY = 0, camZ = 0;
    private static float scrW = 1, scrH = 1;

    public static void init() {
        WorldRenderEvents.LAST.register(SkyRenderer::capture);
        HudRenderCallback.EVENT.register(SkyRenderer::renderHud);
    }

    public static void recheckFont() { fontChecked = false; }

    private static void capture(WorldRenderContext ctx) {
        VP.set(ctx.projectionMatrix()).mul(ctx.matrixStack().peek().getPositionMatrix());
        camYaw = ctx.camera().getYaw();
        camPitch = ctx.camera().getPitch();
        camX = ctx.camera().getPos().x; camY = ctx.camera().getPos().y; camZ = ctx.camera().getPos().z;
        haveVP = true;
    }

    // ---------- font ----------
    private static boolean fontChecked = false, fontBroken = false;
    /** the bundled TTF needs FreeType; if it is unavailable every glyph becomes the same "missing" box, so fall back to the vanilla font */
    private static boolean useCustomFont(TextRenderer tr) {
        if (!customFont) return false;
        if (!fontChecked) {
            try {
                int wi = tr.getWidth(Text.literal("i").setStyle(CUSTOM)), ww = tr.getWidth(Text.literal("W").setStyle(CUSTOM));
                fontBroken = wi == ww;
            } catch (Throwable e) { fontBroken = true; }
            fontChecked = true;
        }
        return !fontBroken;
    }

    // ---------- layout of one lyric line ----------
    private static final class Layout {
        Text[][] g; float[][] x, w; float[] rowW; int rows, n; float maxW = 1f;
    }

    // layouts are cached by text; the carousel draws up to four lines at once
    private static final java.util.HashMap<String, Layout> LAYOUTS = new java.util.HashMap<>();
    private static boolean layoutCustom = true;
    private static Layout layoutFor(String text, TextRenderer tr, boolean custom) {
        if (custom != layoutCustom || LAYOUTS.size() > 64) { LAYOUTS.clear(); layoutCustom = custom; }
        Layout l = LAYOUTS.get(text);
        if (l == null) { l = build(text, tr, custom); LAYOUTS.put(text, l); }
        return l;
    }

    private static Layout build(String text, TextRenderer tr, boolean custom) {
        String[] rows = wrap(text);
        Layout L = new Layout();
        L.rows = rows.length;
        L.g = new Text[rows.length][]; L.x = new float[rows.length][]; L.w = new float[rows.length][];
        L.rowW = new float[rows.length];
        for (int r = 0; r < rows.length; r++) {
            int[] cps = rows[r].codePoints().toArray();
            L.g[r] = new Text[cps.length]; L.x[r] = new float[cps.length]; L.w[r] = new float[cps.length];
            float cx = 0;
            for (int k = 0; k < cps.length; k++) {
                Text t = Text.literal(new String(Character.toChars(cps[k]))).setStyle(custom ? CUSTOM : Style.EMPTY);
                float wd = tr.getWidth(t);
                if (Character.isWhitespace(cps[k])) wd = Math.max(wd, custom ? 8.5f : 5f);   // the font's own space is narrower than an "I", words ran together
                else wd += custom ? 0.8f : 0.4f;                                              // a touch of letter spacing
                L.g[r][k] = t; L.x[r][k] = cx; L.w[r][k] = wd;
                cx += wd; L.n++;
            }
            L.rowW[r] = cx;
            L.maxW = Math.max(L.maxW, cx);
        }
        return L;
    }

    private static String[] wrap(String s) {
        s = s.trim();
        int len = s.codePointCount(0, s.length());
        int k = Math.min(5, Math.max(1, (int) Math.ceil(len / 21.0)));
        if (k == 1) return new String[]{s};
        String[] words = s.split("\\s+");
        int target = (int) Math.ceil(len / (double) k);
        List<String> rows = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : words) {
            if (cur.length() > 0 && cur.length() + 1 + w.length() > target && rows.size() < k - 1) {
                rows.add(cur.toString()); cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        rows.add(cur.toString());
        return rows.toArray(new String[0]);
    }

    // ---------- helpers ----------
    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static float easeOutBack(float x) {
        float c1 = 1.70158f, c3 = c1 + 1f, u = x - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }
    private static float easeOutCubic(float x) { float u = 1f - x; return 1f - u * u * u; }
    private static float smooth(float x) { return x * x * (3f - 2f * x); }
    private static float lerp(float a, float b, float f) { return a + (b - a) * f; }
    private static float wrapDeg(float d) { return ((d % 360f) + 540f) % 360f - 180f; }
    private static int rgb(float r, float g, float b, int a) {
        return (a << 24) | ((int) (clamp01(r) * 255) << 16) | ((int) (clamp01(g) * 255) << 8) | (int) (clamp01(b) * 255);
    }
    private static float[] hsv(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float c = v * s, x = c * (1f - Math.abs((h * 6f) % 2f - 1f)), m = v - c, r, g, b;
        int i = (int) (h * 6f);
        switch (i) {
            case 0: r = c; g = x; b = 0; break;
            case 1: r = x; g = c; b = 0; break;
            case 2: r = 0; g = c; b = x; break;
            case 3: r = 0; g = x; b = c; break;
            case 4: r = x; g = 0; b = c; break;
            default: r = c; g = 0; b = x;
        }
        return new float[]{r + m, g + m, b + m};
    }
    private static float scaleOf(Layout L) { return Math.min(Math.min(MAX_SCALE, TARGET_W / L.maxW), 20f / (L.rows * ROW_GAP)); }
    private static float heightOf(Layout L, float mult) { return L.rows * ROW_GAP * scaleOf(L) * mult; }

    // ---------- projection ----------
    private static final Vector4f V4 = new Vector4f();
    private static final float[] PC = new float[2], PXR = new float[2], PYD = new float[2];
    private static final Matrix4f AFF = new Matrix4f(), MT = new Matrix4f();

    /** world point (relative to the camera) -> GUI-scaled screen coordinates; false if behind the camera */
    private static boolean project(double x, double y, double z, float[] out) {
        V4.set((float) x, (float) y, (float) z, 1f);
        VP.transform(V4);
        if (V4.w <= 0.05f) return false;
        out[0] = (V4.x / V4.w * 0.5f + 0.5f) * scrW;
        out[1] = (0.5f - V4.y / V4.w * 0.5f) * scrH;
        return true;
    }

    private static boolean centerOnScreen(float yaw, float elev) {
        float ce = (float) Math.cos(elev);
        if (!project(-Math.sin(Math.toRadians(yaw)) * ce * DIST, Math.sin(elev) * DIST, Math.cos(Math.toRadians(yaw)) * ce * DIST, PC)) return false;
        return PC[0] > scrW * 0.05f && PC[0] < scrW * 0.95f && PC[1] > scrH * 0.05f && PC[1] < scrH * 0.95f;
    }

    /**
     * Places a glyph centre on the sky sphere at (gyaw, gel) radians and fills AFF with the 2D affine map
     * text-space -> screen (so glyphs follow the perspective and roll of the sky). s = blocks per text unit.
     */
    private static boolean place(float gyaw, float gel, float s) {
        float ce = (float) Math.cos(gel), se = (float) Math.sin(gel), cg = (float) Math.cos(gyaw), sg = (float) Math.sin(gyaw);
        double cx = -sg * ce * DIST, cy = se * DIST, cz = cg * ce * DIST;
        if (!project(cx, cy, cz, PC)) return false;
        if (PC[0] < -scrW * 0.15f || PC[0] > scrW * 1.15f || PC[1] < -scrH * 0.25f || PC[1] > scrH * 1.25f) return false;
        float k = s * 8f;                                               // probe 8 text units along each axis
        if (!project(cx - cg * k, cy, cz - sg * k, PXR)) return false;                  // text +x = sky "right"
        if (!project(cx - sg * se * k, cy - ce * k, cz + cg * se * k, PYD)) return false; // text +y = sky "down"
        float ax = (PXR[0] - PC[0]) / 8f, ay = (PXR[1] - PC[1]) / 8f, bx = (PYD[0] - PC[0]) / 8f, by = (PYD[1] - PC[1]) / 8f;
        AFF.set(ax, ay, 0f, 0f, bx, by, 0f, 0f, 0f, 0f, 1f, 0f, PC[0], PC[1], 0f, 1f);
        return true;
    }


    /** same as place(), but for a glyph centre at a camera-relative world point on an upright plane whose "right" is (rx, 0, rz). s = blocks per text px. */
    private static boolean placeW(double x, double y, double z, float rx, float rz, float s) {
        if (!project(x, y, z, PC)) return false;
        if (PC[0] < -scrW * 0.15f || PC[0] > scrW * 1.15f || PC[1] < -scrH * 0.25f || PC[1] > scrH * 1.25f) return false;
        float k = s * 8f;
        if (!project(x + rx * k, y, z + rz * k, PXR)) return false;
        if (!project(x, y - k, z, PYD)) return false;
        float ax = (PXR[0] - PC[0]) / 8f, ay = (PXR[1] - PC[1]) / 8f, bx = (PYD[0] - PC[0]) / 8f, by = (PYD[1] - PC[1]) / 8f;
        AFF.set(ax, ay, 0f, 0f, bx, by, 0f, 0f, 0f, 0f, 1f, 0f, PC[0], PC[1], 0f, 1f);
        return true;
    }

    // ---------- main ----------
    private static final double TAU = Math.PI * 2;
    private static final long T0 = System.nanoTime();
    private static long lastNanos = T0;
    private static float dt = 0.016f;

    // Every lyric line is born in the air somewhere in front of you and then stays at those world coordinates.
    private static final float R_SPAWN = 11f;                    // blocks in front of you where a line appears
    private static final float VIEW_HALF_W = 32f;                // it is born inside +-32 degrees sideways of where you look
    private static final float SPOT_LO = -4f, SPOT_HI = 20f;     // and between -4 and +20 degrees up/down from the view centre
    private static final float ABS_LO = -40f, ABS_HI = 55f;      // never on the floor, never straight overhead
    private static final float TURN = 2.0f;                      // how lazily a line turns to face you (1/s)

    private static final class Anchor { double x, y, z; float face; float hwB, hhB; }
    private static final java.util.HashMap<Integer, Anchor> ANCH = new java.util.HashMap<>();
    private static Lrc lastLrc = null;
    private static java.util.Random rng = new java.util.Random();
    private static String lastTitle = null, titleText = "♪", titlePlain = "♪";

    // per-frame context
    private static Lrc ctxLrc;
    // result of chunkInfo()
    private static double cTime, cType, cLeave;

    private static void renderHud(DrawContext dc, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !haveVP) return;
        long now = System.nanoTime();
        dt = Math.max(0.0005f, Math.min(0.05f, (now - lastNanos) / 1e9f));
        lastNanos = now;
        double t = SkyMusicClient.PLAYER.getTime();
        if (t < 0) { anchored = false; status = "no song playing"; return; }
        try {
            scrW = mc.getWindow().getScaledWidth();
            scrH = mc.getWindow().getScaledHeight();
            renderLyrics(dc, mc, t);
        } catch (Throwable e) {
            status = "error: " + e;
            if (!errorShown) { errorShown = true; SkyMusicClient.msg("Lyrics error (please report): " + e); }
        }
    }

    private static int drawn = 0;

    /** chunk 0 = title card, chunk n = lyric line n-1 */
    private static String itemText(int c) {
        if (c == 0) return titleText;
        String s = ctxLrc.lines.get(c - 1).text();
        return s.isEmpty() ? "♪  ♫  ♪" : s;
    }

    /** when chunk c starts, how long its typing takes and when it starts to leave (seconds of song time). false = not shown. */
    private static boolean chunkInfo(int c, int nLines) {
        String tx = itemText(c);
        int len = tx.codePointCount(0, tx.length());
        if (c == 0) {
            double first = ctxLrc != null ? ctxLrc.lines.get(0).time() : 7.0;
            if (ctxLrc != null && first < 1.2) return false;          // lyrics start right away, no room for a title card
            cTime = 0;
            cType = Math.max(0.5, Math.min(first * 0.85, len * 0.075));
            cLeave = Math.min(first, cType + 3.5);
            return true;
        }
        Lrc.Line ln = ctxLrc.lines.get(c - 1);
        double next = c < nLines ? ctxLrc.lines.get(c).time() : ln.time() + 5.0;
        double gap = Math.max(0.3, next - ln.time());
        cTime = ln.time();
        cType = Math.max(0.45, Math.min(gap * 0.85, len * 0.075));      // typing follows the singing, but never drags
        cLeave = cTime + Math.max(0.5, Math.min(gap, cType + 2.6));     // leaves when the next line comes, or a bit after it was sung
        return true;
    }

    /** distance in degrees between two rectangles (negative = overlapping) */
    private static float rectSep(float y, float e, float hw, float hh, float oy, float oe, float ohw, float ohh) {
        return Math.max(Math.abs(y - oy) - (hw + ohw), Math.abs(e - oe) - (hh + ohh));
    }

    /** how far (degrees, as seen from where you stand now) a candidate spot is from an earlier line; large if that line is far away */
    private static float sepToAnchor(Anchor p, float y, float e, float hwD, float hhD) {
        if (p == null) return 99f;
        double dx = p.x - camX, dy = p.y - camY, dz = p.z - camZ;
        double dist = Math.max(0.5, Math.sqrt(dx * dx + dy * dy + dz * dz));
        float elAbs = (float) Math.toDegrees(Math.asin(dy / dist));
        float yawRel = wrapDeg((float) Math.toDegrees(Math.atan2(-dx, dz)) - camYaw) * (float) Math.cos(Math.toRadians(elAbs));
        float elRel = elAbs - (-camPitch);
        float hw = (float) Math.toDegrees(Math.atan(p.hwB / dist)), hh = (float) Math.toDegrees(Math.atan(p.hhB / dist));
        return rectSep(y, e, hwD, hhD, yawRel, elRel, hw, hh);
    }

    /** the fixed place in the world where chunk c lives; picked the first time it is needed, from where you are looking right now */
    private static Anchor anchorFor(int c, Layout L, float bias) {
        Anchor a = ANCH.get(c);
        if (a != null) return a;
        float k = R_SPAWN / (float) DIST;
        float hw = L.maxW * scaleOf(L) * k * 0.5f * 1.15f + 0.4f;
        float hh = heightOf(L, 1f) * k * 0.5f * 1.15f + 0.3f;
        float hwD = (float) Math.toDegrees(Math.atan(hw / R_SPAWN)), hhD = (float) Math.toDegrees(Math.atan(hh / R_SPAWN));
        float lim = Math.max(0f, VIEW_HALF_W - hwD);
        float eLo = SPOT_LO + hhD, eHi = SPOT_HI - hhD;
        if (eLo > eHi) eLo = eHi = (SPOT_LO + SPOT_HI) / 2f;
        Anchor p1 = ANCH.get(c - 1), p2 = ANCH.get(c - 2);
        float by = 0f, be = (eLo + eHi) / 2f, bs = -1e9f;
        for (int tries = 0; tries < 48; tries++) {
            float y = (rng.nextFloat() * 2f - 1f) * lim;
            float e = eLo + rng.nextFloat() * (eHi - eLo);
            float sc = rectSep(y, e, hwD, hhD, 0f, 0f, 3f, 3f) + 4f;                // keep the crosshair clear
            sc = Math.min(sc, Math.min(sepToAnchor(p1, y, e, hwD, hhD), sepToAnchor(p2, y, e, hwD, hhD)));
            if (sc > bs) { bs = sc; by = y; be = e; }
            if (sc >= 5f) break;
        }
        float eAbs = Math.max(ABS_LO, Math.min(ABS_HI, -camPitch + be + bias));
        double er = Math.toRadians(eAbs), ce = Math.cos(er);
        double yr = Math.toRadians(camYaw + by / Math.max(0.35, ce));
        a = new Anchor();
        a.x = camX - Math.sin(yr) * ce * R_SPAWN;
        a.y = camY + Math.sin(er) * R_SPAWN;
        a.z = camZ + Math.cos(yr) * ce * R_SPAWN;
        a.face = (float) Math.atan2(camZ - a.z, camX - a.x);        // starts out facing you
        a.hwB = hw; a.hhB = hh;
        ANCH.put(c, a);
        return a;
    }

    private static float wrapRad(float x) { return (float) (x - TAU * Math.round(x / TAU)); }

    private static void renderLyrics(DrawContext dc, MinecraftClient mc, double t) {
        TextRenderer tr = mc.textRenderer;
        boolean custom = useCustomFont(tr);
        Lrc lrc = SkyMusicClient.lyrics;
        boolean hasLyrics = lrc != null && !lrc.lines.isEmpty();
        int nLines = hasLyrics ? lrc.lines.size() : 0;
        drawn = 0;

        String ttl = SkyMusicClient.title;
        if (ttl == null) ttl = "";
        if (!ttl.equals(lastTitle)) {
            lastTitle = ttl;
            titleText = ttl.isEmpty() ? "♪" : "♪  " + ttl;
            titlePlain = ttl.isEmpty() ? "♪" : "♪ " + ttl;
            ANCH.clear();
        }
        Lrc use = hasLyrics ? lrc : null;
        if (use != lastLrc) { lastLrc = use; ANCH.clear(); rng = new java.util.Random(); }
        ctxLrc = use;
        float bias = (float) Math.toDegrees(ELEV - 0.45f);       // /sky height shifts where new lines are born, up or down

        double secs = (System.nanoTime() - T0) / 1e9;
        float waveBase = (float) ((secs * 3.2) % TAU);
        float hueBase = (float) ((secs * 0.05) % 1.0);
        float k = R_SPAWN / (float) DIST;

        int idx = hasLyrics ? lrc.indexAt(t) : -1;
        int cur = idx + 1;
        String plain = null;
        boolean visible = false;                                   // is the line being sung on screen right now?
        for (int c = Math.max(0, cur - 5); c <= cur; c++) {          // oldest first, so the newest chunk is painted on top
            if (!chunkInfo(c, nLines)) continue;
            double tIn = t - cTime;
            double tLeave = t - cLeave;
            if (tIn < 0 || tLeave > 0.9) continue;
            double type = cType, hold = Math.max(0.8, cLeave - cTime);

            Layout L = layoutFor(itemText(c), tr, custom);
            Anchor an = anchorFor(c, L, bias);
            // turns slowly to face you (upright, only around the vertical axis) so it never looks forced
            float target = (float) Math.atan2(camZ - an.z, camX - an.x);
            an.face += wrapRad(target - an.face) * (1f - (float) Math.exp(-dt * TURN));

            float inE = easeOutCubic(clamp01((float) (tIn / 0.65)));            // slides up into place
            float ex = clamp01((float) (tLeave / 0.8));
            float exE = ex * ex * ex;                                            // and slides up and away when done
            float bob = (float) Math.sin(secs * 0.8 + c * 1.7) * 0.06f;          // barely floating
            double rx = an.x - camX, ry = an.y - camY + bob - (1f - inE) * 0.9f + exE * 1.4f, rz = an.z - camZ;
            float alpha = clamp01((float) (tIn / 0.3));
            float grow = 1f + 0.10f * clamp01((float) (tIn / hold)) + 0.05f * (float) Math.sin(Math.PI * clamp01((float) (tIn / 0.5)));
            float sBlocks = scaleOf(L) * k * grow * (1f - 0.08f * exE);
            float rightX = (float) Math.sin(an.face), rightZ = (float) -Math.cos(an.face);
            draw(dc, tr, L, rx, ry, rz, rightX, rightZ, sBlocks, (float) tIn, (float) type, (float) tLeave,
                 alpha, hueBase + c * 0.11f, waveBase);
            if (c == cur) {
                plain = c == 0 ? titlePlain : itemText(c);
                visible = project(rx, ry, rz, PC) && PC[0] > scrW * 0.04f && PC[0] < scrW * 0.96f && PC[1] > scrH * 0.04f && PC[1] < scrH * 0.96f;
            }
        }
        dc.draw();                            // flush the lyric text now so it sits under the rest of the HUD

        // small plain subtitle when you are not looking at the floating lyrics (or always, /sky subtitle on)
        int sm = subtitleMode;
        if (plain != null && (sm == 1 || (sm == 2 && !visible))) {
            int y = (int) (scrH * 0.12f);
            dc.drawCenteredTextWithShadow(tr, Text.literal(plain), (int) (scrW / 2f), y, 0xFFFFFF);
        }
        status = "playing, t=" + String.format("%.1f", t) + ", glyphs drawn=" + drawn + ", on screen=" + visible
            + ", font=" + (custom ? "custom" : (customFont ? "vanilla (custom font unavailable)" : "vanilla"));
    }

    /**
     * Draws one lyric chunk as an upright sign in the world. (rx, ry, rz) = its centre relative to the camera, (rightX, rightZ) = which way
     * "right" points, s = blocks per text px. tIn = seconds since the chunk started (letters type in as it is sung), type = seconds the
     * typing takes, tLeave = seconds since it started leaving (negative = not leaving yet).
     */
    private static void draw(DrawContext dc, TextRenderer tr, Layout L,
                             double rx, double ry, double rz, float rightX, float rightZ, float s,
                             float tIn, float type, float tLeave, float alpha, float hue, float waveBase) {
        VertexConsumerProvider.Immediate vc = dc.getVertexConsumers();
        Matrix4f hud = dc.getMatrices().peek().getPositionMatrix();
        int haloTaps = Perf.skyQuality >= 2 ? 4 : 2;
        for (int pass = 0; pass < 2; pass++) {       // pass 0 = soft halo, pass 1 = colour
            int gi = 0;
            for (int r = 0; r < L.rows; r++) {
                float rowY = (r - (L.rows - 1) / 2f) * ROW_GAP;
                float x0 = -L.rowW[r] / 2f;
                for (int k = 0; k < L.g[r].length; k++, gi++) {
                    float age = tIn - (gi / (float) L.n) * type * 0.92f;       // seconds since this letter was typed
                    if (age <= 0f) continue;
                    float pe = clamp01(age / 0.32f);
                    float xe = tLeave > 0f ? clamp01((tLeave - gi * 0.012f) / 0.7f) : 0f;   // letters leave left to right
                    int a = (int) (255 * alpha * Math.min(1f, pe * 1.8f) * (1f - xe * xe));
                    if (a < 8) continue;                                // tiny alpha would be treated as opaque by vanilla

                    float pc = easeOutCubic(pe);
                    float fresh = (float) Math.exp(-age * 2.6f);        // 1 for a brand new letter, fades to 0
                    float wave = (float) Math.sin(waveBase + gi * 0.55f) * 1.4f;
                    float sc = (0.4f + 0.6f * easeOutBack(pe)) * (1f + 0.20f * fresh) * (1f - 0.12f * xe);
                    float cx = x0 + L.x[r][k] + L.w[r][k] / 2f;
                    float cy = rowY + wave + (1f - pc) * 10f - xe * 8f;
                    float rot = (1f - pc) * 0.45f * ((gi & 1) == 0 ? 1f : -1f);

                    // glyph centre on the sign: right along the sign, down = lower in the world
                    if (!placeW(rx + rightX * cx * s, ry - cy * s, rz + rightZ * cx * s, rightX, rightZ, s)) continue;
                    MT.set(hud).mul(AFF).scale(sc, sc, 1f).rotateZ(rot);
                    if (pass == 1) drawn++;

                    float gx = -L.w[r][k] / 2f;
                    if (pass == 0) {
                        int ha = (int) (a * (0.10f + 0.34f * fresh));
                        if (ha < 6) continue;
                        int oc = rgb(0.55f, 0.72f, 1f, ha);
                        float o = 2.4f;
                        tr.draw(L.g[r][k], gx - o, -GLYPH_MID, oc, false, MT, vc, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                        tr.draw(L.g[r][k], gx + o, -GLYPH_MID, oc, false, MT, vc, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                        if (haloTaps > 2) {
                            tr.draw(L.g[r][k], gx, -GLYPH_MID - o, oc, false, MT, vc, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                            tr.draw(L.g[r][k], gx, -GLYPH_MID + o, oc, false, MT, vc, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                        }
                    } else {
                        // warm white, with a colourful flash on letters that were just typed
                        float[] ac = hsv(hue + gi * 0.010f, 0.5f, 1f);
                        float cr = 1.00f + (ac[0] - 1.00f) * fresh, cg = 0.97f + (ac[1] - 0.97f) * fresh, cb = 0.90f + (ac[2] - 0.90f) * fresh;
                        tr.draw(L.g[r][k], gx, -GLYPH_MID, rgb(cr, cg, cb, (int) (a * 0.94f)), false, MT, vc, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                    }
                }
            }
        }
    }
}
