package dev.skymusic;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Giant animated lyrics floating in the sky: custom bundled font, letters pop in one by one,
 * a karaoke colour sweep follows the song, the active letter bumps, old line floats away, next line previews below.
 *
 * Rendering: every glyph is positioned on an imaginary sky sphere around the camera, projected to the screen with the
 * world camera matrices, and drawn through the normal 2D text path (same path as the hotbar numbers / chat). That path
 * works everywhere; the old in-world text path depends on culling, fog, depth and camera maths all being right.
 * (Side effect: the lyrics are part of the HUD, so F1 hides them.)
 */
public class SkyRenderer {
    public static volatile boolean customFont = true;
    /** 0 = never, 1 = always, 2 = auto: a small plain subtitle only while the sky lyrics are out of view */
    public static volatile int subtitleMode = 2;
    public static volatile String status = "not rendered yet";

    private static final Identifier FONT_ID = new Identifier("skymusic", "lyrics");
    private static final Style CUSTOM = Style.EMPTY.withFont(FONT_ID);

    private static final float ROW_GAP = 26f;       // text-space px between rows (font size 20)
    private static final float GLYPH_MID = 10f;     // about half a glyph's height
    private static final float MAX_SCALE = 0.9f;    // world units per text px (short lines)
    private static final float TARGET_W = 92f;      // max line width in blocks
    private static final double DIST = 70;          // radius of the lyric dome (blocks)
    public static volatile float ELEV = 0.45f;       // elevation of the lyric block centre in radians (~26 degrees up), /sky height <deg>
    private static boolean anchored = false;
    private static float anchorYaw = 0;
    private static int lastSlot = -99;
    private static boolean errorShown = false;

    // camera matrices captured at the end of the world render, used by the HUD pass
    private static final Matrix4f VP = new Matrix4f();
    private static boolean haveVP = false;
    private static float camYaw = 0;
    private static float scrW = 1, scrH = 1;

    public static void init() {
        WorldRenderEvents.LAST.register(SkyRenderer::capture);
        HudRenderCallback.EVENT.register(SkyRenderer::renderHud);
    }

    public static void recheckFont() { fontChecked = false; }

    private static void capture(WorldRenderContext ctx) {
        VP.set(ctx.projectionMatrix()).mul(ctx.matrixStack().peek().getPositionMatrix());
        camYaw = ctx.camera().getYaw();
        haveVP = true;
    }

    // ---------- font ----------
    private static boolean fontChecked = false, fontBroken = false;
    /** the bundled TTF needs FreeType; if it is unavailable every glyph becomes the same "missing" box, so fall back to the vanilla font */
    private static boolean useCustomFont(TextRenderer tr) {
        if (!customFont) return false;
        if (!fontChecked) {
            try {
                int wi = tr.getWidth(Text.literal("i").setStyle(CUSTOM)), ww = tr.getWidth(Text.literal("W").setStyle(CUSTOM));
                fontBroken = wi == ww;
            } catch (Throwable e) { fontBroken = true; }
            fontChecked = true;
        }
        return !fontBroken;
    }

    // ---------- layout of one lyric line ----------
    private static final class Layout {
        Text[][] g; float[][] x, w; float[] rowW; int rows, n; float maxW = 1f;
    }

    private static final class Cache {
        String key; boolean font; Layout l;
        Layout get(String text, TextRenderer tr, boolean custom) {
            if (l == null || !text.equals(key) || font != custom) { key = text; font = custom; l = build(text, tr, custom); }
            return l;
        }
    }
    private static final Cache CUR = new Cache(), NEXT = new Cache(), PREV = new Cache(), TITLE = new Cache();

    private static Layout build(String text, TextRenderer tr, boolean custom) {
        String[] rows = wrap(text);
        Layout L = new Layout();
        L.rows = rows.length;
        L.g = new Text[rows.length][]; L.x = new float[rows.length][]; L.w = new float[rows.length][];
        L.rowW = new float[rows.length];
        for (int r = 0; r < rows.length; r++) {
            int[] cps = rows[r].codePoints().toArray();
            L.g[r] = new Text[cps.length]; L.x[r] = new float[cps.length]; L.w[r] = new float[cps.length];
            float cx = 0;
            for (int k = 0; k < cps.length; k++) {
                Text t = Text.literal(new String(Character.toChars(cps[k]))).setStyle(custom ? CUSTOM : Style.EMPTY);
                float wd = tr.getWidth(t);
                L.g[r][k] = t; L.x[r][k] = cx; L.w[r][k] = wd;
                cx += wd; L.n++;
            }
            L.rowW[r] = cx;
            L.maxW = Math.max(L.maxW, cx);
        }
        return L;
    }

    private static String[] wrap(String s) {
        s = s.trim();
        int len = s.codePointCount(0, s.length());
        int k = len <= 24 ? 1 : len <= 48 ? 2 : 3;
        if (k == 1) return new String[]{s};
        String[] words = s.split("\\s+");
        int target = (int) Math.ceil(len / (double) k);
        List<String> rows = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : words) {
            if (cur.length() > 0 && cur.length() + 1 + w.length() > target && rows.size() < k - 1) {
                rows.add(cur.toString()); cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        rows.add(cur.toString());
        return rows.toArray(new String[0]);
    }

    // ---------- helpers ----------
    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static float easeOutBack(float x) {
        float c1 = 1.70158f, c3 = c1 + 1f, u = x - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }
    private static int rgb(float r, float g, float b, int a) {
        return (a << 24) | ((int) (clamp01(r) * 255) << 16) | ((int) (clamp01(g) * 255) << 8) | (int) (clamp01(b) * 255);
    }
    private static float[] hsv(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float c = v * s, x = c * (1f - Math.abs((h * 6f) % 2f - 1f)), m = v - c, r, g, b;
        int i = (int) (h * 6f);
        switch (i) {
            case 0: r = c; g = x; b = 0; break;
            case 1: r = x; g = c; b = 0; break;
            case 2: r = 0; g = c; b = x; break;
            case 3: r = 0; g = x; b = c; break;
            case 4: r = x; g = 0; b = c; break;
            default: r = c; g = 0; b = x;
        }
        return new float[]{r + m, g + m, b + m};
    }
    private static float scaleOf(Layout L) { return Math.min(MAX_SCALE, TARGET_W / L.maxW); }
    private static float heightOf(Layout L, float mult) { return L.rows * ROW_GAP * scaleOf(L) * mult; }

    // ---------- projection ----------
    private static final Vector4f V4 = new Vector4f();
    private static final float[] PC = new float[2], PXR = new float[2], PYD = new float[2];
    private static final Matrix4f AFF = new Matrix4f(), MT = new Matrix4f();

    /** world point (relative to the camera) -> GUI-scaled screen coordinates; false if behind the camera */
    private static boolean project(double x, double y, double z, float[] out) {
        V4.set((float) x, (float) y, (float) z, 1f);
        VP.transform(V4);
        if (V4.w <= 0.05f) return false;
        out[0] = (V4.x / V4.w * 0.5f + 0.5f) * scrW;
        out[1] = (0.5f - V4.y / V4.w * 0.5f) * scrH;
        return true;
    }

    private static boolean centerOnScreen(float yaw, float elev) {
        float ce = (float) Math.cos(elev);
        if (!project(-Math.sin(Math.toRadians(yaw)) * ce * DIST, Math.sin(elev) * DIST, Math.cos(Math.toRadians(yaw)) * ce * DIST, PC)) return false;
        return PC[0] > scrW * 0.05f && PC[0] < scrW * 0.95f && PC[1] > scrH * 0.05f && PC[1] < scrH * 0.95f;
    }

    /**
     * Places a glyph centre on the sky sphere at (gyaw, gel) radians and fills AFF with the 2D affine map
     * text-space -> screen (so glyphs follow the perspective and roll of the sky). s = blocks per text unit.
     */
    private static boolean place(float gyaw, float gel, float s) {
        float ce = (float) Math.cos(gel), se = (float) Math.sin(gel), cg = (float) Math.cos(gyaw), sg = (float) Math.sin(gyaw);
        double cx = -sg * ce * DIST, cy = se * DIST, cz = cg * ce * DIST;
        if (!project(cx, cy, cz, PC)) return false;
        if (PC[0] < -scrW * 0.15f || PC[0] > scrW * 1.15f || PC[1] < -scrH * 0.25f || PC[1] > scrH * 1.25f) return false;
        float k = s * 8f;                                               // probe 8 text units along each axis
        if (!project(cx - cg * k, cy, cz - sg * k, PXR)) return false;                  // text +x = sky "right"
        if (!project(cx - sg * se * k, cy - ce * k, cz + cg * se * k, PYD)) return false; // text +y = sky "down"
        float ax = (PXR[0] - PC[0]) / 8f, ay = (PXR[1] - PC[1]) / 8f, bx = (PYD[0] - PC[0]) / 8f, by = (PYD[1] - PC[1]) / 8f;
        AFF.set(ax, ay, 0f, 0f, bx, by, 0f, 0f, 0f, 0f, 1f, 0f, PC[0], PC[1], 0f, 1f);
        return true;
    }

    // ---------- main ----------
    private static void renderHud(DrawContext dc, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !haveVP) return;
        double t = SkyMusicClient.PLAYER.getTime();
        if (t < 0) { anchored = false; status = "no song playing"; return; }
        try {
            scrW = mc.getWindow().getScaledWidth();
            scrH = mc.getWindow().getScaledHeight();
            renderLyrics(dc, mc, t);
        } catch (Throwable e) {
            status = "error: " + e;
            if (!errorShown) { errorShown = true; SkyMusicClient.msg("Lyrics error (please report): " + e); }
        }
    }

    private static int drawn = 0;

    private static void renderLyrics(DrawContext dc, MinecraftClient mc, double t) {
        TextRenderer tr = mc.textRenderer;
        boolean custom = useCustomFont(tr);
        Lrc lrc = SkyMusicClient.lyrics;
        boolean hasLyrics = lrc != null && !lrc.lines.isEmpty();
        int q = Math.max(1, Perf.skyQuality);
        float anim = (System.currentTimeMillis() % 1_000_000L) / 1000f;
        drawn = 0;

        int idx = hasLyrics ? lrc.indexAt(t) : -1;
        int slot = idx;                       // -1 = title card
        if (!anchored) { anchored = true; anchorYaw = camYaw; lastSlot = slot; }
        else if (slot != lastSlot) {
            lastSlot = slot;
            // the text lives in the sky; only move it if you have turned far away from it
            float diff = Math.abs(((camYaw - anchorYaw) % 360f + 540f) % 360f - 180f);
            if (diff > 100f) anchorYaw = camYaw;
        }
        boolean visible = centerOnScreen(anchorYaw, ELEV);
        String plain = null;                  // text for the fallback subtitle

        if (idx < 0) {
            // title card before the first line (or the whole intro when there are no lyrics)
            String ttl = SkyMusicClient.title;
            double end = hasLyrics ? lrc.lines.get(0).time() : 7.0;
            if (ttl != null && !ttl.isEmpty() && t <= end) {
                float fade = (float) Math.min(clamp01((float) (t / 0.5)), clamp01((float) (end - t)));
                Layout L = TITLE.get("\u266A  " + ttl, tr, custom);
                draw(dc, tr, L, anchorYaw, ELEV, 1f, (float) t, anim, clamp01((float) (t / 3.0)), fade, true, true, q);
                plain = "\u266A " + ttl;
            }
        } else {
            Lrc.Line cur = lrc.lines.get(idx);
            double since = t - cur.time();
            double nextTime = idx + 1 < lrc.lines.size() ? lrc.lines.get(idx + 1).time() : cur.time() + 5.0;
            double dur = Math.max(0.6, Math.min(8.0, nextTime - cur.time()));
            float prog = clamp01((float) (since / (dur * 0.92)));

            float outFade = 1f;
            if (idx + 1 >= lrc.lines.size()) outFade = clamp01((float) (1.0 - (since - 6.0) / 2.0));   // last line fades away
            if (outFade > 0f) {
                String curText = cur.text().isEmpty() ? "\u266A  \u266B  \u266A" : cur.text();
                Layout curL = CUR.get(curText, tr, custom);
                draw(dc, tr, curL, anchorYaw, ELEV, 1f, (float) since, anim, prog, outFade, true, true, q);
                plain = curText;

                float curHalf = heightOf(curL, 1f) / 2f;
                // previous line floats up and fades
                if (idx > 0 && since < 1.4) {
                    String pt = lrc.lines.get(idx - 1).text();
                    if (!pt.isEmpty()) {
                        float qv = (float) (since / 1.4);
                        Layout pl = PREV.get(pt, tr, custom);
                        float ph = heightOf(pl, 0.6f) / 2f;
                        draw(dc, tr, pl, anchorYaw, ELEV + (curHalf + ph + 4 + qv * 8f) / (float) DIST, 0.6f, 0f, anim, 1f, 0.55f * (1f - qv) * outFade, false, false, q);
                    }
                }
                // next line previews below, dim
                if (idx + 1 < lrc.lines.size()) {
                    String nt = lrc.lines.get(idx + 1).text();
                    if (!nt.isEmpty()) {
                        Layout nl = NEXT.get(nt, tr, custom);
                        float nh = heightOf(nl, 0.6f) / 2f;
                        float fin = clamp01((float) (since / 0.5));
                        draw(dc, tr, nl, anchorYaw, ELEV - (curHalf + nh + 4) / (float) DIST, 0.6f, 0f, anim, 1f, 0.5f * fin * outFade, false, false, q);
                    }
                }
            }
        }
        dc.draw();                            // flush the lyric text now so it sits under the rest of the HUD

        // small plain subtitle when you are not looking at the sky lyrics (or always, /sky subtitle on)
        int sm = subtitleMode;
        if (plain != null && (sm == 1 || (sm == 2 && !visible))) {
            int y = (int) (scrH * 0.12f);
            dc.drawCenteredTextWithShadow(tr, Text.literal(plain), (int) (scrW / 2f), y, 0xFFFFFF);
        }
        status = "playing, t=" + String.format("%.1f", t) + ", glyphs drawn=" + drawn + ", on screen=" + visible
            + ", font=" + (custom ? "custom" : (customFont ? "vanilla (custom font unavailable)" : "vanilla"));
    }

    /** draws one lyric block painted on the sky dome at (yawDeg, elev), each glyph placed on the sphere so the line curves like the sky */
    private static void draw(DrawContext dc, TextRenderer tr, Layout L,
                             float yawDeg, float elev, float scaleMult, float elapsed, float anim,
                             float prog, float alpha, boolean animateIn, boolean karaoke, int q) {
        VertexConsumerProvider.Immediate vc = dc.getVertexConsumers();
        Matrix4f hud = dc.getMatrices().peek().getPositionMatrix();
        float s = scaleOf(L) * scaleMult;
        float yawRad0 = (float) Math.toRadians(yawDeg);
        float stagger = animateIn ? Math.min(0.035f, 0.45f / Math.max(1, L.n)) : 0f;
        int haloTaps = Perf.skyQuality >= 2 ? 4 : 2;
        for (int pass = 0; pass < 2; pass++) {       // pass 0 = soft halo, pass 1 = colour
            int gi = 0;
            for (int r = 0; r < L.rows; r++) {
                float rowY = (r - (L.rows - 1) / 2f) * ROW_GAP;
                float x0 = -L.rowW[r] / 2f;
                for (int k = 0; k < L.g[r].length; k++, gi++) {
                    float p = animateIn ? clamp01((elapsed - gi * stagger) / 0.32f) : 1f;
                    if (p <= 0f) continue;
                    int a = (int) (255 * alpha * Math.min(1f, p * 1.4f));
                    if (a < 6) continue;                                // tiny alpha would be treated as opaque by vanilla

                    float frac = (gi + 0.5f) / L.n;
                    float lit = karaoke ? clamp01((prog * 1.06f - frac) / 0.06f) : 0f;
                    float bump = karaoke ? lit * (1f - lit) * 4f : 0f;
                    float wave = karaoke ? (float) Math.sin(anim * 3.2f + gi * 0.55f) * 1.6f : 0f;
                    float sc = easeOutBack(p) * (1f + 0.22f * bump);
                    float cx = x0 + L.x[r][k] + L.w[r][k] / 2f;
                    float cy = rowY + wave + (1f - p) * 9f - bump * 2.5f;

                    // place this glyph on the sphere: right = larger yaw, down = lower elevation
                    float gyaw = yawRad0 + cx * s / (float) DIST / (float) Math.max(0.2, Math.cos(elev));
                    float gel = elev - cy * s / (float) DIST;
                    if (!place(gyaw, gel, s)) continue;
                    MT.set(hud).mul(AFF).scale(sc, sc, 1f);
                    if (pass == 1) drawn++;

                    float gx = -L.w[r][k] / 2f;
                    if (pass == 0) {
                        int oc = rgb(0.55f, 0.72f, 1f, (int) (a * 0.20f));
                        float o = 2.4f;
                        tr.draw(L.g[r][k], gx - o, -GLYPH_MID, oc, false, MT, vc, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                        tr.draw(L.g[r][k], gx + o, -GLYPH_MID, oc, false, MT, vc, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                        if (haloTaps > 2) {
                            tr.draw(L.g[r][k], gx, -GLYPH_MID - o, oc, false, MT, vc, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                            tr.draw(L.g[r][k], gx, -GLYPH_MID + o, oc, false, MT, vc, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                        }
                    } else {
                        float[] ac = hsv(anim * 0.05f + gi * 0.010f, 0.32f, 1f);
                        float cr = 1.0f + (ac[0] - 1.0f) * lit, cg = 1.0f + (ac[1] - 1.0f) * lit, cb = 1.0f + (ac[2] - 1.0f) * lit;
                        tr.draw(L.g[r][k], gx, -GLYPH_MID, rgb(cr, cg, cb, (int) (a * 0.94f)), false, MT, vc, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                    }
                }
            }
        }
    }
}
