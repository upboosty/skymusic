package dev.skymusic;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/**
 * Draws the mist trail (geometry: MistTrail). Two textured quad batches per frame (the ribbons and the puffs), drawn after the letters:
 *  - vanilla position_tex_color shader, no shader pack / extra shader needed;
 *  - normal alpha blending, depth TEST on (blocks and the letters hide the mist), depth WRITE off (soft mist never hides anything itself);
 *  - the vertices are in eye space like the letters, so the world's own projection does the perspective.
 * If anything in here ever throws, the mist switches itself off for the session and the lyrics keep working.
 */
final class MistRender {
    private MistRender() {}

    private static final Identifier TEX_WISP = new Identifier("skymusic", "textures/mist/wisp.png");
    private static final Identifier TEX_PUFF = new Identifier("skymusic", "textures/mist/puff.png");

    private static final MistTrail.Mesh WISP = new MistTrail.Mesh(), PUFF = new MistTrail.Mesh();
    private static final MistTrail.Look LOOK = new MistTrail.Look();
    private static BufferBuilder bufWisp, bufPuff;
    private static boolean failed = false;

    static boolean enabled() { return LyricConfig.trailEnabled && !failed; }

    static void reset() { WISP.clear(); PUFF.clear(); }

    /** adds the mist of one row (eye-space frame of the sign, see MistTrail.addRow) */
    static void addRow(float ox, float oy, float oz, float rx, float ry, float rz, float dx, float dy, float dz, float nx, float ny, float nz,
                       float rowHalfLen, float rowY, float rowH, float time, int seed, float fade, float shrink, float lr, float lg, float lb) {
        if (!enabled()) return;
        int q = Perf.skyQuality;                                     // the performance steps thin the mist out on weak devices
        MistTrail.Look k = LOOK;
        k.opacity = LyricConfig.trailOpacity;
        k.size = LyricConfig.trailSize;
        k.speed = LyricConfig.trailSpeed;
        k.curl = LyricConfig.trailCurl;
        k.layers = Math.min(LyricConfig.trailLayers, q <= 0 ? 1 : q == 1 ? 2 : 4);
        k.puffs = LyricConfig.trailPuffs && q >= 1;
        MistTrail.addRow(WISP, PUFF, k, ox, oy, oz, rx, ry, rz, dx, dy, dz, nx, ny, nz, rowHalfLen, rowY, rowH, time, seed, fade, shrink, lr, lg, lb);
    }

    /** draws everything collected this frame (after the letters, so the letters hide the mist behind them) */
    static void flush() {
        if (WISP.n == 0 && PUFF.n == 0) return;
        try {
            if (WISP.n > 0) { if (bufWisp == null) bufWisp = new BufferBuilder(1 << 16); draw(bufWisp, WISP, TEX_WISP); }
            if (PUFF.n > 0) { if (bufPuff == null) bufPuff = new BufferBuilder(1 << 15); draw(bufPuff, PUFF, TEX_PUFF); }
        } catch (Throwable t) {
            failed = true;
            SkyMusicClient.msg("Mist trail switched off (error: " + t + ")");
        } finally {
            reset();
        }
    }

    private static void draw(BufferBuilder b, MistTrail.Mesh m, Identifier tex) {
        RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
        RenderSystem.setShaderTexture(0, tex);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(515);                                 // GL_LEQUAL: blocks and letters in front hide the mist
        RenderSystem.depthMask(false);                               // ... but the mist itself writes no depth
        RenderSystem.disableCull();
        b.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        float[] d = m.d;
        for (int i = 0, o = 0; i < m.n; i++, o += 9)
            b.vertex(d[o], d[o + 1], d[o + 2]).texture(d[o + 3], d[o + 4]).color(d[o + 5], d[o + 6], d[o + 7], d[o + 8]).next();
        BufferRenderer.drawWithGlobalProgram(b.end());
    }
}
