package dev.skymusic;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/**
 * Draws the mist trail (geometry: MistTrail) and the light that follows the singing. Up to four textured quad batches per frame, drawn after the letters:
 *  - the ribbons and the puffs of the mist: normal alpha blending;
 *  - the glow (soft light behind the rows and a bloom behind every sung letter) and the sparkles: ADDITIVE (rgb carries the brightness, like the sky's stars),
 *    so their soft edges can never be clipped by the alpha test and they only ever add light;
 *  - vanilla position_tex_color shader, no shader pack / extra shader needed;
 *  - depth TEST on (blocks and the letters hide them), depth WRITE off (soft light never hides anything itself);
 *  - the vertices are in eye space like the letters, so the world's own projection does the perspective.
 * If anything in here ever throws, the mist switches itself off for the session and the lyrics keep working.
 */
final class MistRender {
    private MistRender() {}

    private static final Identifier TEX_WISP = new Identifier("skymusic", "textures/mist/wisp.png");
    private static final Identifier TEX_PUFF = new Identifier("skymusic", "textures/mist/puff.png");
    private static final Identifier TEX_GLOW = new Identifier("skymusic", "textures/mist/glow.png");
    private static final Identifier TEX_SPARK = new Identifier("skymusic", "textures/mist/spark.png");

    private static final MistTrail.Mesh WISP = new MistTrail.Mesh(), PUFF = new MistTrail.Mesh(), GLOW = new MistTrail.Mesh(), SPARK = new MistTrail.Mesh();
    private static final MistTrail.Look LOOK = new MistTrail.Look();
    private static BufferBuilder bufWisp, bufPuff, bufGlow, bufSpark;
    private static final float[] layerMul = {1f, 1f, 1f, 1f};   // eased presence of each wisp layer (quality steps / settings fade, never pop)
    private static float puffMul = 1f;
    private static long lastNs = System.nanoTime();
    private static boolean failed = false;

    static boolean enabled() { return LyricConfig.trailEnabled && !failed; }

    /** the bloom and the sparkles of the letters do not depend on the mist trail being on, only on not having failed */
    static boolean fxEnabled() { return !failed; }

    /** start of a frame: forget last frame's mist and ease the layer / puff presence toward what the settings and the performance step want */
    static void reset() {
        WISP.clear(); PUFF.clear(); GLOW.clear(); SPARK.clear();
        long now = System.nanoTime();
        float dt = Math.max(0.0005f, Math.min(0.25f, (now - lastNs) / 1e9f));
        lastNs = now;
        float k = 1f - (float) Math.exp(-dt * 2.5f);
        int q = Perf.skyQuality;
        int want = Math.min(LyricConfig.trailLayers, q <= 0 ? 1 : q == 1 ? 2 : 4);
        for (int l = 0; l < 4; l++) layerMul[l] += ((l < want ? 1f : 0f) - layerMul[l]) * k;
        puffMul += ((LyricConfig.trailPuffs && q >= 1 ? 1f : 0f) - puffMul) * k;
    }

    /** adds the soft light behind one row: it spans layout x0 .. x1 (the part of the row that has been sung so far); additive. alpha = its strength (before the glow setting) */
    static void addGlow(float ox, float oy, float oz, float rx, float ry, float rz, float dx, float dy, float dz, float nx, float ny, float nz,
                        float x0, float x1, float rowY, float rowH, float alpha, float lr, float lg, float lb) {
        if (!enabled() || LyricConfig.glow < 0.01f || Perf.skyQuality < 1) return;
        MistTrail.addGlow(GLOW, ox, oy, oz, rx, ry, rz, dx, dy, dz, nx, ny, nz, x0, x1, rowY, rowH, alpha * LyricConfig.glow * 2f, lr, lg, lb);
    }

    /**
     * adds what follows the singing at one letter: the bloom behind it (strength = the glow setting) and `sparks` twinkling sparkles. bloom = 0..1 envelope,
     * ts = seconds since the letter was sung, amount = 0..1 fade of the line; g* = tint of the bloom, k* = tint of the sparkles
     */
    static void addLetterFx(float ox, float oy, float oz, float rx, float ry, float rz, float dx, float dy, float dz, float nx, float ny, float nz,
                            float cx, float cy, float bloom, float ts, int seed, int sparks, float amount,
                            float gr, float gg, float gb, float kr, float kg, float kb) {
        if (failed) return;
        MistTrail.addLetterFx(GLOW, SPARK, ox, oy, oz, rx, ry, rz, dx, dy, dz, nx, ny, nz, cx, cy, bloom, ts, seed, sparks, LyricConfig.glow, amount, gr, gg, gb, kr, kg, kb);
    }

    /** adds the mist of one row (eye-space frame of the sign, see MistTrail.addRow) */
    static void addRow(float ox, float oy, float oz, float rx, float ry, float rz, float dx, float dy, float dz, float nx, float ny, float nz,
                       float rowHalfLen, float rowY, float rowH, float time, int seed, float fade, float shrink, float lr, float lg, float lb) {
        if (!enabled()) return;
        MistTrail.Look k = LOOK;
        k.opacity = LyricConfig.trailOpacity;
        k.size = LyricConfig.trailSize;
        k.speed = LyricConfig.trailSpeed;
        k.curl = LyricConfig.trailCurl;
        k.layers = 4;                                                // how many are really there is eased in layerMul (performance steps thin the mist out smoothly)
        k.puffs = true;
        System.arraycopy(layerMul, 0, k.layerMul, 0, 4);
        k.puffMul = puffMul;
        MistTrail.addRow(WISP, PUFF, k, ox, oy, oz, rx, ry, rz, dx, dy, dz, nx, ny, nz, rowHalfLen, rowY, rowH, time, seed, fade, shrink, lr, lg, lb);
    }

    /** draws everything collected this frame (after the letters, so the letters hide the mist behind them) */
    static void flush() {
        if (WISP.n == 0 && PUFF.n == 0 && GLOW.n == 0 && SPARK.n == 0) return;
        try {
            if (WISP.n > 0) { if (bufWisp == null) bufWisp = new BufferBuilder(1 << 20); draw(bufWisp, WISP, TEX_WISP, false); }
            if (PUFF.n > 0) { if (bufPuff == null) bufPuff = new BufferBuilder(1 << 19); draw(bufPuff, PUFF, TEX_PUFF, false); }
            if (GLOW.n > 0) { if (bufGlow == null) bufGlow = new BufferBuilder(1 << 17); draw(bufGlow, GLOW, TEX_GLOW, true); }
            if (SPARK.n > 0) { if (bufSpark == null) bufSpark = new BufferBuilder(1 << 16); draw(bufSpark, SPARK, TEX_SPARK, true); }
        } catch (Throwable t) {
            failed = true;
            SkyMusicClient.msg("Mist trail and letter glow switched off (error: " + t + ")");
        } finally {
            reset();
        }
    }

    private static void draw(BufferBuilder b, MistTrail.Mesh m, Identifier tex, boolean additive) {
        RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
        RenderSystem.setShaderTexture(0, tex);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.enableBlend();
        if (additive) RenderSystem.blendFunc(GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ONE);   // rgb carries the brightness
        else RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(515);                                 // GL_LEQUAL: blocks and letters in front hide the mist
        RenderSystem.depthMask(false);                               // ... but the mist itself writes no depth
        RenderSystem.disableCull();
        b.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        float[] d = m.d;
        for (int i = 0, o = 0; i < m.n; i++, o += 9)
            b.vertex(d[o], d[o + 1], d[o + 2]).texture(d[o + 3], d[o + 4]).color(d[o + 5], d[o + 6], d[o + 7], d[o + 8]).next();
        BufferRenderer.drawWithGlobalProgram(b.end());
        if (additive) RenderSystem.defaultBlendFunc();                 // back to the usual blending for whatever is drawn next
    }
}
