package dev.skymusic;

/**
 * Builds the triangles of ONE solid lyric letter and hands every vertex to a Sink. Pure math (no Minecraft classes): SkyRenderer's sink writes
 * the vertices into the GPU batch, tools/LyricPreview.java rasterises them offline, so what is tested there is exactly what runs in the game.
 *
 * A letter is a baked outline (MeshFont) extruded into a solid: front face + side walls (+ back face when you stand behind the sign).
 * Its position in the world is   P + vx * A + vy * B + vz * C   (eye space), where A / B / C are the letter's own axes after the jelly motion:
 * squash / stretch (sx, sy), shear (lean), a roll in the plane of the sign, a tilt about the foot, and a pop toward you (zoff).
 *
 * Speed: the side walls are the bulk of a letter (about two thirds of its triangles). Walls that face away from you can never be seen (a solid
 * hides its own far side), so they are skipped: the viewer is carried into the letter's own coordinates once per letter, and every wall then costs
 * one 2D plane test. That is an exact test (affine maps keep planes and sides), it removes about half of the wall triangles, and because
 * the lyrics are drawn twice (depth pre-pass + colour pass) every skipped triangle is saved twice.
 *
 * Look: the face is a touch brighter at the top; a slow SHEEN sweeps across lit letters; the walls are lit by the real sun / moon plus a steady soft
 * key light from the upper left (so the letters keep their shape at night and in caves) with a little gloss on the edge that faces the light; and a
 * letter flashes toward white for a moment when it is sung.
 */
final class LyricMesh {
    private LyricMesh() {}

    interface Sink {
        /** called before the first vertex of a letter, so the renderer can start its batch lazily */
        void begin();
        void v(float x, float y, float z, float r, float g, float b, float a);
    }

    static Sink sink;

    /** thickness of the letters in layout px (a capital is about 14.7 px high) */
    static final float DEPTH = 6.0f;

    // ---- lighting ----
    static final float FRONT_AMB = 0.84f, FRONT_DIFF = 0.16f;       // brightness of the front face: always readable, a little brighter when the sun / moon shines on it
    static final float WALL_AMB = 0.48f, WALL_DIFF = 0.46f;         // brightness of the side walls: darker, brighter on the side that faces the light
    static final float WALL_SPEC = 0.16f;                           // a little gloss on the edge that faces the light
    static final float KEY_X = -0.17f, KEY_Y = -0.26f;              // steady soft key light from the upper left (sign axes: x right, y down)
    private static final float GK0 = 0.925f, GK1 = -0.0075f;        // face brightness by height: y < 0 is up, so the top is a little brighter
    private static final float SHEEN_K = 0.55f;                     // how far the sheen pulls a face toward its highlight colour
    private static final float SHEEN_R = 1.00f, SHEEN_G = 0.985f, SHEEN_B = 0.955f;
    private static final float FLASH_FACE = 0.65f, FLASH_WALL = 0.50f;

    // ---- the sign being drawn (set by the renderer) ----
    private static float eOx, eOy, eOz, eRx, eRy, eRz, eUx, eUy, eUz, eNx, eNy, eNz, eS;
    private static boolean frontToYou;
    private static float lLx, lLy, lLz;                              // sun / moon in the sign's own axes (x right, y down, z toward the side the letters face), scaled by its strength
    static boolean ghost = false;                                    // you are inside / right next to the text: see-through, both sides, nothing is skipped
    static float thickMul = 1f;                                      // letters are made thicker when the text is tiny in the world (close to you)
    static float tanHX = 1.5f, tanHY = 0.7f;                         // tangent of the half field of view
    static boolean cullWalls = true;
    /** statistics of the last frame (the renderer / the preview may reset them) */
    static int wallsDrawn = 0, wallsCulled = 0;

    /** the sign in eye space: origin, and its right / down / toward-you axes (each one layout px long), eS = blocks per layout px */
    static void setSign(float ox, float oy, float oz, float rx, float ry, float rz, float ux, float uy, float uz,
                        float nx, float ny, float nz, float s, boolean front) {
        eOx = ox; eOy = oy; eOz = oz; eRx = rx; eRy = ry; eRz = rz; eUx = ux; eUy = uy; eUz = uz; eNx = nx; eNy = ny; eNz = nz; eS = s;
        frontToYou = front;
    }

    /** light of the sun / moon in the sign's own axes (x right, y down, z toward the side the letters face), scaled by its strength */
    static void setLight(float x, float y, float z) { lLx = x; lLy = y; lLz = z; }

    private static float c1(float v) { return v > 1f ? 1f : v; }       // vertex colours must stay <= 1 (the GPU buffers store bytes: 1.02 would wrap around to nearly black)

    /** the sheen: a soft highlight band of half width w centred at `centre` (layout px along the row); 1 in the middle, 0 at the edge, smooth */
    static float sheen(float x, float centre, float w) {
        float u = (x - centre) / w;
        u *= u;
        if (u >= 1f) return 0f;
        u = 1f - u;
        return u * u;
    }

    /** sin / cos for |x| <= 0.9 (error below 2e-6): the letters only ever turn by small angles */
    private static float sinS(float x) { float x2 = x * x; return x * (1f + x2 * (-1f / 6f + x2 * (1f / 120f + x2 * (-1f / 5040f)))); }
    private static float cosS(float x) { float x2 = x * x; return 1f + x2 * (-0.5f + x2 * (1f / 24f + x2 * (-1f / 720f + x2 * (1f / 40320f)))); }

    /**
     * One solid letter.
     *
     * @param gl      the glyph
     * @param pen     pen x on the sign plane, base = baseline y (already including the letter's own bounce), foot = x of the letter's foot (middle of its advance)
     * @param sx,sy   squash / stretch about the foot (the letter stays planted like jelly); lean = sideways shift of the top per unit of height
     * @param roll    turn in the plane of the sign (radians, + = clockwise seen from the front); tilt = turn about the horizontal axis through the foot
     *                (radians, + = the top leans away from you); zoff = offset toward you (layout px)
     * @param cr,cg,cb,ca colour and opacity of the front face (the walls are the same colour, shaded)
     * @param flash   0..1 brightness pop; shL / shR = 0..1 strength of the sheen at the left / right edge of the letter
     * @return triangles built
     */
    static int glyph(MeshFont.Glyph gl, float pen, float base, float foot, float sx, float sy, float lean, float roll, float tilt, float zoff,
                     float cr, float cg, float cb, float ca, float flash, float shL, float shR) {
        if (ca < 0.012f) return 0;
        final float zs = Math.max(0.5f, Math.min(1.5f, 0.5f * (sx + sy))) * thickMul;     // thickness follows the squash, a little
        final float h = DEPTH * 0.5f;

        // ---- the letter's axes in layout space (x right, y down, z toward you), about its foot: scale + shear, then tilt (about x), then roll (about z)
        float rc = 1f, rs = 0f, tc = 1f, ts = 0f;
        if (roll > 1e-4f || roll < -1e-4f) { rs = sinS(roll); rc = cosS(roll); }
        if (tilt > 1e-4f || tilt < -1e-4f) { ts = sinS(tilt); tc = cosS(tilt); }
        final float lx0 = (pen - foot) * sx;                                             // the letter's origin, relative to the foot
        final float opx = foot + lx0 * rc, opy = base + lx0 * rs;
        final float axx = sx * rc, axy = sx * rs;                                        // local x axis
        final float byy0 = sy * tc, bxx0 = -lean * sy;                                   // local y axis after the shear and the tilt (z part: sy * ts)
        final float bxx = bxx0 * rc - byy0 * rs, byy = bxx0 * rs + byy0 * rc, bzz = sy * ts;
        final float cxx = zs * ts * rs, cyy = -zs * ts * rc, czz = zs * tc;              // local z axis

        // ---- into eye space: a glyph point (vx, vy, vz) is at P + vx * A + vy * B + vz * C
        final float pX = eOx + opx * eRx + opy * eUx + zoff * eNx, pY = eOy + opx * eRy + opy * eUy + zoff * eNy, pZ = eOz + opx * eRz + opy * eUz + zoff * eNz;
        final float aX = axx * eRx + axy * eUx, aY = axx * eRy + axy * eUy, aZ = axx * eRz + axy * eUz;
        final float bX = bxx * eRx + byy * eUx + bzz * eNx, bY = bxx * eRy + byy * eUy + bzz * eNy, bZ = bxx * eRz + byy * eUz + bzz * eNz;
        final float cX = cxx * eRx + cyy * eUx + czz * eNx, cY = cxx * eRy + cyy * eUy + czz * eNy, cZ = cxx * eRz + cyy * eUz + czz * eNz;

        // ---- skip letters that are surely off screen or behind you
        final float cvx = gl.adv * 0.5f, cvy = -7f;
        final float mx = pX + cvx * aX + cvy * bX, my = pY + cvx * aY + cvy * bY, mz = pZ + cvx * aZ + cvy * bZ;
        final float rad = 22f * eS * Math.max(1f, Math.max(sx, sy)) + 0.5f;
        if (mz > rad) return 0;
        final float depth = Math.max(0.01f, -mz);
        if (Math.abs(mx) - rad > depth * tanHX * 1.15f || Math.abs(my) - rad > depth * tanHY * 1.15f) return 0;

        final Sink out = sink;
        out.begin();

        // ---- where the viewer is, in the letter's own coordinates (qx, qy): a wall is only visible from the side it faces
        boolean cull = cullWalls && !ghost;
        float qx = 0f, qy = 0f;
        if (cull) {
            final float bcx = bY * cZ - bZ * cY, bcy = bZ * cX - bX * cZ, bcz = bX * cY - bY * cX;        // B x C
            final float cax = cY * aZ - cZ * aY, cay = cZ * aX - cX * aZ, caz = cX * aY - cY * aX;        // C x A
            final float det = aX * bcx + aY * bcy + aZ * bcz;                                             // A . (B x C)
            if (det > 1e-14f || det < -1e-14f) {
                final float inv = -1f / det;                                                              // the eye is at the origin: q = M^-1 * (-P)
                qx = (pX * bcx + pY * bcy + pZ * bcz) * inv;
                qy = (pX * cax + pY * cay + pZ * caz) * inv;
            } else cull = false;
        }

        // ---- colours
        final float k = FRONT_AMB + FRONT_DIFF * Math.max(0f, lLz);
        float fr = cr * k, fg = cg * k, fb = cb * k;
        if (flash > 0.002f) {
            final float f = flash * FLASH_FACE;
            fr += (1f - fr) * f; fg += (1f - fg) * f; fb += (1f - fb) * f;
        }
        int tris = 0;
        final float hx = h * cX, hy = h * cY, hz = h * cZ;
        final float[] t = gl.tri;

        // ---- front face (the one you see)
        if (frontToYou || ghost) {
            final float fx = pX + hx, fy = pY + hy, fz = pZ + hz;
            final boolean sheen = shL > 0.004f || shR > 0.004f;
            final float invAdv = gl.adv > 0.5f ? 1f / gl.adv : 1f;
            for (int i = 0; i < t.length; i += 2) {
                final float vx = t[i], vy = t[i + 1];
                final float gk = GK0 + GK1 * vy;                       // a faint top-light gradient on the face: less flat, more premium
                float vr = c1(fr * gk), vg = c1(fg * gk), vb = c1(fb * gk);
                if (sheen) {
                    float u = vx * invAdv; u = u < 0f ? 0f : (u > 1f ? 1f : u);
                    final float sh = (shL + (shR - shL) * u) * SHEEN_K;
                    if (sh > 0.002f) { vr += (SHEEN_R - vr) * sh; vg += (SHEEN_G - vg) * sh; vb += (SHEEN_B - vb) * sh; }
                }
                out.v(fx + vx * aX + vy * bX, fy + vx * aY + vy * bY, fz + vx * aZ + vy * bZ, vr, vg, vb, ca);
            }
            tris += gl.nTri;
        }
        // ---- back face, darker (you walked around the sign; or you are inside it and see both)
        if (!frontToYou || ghost) {
            final float br = c1(fr) * 0.5f, bg = c1(fg) * 0.5f, bb = c1(fb) * 0.5f;
            final float bx0 = pX - hx, by0 = pY - hy, bz0 = pZ - hz;
            for (int i = 0; i < t.length; i += 2) {
                final float vx = t[i], vy = t[i + 1];
                out.v(bx0 + vx * aX + vy * bX, by0 + vx * aY + vy * bY, bz0 + vx * aZ + vy * bZ, br, bg, bb, ca);
            }
            tris += gl.nTri;
        }

        // ---- side walls, shaded by which way each edge faces the light (sun / moon + the steady key light), the ones facing away skipped
        final float[] sg = gl.seg, gn = gl.gn;
        final float lx = lLx + KEY_X, ly = lLy + KEY_Y;
        final float tfx = pX + hx, tfy = pY + hy, tfz = pZ + hz;       // origin of the front plane
        final float tbx = pX - hx, tby = pY - hy, tbz = pZ - hz;       // origin of the back plane
        int drawn = 0, skipped = 0;
        for (int i = 0, kk = 0; i < sg.length; i += 8, kk += 2) {
            final float x0 = sg[i], y0 = sg[i + 1];
            if (cull && gn[kk] * (qx - x0) + gn[kk + 1] * (qy - y0) <= 0f) { skipped++; continue; }
            final float x1 = sg[i + 2], y1 = sg[i + 3];
            float d0 = sg[i + 4] * lx + sg[i + 5] * ly;  d0 = d0 < 0f ? 0f : (d0 > 1.2f ? 1.2f : d0);
            float d1 = sg[i + 6] * lx + sg[i + 7] * ly;  d1 = d1 < 0f ? 0f : (d1 > 1.2f ? 1.2f : d1);
            final float s0 = c1(WALL_AMB + d0 * (WALL_DIFF + WALL_SPEC * d0 * d0));
            final float s1 = c1(WALL_AMB + d1 * (WALL_DIFF + WALL_SPEC * d1 * d1));
            float r0 = cr * s0, g0 = cg * s0, b0 = cb * s0, r1 = cr * s1, g1 = cg * s1, b1 = cb * s1;
            if (flash > 0.002f) {
                final float f = flash * FLASH_WALL;
                r0 += (1f - r0) * f; g0 += (1f - g0) * f; b0 += (1f - b0) * f;
                r1 += (1f - r1) * f; g1 += (1f - g1) * f; b1 += (1f - b1) * f;
            }
            final float ax0 = x0 * aX + y0 * bX, ay0 = x0 * aY + y0 * bY, az0 = x0 * aZ + y0 * bZ;
            final float ax1 = x1 * aX + y1 * bX, ay1 = x1 * aY + y1 * bY, az1 = x1 * aZ + y1 * bZ;
            final float t0x = tfx + ax0, t0y = tfy + ay0, t0z = tfz + az0;       // (x0, y0, +h)
            final float u0x = tbx + ax0, u0y = tby + ay0, u0z = tbz + az0;       // (x0, y0, -h)
            final float t1x = tfx + ax1, t1y = tfy + ay1, t1z = tfz + az1;       // (x1, y1, +h)
            final float u1x = tbx + ax1, u1y = tby + ay1, u1z = tbz + az1;       // (x1, y1, -h)
            out.v(t0x, t0y, t0z, r0, g0, b0, ca);
            out.v(u0x, u0y, u0z, r0, g0, b0, ca);
            out.v(u1x, u1y, u1z, r1, g1, b1, ca);
            out.v(t0x, t0y, t0z, r0, g0, b0, ca);
            out.v(u1x, u1y, u1z, r1, g1, b1, ca);
            out.v(t1x, t1y, t1z, r1, g1, b1, ca);
            drawn++;
        }
        wallsDrawn += drawn; wallsCulled += skipped;
        return tris + drawn * 2;
    }
}
