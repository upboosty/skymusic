package dev.skymusic;

import java.util.Arrays;

/**
 * Geometry of the cloudy white mist trail that curls and loops around ONE lyric row. Pure math: no Minecraft classes, so the exact same code
 * can be rendered offline (tools/MistPreview.java) to look at the result without starting the game.
 *
 * How it is built (cheap on purpose, softness comes from the textures, not from many particles):
 *  - every wisp is a camera-facing RIBBON along a 3D curve: the curve is a loose helix around the row (it loops in front of and behind the
 *    text), whose radius, tilt, speed and thickness wander with smooth noise, so it never looks like a rigid ring;
 *  - the ribbon carries tools/gen_mist.py's smoke texture, whose alpha already fades to nothing across its width (feathered edges) and
 *    holds soft silky strands inside; the vertex alpha tapers both ends to nothing;
 *  - a few large soft cloud PUFFS sit along each wisp to give it body;
 *  - a wisp lives in cycles: nearly invisible and tiny -> a soft visible wisp drifting along the row -> it shrinks and fades. Every cycle has
 *    its own random shape, direction and phase, every layer its own period, and every row its own seed, so it never repeats in lock step.
 *
 * Everything is placed in the frame of the sign (fixed in the world: it never follows the camera). Only the cross direction of a ribbon
 * turns to the viewer (like every smoke / beam), which is what keeps it soft from any side. All coordinates are EYE SPACE (camera at the
 * origin looking down -z), the same space SkyRenderer builds its letters in, so the vertices go straight to the GPU.
 */
final class MistTrail {
    private MistTrail() {}

    /** vertex store, 9 floats per vertex (x y z u v r g b a), 4 vertices per quad */
    static final class Mesh {
        float[] d = new float[9 * 4 * 1024];
        int n = 0;

        void clear() { n = 0; }

        void vert(float x, float y, float z, float u, float v, float r, float g, float b, float a) {
            int o = n * 9;
            if (o + 9 > d.length) d = Arrays.copyOf(d, d.length * 2);
            d[o] = x; d[o + 1] = y; d[o + 2] = z; d[o + 3] = u; d[o + 4] = v; d[o + 5] = r; d[o + 6] = g; d[o + 7] = b; d[o + 8] = a;
            n++;
        }
    }

    /** the look of the trail (SkyRenderer fills it from LyricConfig) */
    static final class Look {
        float opacity = 0.85f;     // peak opacity of a wisp (0..1)
        float size = 1f;           // radius and thickness multiplier
        float speed = 1f;          // animation speed multiplier
        float curl = 1f;           // how many loops it makes around the row
        int layers = 3;            // wisps per row (1..4)
        boolean puffs = true;      // soft cloud puffs along the wisps
    }

    private static final int N = 34;                         // samples along one wisp (quads per wisp)
    private static final int PUFFS = 9;                      // puffs per wisp
    private static final float TWO_PI = (float) (Math.PI * 2.0);
    private static final float[] LAYER_W = {1.00f, 0.72f, 1.22f, 0.86f};      // thickness of each layer's wisp
    private static final float[] LAYER_R = {1.00f, 0.80f, 1.18f, 0.92f};      // loop radius of each layer's wisp
    private static final float[] LAYER_T = {5.6f, 6.7f, 7.9f, 9.1f};          // seconds one cycle of each layer takes (at speed 1)

    // scratch (render thread only)
    private static final float[] PX = new float[N + 1], PY = new float[N + 1], PZ = new float[N + 1];
    private static final float[] SX = new float[N + 1], SY = new float[N + 1], SZ = new float[N + 1];
    private static final float[] WW = new float[N + 1], AA = new float[N + 1], UU = new float[N + 1];

    // ------------------------------------------------------------------ small helpers
    private static float sm(float x) { x = x < 0f ? 0f : (x > 1f ? 1f : x); return x * x * (3f - 2f * x); }
    private static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    /** hash of two ints -> 0..1 */
    static float hash(int a, int b) {
        int h = a * 0x27d4eb2d ^ b * 0x165667b1;
        h ^= h >>> 15; h *= 0x2c1b3c6d; h ^= h >>> 12; h *= 0x297a2d39; h ^= h >>> 15;
        return (h >>> 8) / 16777216f;
    }

    /** smooth 1D value noise, -1..1 */
    static float vnoise(float x, int seed) {
        int i = (int) Math.floor(x);
        float f = x - i;
        f = f * f * (3f - 2f * f);
        return lerp(hash(i, seed), hash(i + 1, seed), f) * 2f - 1f;
    }

    /**
     * Adds the mist of one row.
     *
     * @param o         eye-space centre of the sign (layout px 0,0,0)
     * @param r,d,n     eye-space vector of ONE layout px to the right / down / toward the front of the sign
     * @param rowHalfLen half length of the row (layout px), rowY = its height (layout px, down is +), rowH = row spacing (layout px)
     * @param time      seconds (wall clock, keeps drifting while a song is paused)
     * @param seed      different for every row of every line
     * @param fade      0..1 overall opacity of the line right now (its entrance and exit fades)
     * @param shrink    0..1 how big the line still is (it shrinks a little while it leaves)
     * @param lr,lg,lb  tint (the light at the sign)
     * @return number of quads added
     */
    static int addRow(Mesh wisp, Mesh puff, Look k,
                      float ox, float oy, float oz, float rx, float ry, float rz, float dx, float dy, float dz, float nx, float ny, float nz,
                      float rowHalfLen, float rowY, float rowH,
                      float time, int seed, float fade, float shrink, float lr, float lg, float lb) {
        if (fade < 0.004f || k.opacity < 0.004f) return 0;
        final float s = (float) Math.sqrt(rx * rx + ry * ry + rz * rz);          // blocks per layout px
        final float lenRow = Math.max(2f * rowHalfLen, 2.2f * rowH);
        final int layers = Math.max(1, Math.min(4, k.layers));
        int quads = 0;

        for (int l = 0; l < layers; l++) {
            // ---- where this wisp is in its life
            float period = LAYER_T[l] / Math.max(0.05f, k.speed);
            float cyc = time / period + hash(seed, 100 + l) * 3f;
            int ci = (int) Math.floor(cyc);
            float u = cyc - ci;                                                    // 0 = just born, 1 = gone
            int cs = seed * 7919 + l * 104729 + ci * 15485863;                      // every cycle has its own random shape
            float env = sm(u / 0.36f) * (1f - sm((u - 0.56f) / 0.44f));            // invisible -> visible -> faded away
            float kk = lerp(0.28f, 1f, sm(u / 0.5f)) * lerp(1f, 0.38f, sm((u - 0.5f) / 0.5f)) * shrink;   // tiny -> full size -> shrinking
            float alphaMul = env * fade * k.opacity;
            if (alphaMul < 0.004f) continue;

            // ---- shape of this cycle
            float dir = hash(cs, 1) > 0.5f ? 1f : -1f;
            float wispLen = Math.max(3.4f * rowH, lenRow * (0.42f + 0.30f * hash(cs, 2)));
            float ease = u * u * (3f - 2f * u);
            float cx = lerp(-0.5f * lenRow, 0.5f * lenRow, dir > 0 ? ease : 1f - ease);          // the wisp drifts along the row
            float loops = (1.5f + 1.3f * hash(cs, 3)) * k.curl;                                  // turns around the row per row length
            float phi0 = TWO_PI * hash(cs, 4);
            float spin = (hash(cs, 5) > 0.5f ? 1f : -1f) * (0.6f + 0.8f * hash(cs, 6));
            float yBias = (hash(cs, 7) - 0.5f) * 0.55f * rowH;                                   // the loop axis sits a little above / below the row
            float zBias = (hash(cs, 8) - 0.5f) * 0.35f * rowH;
            float tilt = (hash(cs, 9) - 0.5f) * 0.9f * rowH;
            float r0 = 0.78f * rowH * k.size * LAYER_R[l];
            float w0 = 0.72f * rowH * k.size * LAYER_W[l];
            float sc1 = hash(cs, 10) * 10f, sc2 = hash(cs, 11) * 10f, sc3 = hash(cs, 12) * 10f, sc4 = hash(cs, 13) * 10f;
            float scroll = time * 0.045f * k.speed * dir + hash(cs, 14) * 5f + l * 0.37f;
            float tile = Math.max(1e-4f, 7.0f * w0 * s);                                         // blocks of ribbon per texture repeat

            // ---- the curve
            float arc = 0f;
            for (int i = 0; i <= N; i++) {
                float tau = i / (float) N;
                float xl = cx + (tau - 0.5f) * wispLen;
                float xn = xl / lenRow;
                float theta = phi0 + TWO_PI * loops * xn
                        + 0.9f * (float) Math.sin(TWO_PI * 0.55f * xn + time * 0.33f * k.speed + l * 1.7f + phi0)
                        + time * 0.22f * k.speed * spin;
                float taper = (float) Math.pow(Math.sin(Math.PI * tau), 0.75);
                float rad = r0 * kk * (0.62f + 0.38f * (0.5f + 0.5f * vnoise(tau * 2.4f + sc1 + time * 0.17f * k.speed, cs)));
                rad *= 0.35f + 0.65f * taper;                                                    // the tips come back to the row
                float wob = vnoise(tau * 6.5f + time * 0.40f * k.speed + sc2, cs + 1) * 0.12f * r0 * kk;
                float yl = rowY + yBias + tilt * xn + rad * (float) Math.sin(theta) * 0.88f + wob;
                float zl = zBias + rad * (float) Math.cos(theta) * 1.12f + vnoise(tau * 5.1f + time * 0.30f * k.speed + sc3, cs + 2) * 0.10f * r0 * kk;
                float px = ox + xl * rx + yl * dx + zl * nx;
                float py = oy + xl * ry + yl * dy + zl * ny;
                float pz = oz + xl * rz + yl * dz + zl * nz;
                PX[i] = px; PY[i] = py; PZ[i] = pz;

                float wpx = w0 * kk * taper * (0.72f + 0.28f * (0.5f + 0.5f * vnoise(tau * 3.3f + sc4 + time * 0.21f * k.speed, cs + 3)));
                WW[i] = wpx * s;
                float a = alphaMul * (float) Math.pow(taper, 0.85) * (0.62f + 0.38f * (0.5f + 0.5f * vnoise(tau * 4.2f + sc1 - time * 0.27f * k.speed, cs + 4)));
                float dist = (float) Math.sqrt(px * px + py * py + pz * pz);
                a *= sm((dist - 0.7f) / 2.0f);                                                  // never a big white blob in your face
                if (pz > -0.1f) a = 0f;                                                          // behind the camera
                AA[i] = a;
            }
            // ---- ribbon cross direction (perpendicular to the curve and to the line of sight) and texture coordinate along it.
            // The direction is kept continuous (never flips between neighbours: that would twist the ribbon into thin spikes), and a ribbon
            // that points straight at / away from the viewer, where it has no visible width, fades out instead of showing a sliver.
            float lsx = 0f, lsy = 0f, lsz = 0f;
            boolean haveS = false;
            for (int i = 0; i <= N; i++) {
                int i0 = Math.max(0, i - 3), i1 = Math.min(N, i + 3);                     // a wide window: the direction turns gradually, never in one step
                float tx = PX[i1] - PX[i0], ty = PY[i1] - PY[i0], tz = PZ[i1] - PZ[i0];
                float cxv = ty * PZ[i] - tz * PY[i], cyv = tz * PX[i] - tx * PZ[i], czv = tx * PY[i] - ty * PX[i];     // T x P
                float cl = (float) Math.sqrt(cxv * cxv + cyv * cyv + czv * czv);
                float tl = (float) Math.sqrt(tx * tx + ty * ty + tz * tz), pl = (float) Math.sqrt(PX[i] * PX[i] + PY[i] * PY[i] + PZ[i] * PZ[i]);
                float sinA = cl / Math.max(1e-6f, tl * pl);                                // 1 = ribbon across the view, 0 = edge-on
                if (cl > 1e-6f) {
                    float ux = cxv / cl, uy = cyv / cl, uz = czv / cl;
                    if (haveS && ux * lsx + uy * lsy + uz * lsz < 0f) { ux = -ux; uy = -uy; uz = -uz; }
                    if (haveS) { ux = lsx * 0.35f + ux * 0.65f; uy = lsy * 0.35f + uy * 0.65f; uz = lsz * 0.35f + uz * 0.65f;      // a little smoothing
                                 float ql = (float) Math.sqrt(ux * ux + uy * uy + uz * uz); if (ql > 1e-6f) { ux /= ql; uy /= ql; uz /= ql; } }
                    lsx = ux; lsy = uy; lsz = uz; haveS = true;
                } else if (!haveS) { lsx = 1f; haveS = true; }
                SX[i] = lsx; SY[i] = lsy; SZ[i] = lsz;
                AA[i] *= sm((sinA - 0.10f) / 0.45f);                            // a flat strip seen end-on is just a line: fade it, the puffs carry the volume there
                if (i > 0) { float ax = PX[i] - PX[i - 1], ay = PY[i] - PY[i - 1], az = PZ[i] - PZ[i - 1]; arc += (float) Math.sqrt(ax * ax + ay * ay + az * az); }
                UU[i] = arc / tile + scroll;
            }
            // ---- quads
            for (int i = 0; i < N; i++) {
                float a0 = AA[i], a1 = AA[i + 1];
                if (a0 < 0.003f && a1 < 0.003f) continue;
                if (SX[i] * SX[i + 1] + SY[i] * SY[i + 1] + SZ[i] * SZ[i + 1] < 0.55f) continue;     // the ribbon is twisting here: leave a gap instead of a thin sliver
                float w0a = WW[i], w1a = WW[i + 1];
                wisp.vert(PX[i] - SX[i] * w0a, PY[i] - SY[i] * w0a, PZ[i] - SZ[i] * w0a, UU[i], 0f, lr, lg, lb, a0);
                wisp.vert(PX[i] + SX[i] * w0a, PY[i] + SY[i] * w0a, PZ[i] + SZ[i] * w0a, UU[i], 1f, lr, lg, lb, a0);
                wisp.vert(PX[i + 1] + SX[i + 1] * w1a, PY[i + 1] + SY[i + 1] * w1a, PZ[i + 1] + SZ[i + 1] * w1a, UU[i + 1], 1f, lr, lg, lb, a1);
                wisp.vert(PX[i + 1] - SX[i + 1] * w1a, PY[i + 1] - SY[i + 1] * w1a, PZ[i + 1] - SZ[i + 1] * w1a, UU[i + 1], 0f, lr, lg, lb, a1);
                quads++;
            }
            // ---- soft puffs along the wisp (camera-facing blobs, they give the mist its body)
            if (k.puffs) {
                for (int j = 0; j < PUFFS; j++) {
                    float tj = (j + 0.5f + (hash(cs, 20 + j) - 0.5f) * 0.6f) / PUFFS;
                    float fi = Math.max(0f, Math.min(N - 0.001f, tj * N));
                    int i0 = (int) fi;
                    float f = fi - i0;
                    float a = lerp(AA[i0], AA[i0 + 1], f) * 0.62f;
                    if (a < 0.003f) continue;
                    float w = lerp(WW[i0], WW[i0 + 1], f);
                    float side = (hash(cs, 40 + j) - 0.5f) * 0.9f * w;
                    float cxp = lerp(PX[i0], PX[i0 + 1], f) + lerp(SX[i0], SX[i0 + 1], f) * side;
                    float cyp = lerp(PY[i0], PY[i0 + 1], f) + lerp(SY[i0], SY[i0 + 1], f) * side;
                    float czp = lerp(PZ[i0], PZ[i0 + 1], f) + lerp(SZ[i0], SZ[i0 + 1], f) * side;
                    float size = Math.max(0.02f, w * (1.55f + 0.95f * hash(cs, 60 + j)));
                    float ang = TWO_PI * hash(cs, 80 + j);
                    float ca = (float) Math.cos(ang) * size, sa = (float) Math.sin(ang) * size;
                    puff.vert(cxp - ca + sa, cyp - sa - ca, czp, 0f, 0f, lr, lg, lb, a);
                    puff.vert(cxp + ca + sa, cyp + sa - ca, czp, 1f, 0f, lr, lg, lb, a);
                    puff.vert(cxp + ca - sa, cyp + sa + ca, czp, 1f, 1f, lr, lg, lb, a);
                    puff.vert(cxp - ca - sa, cyp - sa + ca, czp, 0f, 1f, lr, lg, lb, a);
                    quads++;
                }
            }
        }
        return quads;
    }
}
