#version 150
// Sky Music "Cine" post shader. One full-screen pass:
//  soft bloom + light FXAA + filmic curve + time-of-day grading, then the sun's god rays added on top.
// God rays = "Volumetric Light Scattering as a Post-Process" (GPU Gems 3) exactly as in the glsl-godrays demo
// (github.com/Erkaman/glsl-godrays, MIT licence): the same loop, the same default numbers.
// Q = 0 light (phones), 1 balanced, 2 high (Q only changes bloom / FXAA, the god rays are the same on every step).

uniform sampler2D DiffuseSampler;
uniform sampler2D DepthSampler;
uniform vec2 OutSize;

uniform float SunU;
uniform float SunV;
uniform float SunR;        // radius of the sun disc in screen space (units of screen height)
uniform vec3 RayColor;     // colour of the sun (the demo's sun is white)
uniform float RayVis;      // 0..1: sun above the horizon, not raining, overworld, not under water
uniform float Warm;
uniform float Aspect;
uniform float Q;
uniform float Night;
uniform float Rain;

in vec2 texCoord;
out vec4 fragColor;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

// ---- light FXAA (only at Q = 2) ----
vec3 fxaa(vec2 uv, vec3 rgbM) {
    vec2 px = 1.0 / OutSize;
    vec3 rgbNW = texture(DiffuseSampler, uv + vec2(-1.0, -1.0) * px).rgb;
    vec3 rgbNE = texture(DiffuseSampler, uv + vec2( 1.0, -1.0) * px).rgb;
    vec3 rgbSW = texture(DiffuseSampler, uv + vec2(-1.0,  1.0) * px).rgb;
    vec3 rgbSE = texture(DiffuseSampler, uv + vec2( 1.0,  1.0) * px).rgb;
    float lNW = luma(rgbNW), lNE = luma(rgbNE), lSW = luma(rgbSW), lSE = luma(rgbSE), lM = luma(rgbM);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    if (lMax - lMin < max(0.03, lMax * 0.125)) return rgbM;
    vec2 dir;
    dir.x = -((lNW + lNE) - (lSW + lSE));
    dir.y =  ((lNW + lSW) - (lNE + lSE));
    float dirReduce = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-6.0), vec2(6.0)) * px;
    vec3 a = 0.5 * (texture(DiffuseSampler, uv + dir * (1.0 / 3.0 - 0.5)).rgb
                  + texture(DiffuseSampler, uv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 b = a * 0.5 + 0.25 * (texture(DiffuseSampler, uv + dir * -0.5).rgb
                             + texture(DiffuseSampler, uv + dir *  0.5).rgb);
    float lB = luma(b);
    return (lB < lMin || lB > lMax) ? a : b;
}

// ---------------- god rays (glsl-godrays by Erkaman, MIT) ----------------
// The demo renders an "occlusion texture" (white sun, everything that could hide the sun black) and then, for every pixel,
// adds up 100 samples of it on the way from the pixel to the sun. Here the occlusion texture is not stored: it is evaluated
// where the loop samples it - a white disc around the sun that only counts where the depth buffer shows sky (terrain, trees,
// clouds, the lyrics ... are black). Every sample that cannot land on the disc is 0 in the demo, so those are skipped;
// the number that comes out is the same as the full 100 sample loop.
const int   RAY_SAMPLES  = 100;    // numSamples
const float RAY_DENSITY  = 1.0;    // density
const float RAY_WEIGHT   = 0.01;   // weight
const float RAY_DECAY    = 1.0;    // decay (1.0 = no decay; with this value the demo's illuminationDecay is always 1, so it is left out)
const float RAY_EXPOSURE = 1.0;    // exposure

float occlusion(vec2 p, vec2 sunUV, float aa) {
    if (p.x < 0.0 || p.x > 1.0 || p.y < 0.0 || p.y > 1.0) return 0.0;      // off screen: nothing was rendered there
    float disc = clamp((SunR - length((p - sunUV) * vec2(Aspect, 1.0))) / aa + 0.5, 0.0, 1.0);
    if (disc <= 0.0) return 0.0;
    return disc * step(0.99999, textureLod(DepthSampler, p, 0.0).r);           // sun only where we look at the sky
}

float godrays(vec2 uv) {
    vec2 sunUV = vec2(SunU, SunV);
    float aa = 1.5 / OutSize.y;                                               // soft edge of the disc, like the demo's bilinear occlusion texture
    vec2 deltaTextCoord = (uv - sunUV) * (1.0 / float(RAY_SAMPLES)) * RAY_DENSITY;
    float dist = max(length((uv - sunUV) * vec2(Aspect, 1.0)), 1e-5);
    // sample k (1..N) sits at uv - k * delta, i.e. at fraction t = k * density / N of the way to the sun, so its distance to the sun is |1 - t| * dist
    float reach = (SunR + aa) / dist;
    float kPerT = float(RAY_SAMPLES) / RAY_DENSITY;
    int k0 = max(1, int(ceil((1.0 - reach) * kPerT)));
    int k1 = min(RAY_SAMPLES, int(floor((1.0 + reach) * kPerT)));
    float acc = 0.0;
    for (int k = k0; k <= k1; k++) acc += occlusion(uv - deltaTextCoord * float(k), sunUV, aa) * RAY_WEIGHT;
    return acc * RAY_EXPOSURE;
}

void main() {
    vec2 uv = texCoord;
    float noise = hash12(gl_FragCoord.xy);
    vec3 c = texture(DiffuseSampler, uv).rgb;
    if (Q > 1.5) c = fxaa(uv, c);

    // ---------- bloom: golden-spiral taps, rotated per pixel so few taps still look smooth ----------
    int bn = Q > 1.5 ? 12 : (Q > 0.5 ? 8 : 5);
    float radius = 0.022;
    vec3 bloom = vec3(0.0);
    float rot = noise * 6.2831853;
    for (int i = 0; i < bn; i++) {
        float r = sqrt((float(i) + 0.5) / float(bn));
        float a = float(i) * 2.3999632 + rot;
        vec2 o = vec2(cos(a) / Aspect, sin(a)) * r * radius;
        vec3 s = texture(DiffuseSampler, uv + o).rgb;
        float br = max(luma(s) - 0.92, 0.0);
        bloom += s * br * (1.0 - r * 0.6);
    }
    bloom /= float(bn);
    c += bloom * 2.2 * (1.0 - Rain * 0.5) * (1.0 - Night * 0.35);

    // ---------- filmic shoulder (keeps bright rays/bloom from clipping to flat white) ----------
    vec3 fm = vec3(1.0) - exp(-c * 1.45);
    c = mix(c, fm, 0.55);

    // ---------- grading ----------
    float l = luma(c);
    float mx = max(c.r, max(c.g, c.b)), mn = min(c.r, min(c.g, c.b));
    float vib = 0.28 * (1.0 - (mx - mn));                                   // lifts dull colours more than vivid ones
    c = mix(vec3(l), c, 1.0 + vib + 0.06);
    c = mix(c, c * vec3(1.06, 1.0, 0.92), Warm * 0.7);                      // golden hour
    c = mix(c, c * vec3(0.93, 0.98, 1.05) + vec3(0.003, 0.006, 0.014), Night * 0.6); // moonlit blue (kept mild so the aurora stays green)
    c = mix(c, vec3(luma(c)) * vec3(0.95, 0.98, 1.02), Rain * 0.35);        // wet, flatter look
    c = mix(c, smoothstep(0.0, 1.0, c), 0.30);                              // gentle S-curve

    vec2 q = uv - 0.5;
    c *= 1.0 - dot(q, q) * 0.55;                                            // vignette
    c += (noise - 0.5) / 255.0;                                             // dither

    // ---------- god rays: added on top of the finished picture, like the demo's additive pass ----------
    if (RayVis > 0.001) c += RayColor * (godrays(uv) * RayVis);

    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
