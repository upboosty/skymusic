#version 150
// Sky Music "Cine" post shader. One full-screen pass:
//  dithered god rays (sky-depth masked) + soft bloom + light FXAA + filmic curve + time-of-day grading.
// Q = 0 light (phones), 1 balanced, 2 high.

uniform sampler2D DiffuseSampler;
uniform sampler2D DepthSampler;
uniform vec2 OutSize;

uniform float SunU;
uniform float SunV;
uniform float RayVis;
uniform float Warm;
uniform float Aspect;
uniform float Q;
uniform float Night;
uniform float Rain;

in vec2 texCoord;
out vec4 fragColor;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float luma(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

// ---- light FXAA (only at Q = 2) ----
vec3 fxaa(vec2 uv, vec3 rgbM) {
    vec2 px = 1.0 / OutSize;
    vec3 rgbNW = texture(DiffuseSampler, uv + vec2(-1.0, -1.0) * px).rgb;
    vec3 rgbNE = texture(DiffuseSampler, uv + vec2( 1.0, -1.0) * px).rgb;
    vec3 rgbSW = texture(DiffuseSampler, uv + vec2(-1.0,  1.0) * px).rgb;
    vec3 rgbSE = texture(DiffuseSampler, uv + vec2( 1.0,  1.0) * px).rgb;
    float lNW = luma(rgbNW), lNE = luma(rgbNE), lSW = luma(rgbSW), lSE = luma(rgbSE), lM = luma(rgbM);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    if (lMax - lMin < max(0.03, lMax * 0.125)) return rgbM;
    vec2 dir;
    dir.x = -((lNW + lNE) - (lSW + lSE));
    dir.y =  ((lNW + lSW) - (lNE + lSE));
    float dirReduce = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-6.0), vec2(6.0)) * px;
    vec3 a = 0.5 * (texture(DiffuseSampler, uv + dir * (1.0 / 3.0 - 0.5)).rgb
                  + texture(DiffuseSampler, uv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 b = a * 0.5 + 0.25 * (texture(DiffuseSampler, uv + dir * -0.5).rgb
                             + texture(DiffuseSampler, uv + dir *  0.5).rgb);
    float lB = luma(b);
    return (lB < lMin || lB > lMax) ? a : b;
}

void main() {
    vec2 uv = texCoord;
    float noise = hash12(gl_FragCoord.xy);
    vec3 c = texture(DiffuseSampler, uv).rgb;
    if (Q > 1.5) c = fxaa(uv, c);

    // ---------- bloom: golden-spiral taps, rotated per pixel so few taps still look smooth ----------
    int bn = Q > 1.5 ? 12 : (Q > 0.5 ? 8 : 5);
    float radius = 0.022;
    vec3 bloom = vec3(0.0);
    float rot = noise * 6.2831853;
    for (int i = 0; i < bn; i++) {
        float r = sqrt((float(i) + 0.5) / float(bn));
        float a = float(i) * 2.3999632 + rot;
        vec2 o = vec2(cos(a) / Aspect, sin(a)) * r * radius;
        vec3 s = texture(DiffuseSampler, uv + o).rgb;
        float br = max(luma(s) - 0.92, 0.0);
        bloom += s * br * (1.0 - r * 0.6);
    }
    bloom /= float(bn);
    c += bloom * 2.2 * (1.0 - Rain * 0.5) * (1.0 - Night * 0.35);

    // ---------- god rays ----------
    if (RayVis > 0.001) {
        int n = Q > 1.5 ? 18 : (Q > 0.5 ? 12 : 8);
        vec2 sunUV = vec2(SunU, SunV);
        vec2 delta = (sunUV - uv) * (0.95 / float(n));
        vec2 p = uv + delta * noise;                 // jitter hides banding at low sample counts
        float decay = 1.0, acc = 0.0;
        for (int i = 0; i < n; i++) {
            p += delta;
            float sky = step(0.99999, texture(DepthSampler, clamp(p, 0.001, 0.999)).r);
            acc += sky * decay;
            decay *= 0.94;
        }
        acc /= float(n);

        vec2 dd = sunUV - uv;
        dd.x *= Aspect;
        float d = length(dd);
        float fall = clamp(1.0 - d * 0.8, 0.0, 1.0);
        fall *= fall;

        vec3 rayColor = mix(vec3(1.0, 0.94, 0.80), vec3(1.0, 0.52, 0.24), Warm);
        c += rayColor * acc * fall * RayVis * 0.42;
        c += rayColor * pow(fall, 3.0) * RayVis * 0.16;                       // wide halo
        c += rayColor * exp(-d * 16.0) * RayVis * 0.40;                       // hot core glow
    }

    // ---------- filmic shoulder (keeps bright rays/bloom from clipping to flat white) ----------
    vec3 fm = vec3(1.0) - exp(-c * 1.45);
    c = mix(c, fm, 0.55);

    // ---------- grading ----------
    float l = luma(c);
    float mx = max(c.r, max(c.g, c.b)), mn = min(c.r, min(c.g, c.b));
    float vib = 0.28 * (1.0 - (mx - mn));                                   // lifts dull colours more than vivid ones
    c = mix(vec3(l), c, 1.0 + vib + 0.06);
    c = mix(c, c * vec3(1.06, 1.0, 0.92), Warm * 0.7);                      // golden hour
    c = mix(c, c * vec3(0.93, 0.98, 1.05) + vec3(0.003, 0.006, 0.014), Night * 0.6); // moonlit blue (kept mild so the aurora stays green)
    c = mix(c, vec3(luma(c)) * vec3(0.95, 0.98, 1.02), Rain * 0.35);        // wet, flatter look
    c = mix(c, smoothstep(0.0, 1.0, c), 0.30);                              // gentle S-curve

    vec2 q = uv - 0.5;
    c *= 1.0 - dot(q, q) * 0.55;                                            // vignette
    c += (noise - 0.5) / 255.0;                                             // dither

    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
