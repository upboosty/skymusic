#!/usr/bin/env python3
"""
Bakes the two soft smoke textures used by the lyric mist trail (MistTrail / MistRender):

  assets/skymusic/textures/mist/wisp.png   512 x 256  tileable along x. A strip of smoke: swirling filaments inside a feathered,
                                           soft-edged band (alpha = smoke density, rgb = slightly shaded white). Mapped along the mist ribbon.
  assets/skymusic/textures/mist/puff.png   256 x 256  one fuzzy cloud blob with a soft, noisy rim. Used for the volume puffs.

  assets/skymusic/textures/mist/spark.png  64 x 64    a four-point glint (soft core, long thin spikes, short diagonal spikes, faint halo). The twinkling sparkles
                                           that fly off every letter when it is sung.
  assets/skymusic/textures/mist/glow.png   64 x 64    a soft round glow, smooth to exactly zero at the edge. The bloom behind every letter while it is sung and
                                           the soft light behind each row.
                                           (spark and glow are ADDITIVE textures like the sky's star.png: rgb = brightness, alpha = 255 everywhere, so vanilla's
                                            alpha test can never clip their soft edges. Only numpy + Pillow needed:  python3 tools/gen_mist.py --fx-only)

The smoke textures (wisp, puff) are pure white smoke on transparent: the mod tints them with the world light at the sign. Everything is generated from periodic
fractal noise (FFT) that is domain-warped a few times, which is what gives the curling, filament-like look of real smoke.

Needs: numpy, scipy, Pillow.   Run:  python3 tools/gen_mist.py     (optional: --preview writes tools/mist_preview.png)
"""
import os, sys
import numpy as np
from scipy.ndimage import map_coordinates, gaussian_filter
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "src", "main", "resources", "assets", "skymusic", "textures", "mist")


def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0.0, 1.0)
    return t * t * (3 - 2 * t)


def pnoise(h, w, beta, seed, kx=1.0):
    """periodic (tileable) noise with a 1/f^beta power spectrum, unit std. kx > 1 stretches the features along x."""
    r = np.random.default_rng(seed)
    fy = np.fft.fftfreq(h)[:, None] * h
    fx = np.fft.fftfreq(w)[None, :] * w
    f = np.sqrt((fx * kx) ** 2 + fy ** 2)
    f[0, 0] = 1.0
    amp = f ** (-beta / 2.0)
    amp[0, 0] = 0.0
    spec = (r.normal(size=(h, w)) + 1j * r.normal(size=(h, w))) * amp
    n = np.fft.ifft2(spec).real
    return n / n.std()


def warp(field, dx, dy):
    h, w = field.shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float64)
    return map_coordinates(field, [yy + dy, xx + dx], order=1, mode="grid-wrap")


def smoke_field(h, w, seed, kx, strength, passes=2, beta=3.4):
    """silky smoke in roughly -2..2: very smooth fractal noise that is pushed around by two smooth flow fields (a cheap stand-in for
    a curl-noise advection). Smooth inputs + moderate displacement give long, curling, silky strands instead of speckle."""
    base = pnoise(h, w, beta, seed, kx)
    for p in range(passes):
        ax = pnoise(h, w, 4.2, seed + 11 + p, kx * 0.6)
        ay = pnoise(h, w, 4.2, seed + 23 + p, kx * 0.6)
        base = warp(base, ax * strength * 1.8, ay * strength)
    return (base - base.mean()) / base.std()


def make_wisp(w=512, h=256, seed=5):
    s = smoke_field(h, w, seed, kx=4.5, strength=26.0)
    body = smooth(-1.3, 1.5, s)                                # broad, cloudy density
    strand = np.exp(-(s * 1.15) ** 2)                          # thin silky strands where the field crosses zero
    s2 = smoke_field(h, w, seed + 40, kx=3.0, strength=20.0)
    strand2 = np.exp(-(s2 * 1.3) ** 2)
    dens = np.clip(0.36 + 0.56 * body + 0.13 * strand * (0.30 + 0.70 * body) + 0.08 * strand2 * (0.4 + 0.6 * body), 0.0, 1.0)
    # the band: a soft meandering profile across the strip, no flat top and no straight edge
    v = (np.arange(h)[:, None] + 0.5) / h
    mean = 0.11 * pnoise(h, w, 4.0, seed + 5, 3.0)
    d = np.abs(2.0 * (v + mean) - 1.0)                         # 0 in the middle, 1 at the edge
    prof = np.exp(-(d / 0.58) ** 2.0) * smooth(1.0, 0.50, d)
    soft_edge = 0.5 + 0.5 * smooth(-1.4, 1.4, pnoise(h, w, 3.6, seed + 9, 3.0))   # the rim is thinner in places, thicker in others
    prof = prof * (0.50 + 0.50 * soft_edge)
    a = prof * dens
    a = gaussian_filter(a, (2.6, 1.4), mode=("nearest", "wrap"))        # softer across the strip than along it: silky, never a crisp line
    a = np.clip(a * 1.45, 0.0, 1.0) ** 1.0
    a = np.minimum(a, 0.93)
    a *= smooth(0.0, 0.05, v) * smooth(0.0, 0.05, 1.0 - v)    # exactly zero at the top / bottom row: no seam when v wraps
    shade = 0.84 + 0.16 * smooth(0.05, 0.8, a)                 # thin parts a little grey, dense core pure white
    return a, shade


def make_puff(n=256, seed=21):
    base = smoke_field(n, n, seed, kx=1.0, strength=14.0, passes=2, beta=3.6)
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    r = np.hypot(xx - n / 2.0 + 0.5, yy - n / 2.0 + 0.5) / (n / 2.0)
    rr = r + 0.16 * pnoise(n, n, 3.2, seed + 3) * smooth(0.05, 0.6, r)   # a softly wobbling rim
    core = np.exp(-(rr / 0.62) ** 2.0)
    a = core * (0.55 + 0.45 * smooth(-1.5, 1.5, base))
    a = gaussian_filter(a, 2.0)
    a *= smooth(1.0, 0.80, r)                                            # zero at the edge of the square
    a = np.clip(a * 1.1, 0.0, 0.85)
    shade = 0.86 + 0.14 * smooth(0.0, 0.8, a)
    return a, shade


def make_spark(n=64):
    """a four-point glint: bright soft core, two long thin spikes (x / y), two short diagonal spikes and a faint halo. brightness 0 at the edge."""
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    x = (xx - n / 2.0 + 0.5) / (n / 2.0)
    y = (yy - n / 2.0 + 0.5) / (n / 2.0)
    r = np.hypot(x, y)
    core = np.exp(-(r / 0.12) ** 2.0)
    halo = 0.30 * np.exp(-(r / 0.32) ** 2.0)
    ax, ay = np.abs(x), np.abs(y)
    spike_x = np.exp(-(ay / 0.050) ** 2.0) * np.exp(-(ax / 0.62) ** 1.15)      # long horizontal spike, thinner toward its tip
    spike_y = np.exp(-(ax / 0.050) ** 2.0) * np.exp(-(ay / 0.62) ** 1.15)
    u = (x + y) / np.sqrt(2.0); v = (x - y) / np.sqrt(2.0)                     # the 45 degree axes
    diag = 0.40 * (np.exp(-(np.abs(v) / 0.050) ** 2.0) * np.exp(-(np.abs(u) / 0.30) ** 1.2)
                   + np.exp(-(np.abs(u) / 0.050) ** 2.0) * np.exp(-(np.abs(v) / 0.30) ** 1.2))
    a = 1.0 - (1.0 - core) * (1.0 - halo) * (1.0 - 0.95 * spike_x) * (1.0 - 0.95 * spike_y) * (1.0 - diag)
    a *= smooth(1.0, 0.82, r)                                                  # exactly zero at the edge of the square
    return np.clip(a, 0.0, 1.0)


def make_glow(n=64):
    """a soft round glow: bright middle, long gentle tail, exactly zero at the edge of the square (no visible quad)"""
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float64)
    r = np.hypot(xx - n / 2.0 + 0.5, yy - n / 2.0 + 0.5) / (n / 2.0)
    a = 0.60 * np.exp(-(r / 0.26) ** 2.0) + 0.40 * np.exp(-(r / 0.58) ** 2.0)
    a *= smooth(1.0, 0.55, r)
    return np.clip(a, 0.0, 1.0)


def save_add(inten, name):
    """additive texture: rgb = brightness, alpha = 255 everywhere (like sky/star.png)"""
    h, w = inten.shape
    v = np.clip(inten * 255.0 + 0.5, 0, 255).astype(np.uint8)
    img = np.zeros((h, w, 4), np.uint8)
    img[..., 0] = v; img[..., 1] = v; img[..., 2] = v; img[..., 3] = 255
    os.makedirs(OUT, exist_ok=True)
    Image.fromarray(img, "RGBA").save(os.path.join(OUT, name), optimize=True)
    with open(os.path.join(OUT, name + ".mcmeta"), "w") as f:
        f.write('{"texture":{"blur":true,"clamp":true}}')


def save(a, shade, name):
    h, w = a.shape
    rgb = np.clip(shade * 255.0, 0, 255).astype(np.uint8)
    img = np.zeros((h, w, 4), np.uint8)
    img[..., 0] = rgb; img[..., 1] = rgb; img[..., 2] = np.clip(shade * 255.0 + 4, 0, 255).astype(np.uint8)   # a hair of blue: cool white
    img[..., 3] = np.clip(a * 255.0 + 0.5, 0, 255).astype(np.uint8)
    os.makedirs(OUT, exist_ok=True)
    Image.fromarray(img, "RGBA").save(os.path.join(OUT, name), optimize=True)


def main():
    if "--fx-only" in sys.argv:                       # only the two additive effect textures (no scipy needed)
        save_add(make_spark(), "spark.png")
        save_add(make_glow(), "glow.png")
        print("wrote spark.png, glow.png")
        return
    wa, ws = make_wisp()
    pa, ps = make_puff()
    save(wa, ws, "wisp.png")
    save(pa, ps, "puff.png")
    save_add(make_spark(), "spark.png")
    save_add(make_glow(), "glow.png")
    for n in ("wisp.png", "puff.png"):
        with open(os.path.join(OUT, n + ".mcmeta"), "w") as f:
            f.write('{"texture":{"blur":true,"clamp":false}}')
    print("wrote", OUT)
    if "--preview" in sys.argv:
        w = np.concatenate([wa, wa], axis=1)
        sw = np.concatenate([ws, ws], axis=1)
        strip = (w * sw * 255).astype(np.uint8)
        puff = (pa * ps * 255).astype(np.uint8)
        canvas = np.zeros((256 + 256, 1024), np.uint8)
        canvas[:256, :] = strip
        canvas[256:, :256] = puff
        Image.fromarray(canvas, "L").save(os.path.join(HERE, "mist_preview.png"))


if __name__ == "__main__":
    main()
