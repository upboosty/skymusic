package dev.skymusic;

/**
 * Before / after benchmark of building the lyric letters (dev tool, not part of the mod jar).
 *
 * "Before" is a verbatim port of the previous SkyRenderer.letterMotion + meshGlyph (v15 of the source zip); "after" is LyricMotion + LyricMesh.
 * Both build the same scene (three lines of text on screen, one of them mid-animation) into a sink that only counts and checksums vertices,
 * so what is measured is the work done on the CPU before anything reaches the GPU buffers. In the game every vertex is then written twice
 * (colour batch + depth pre-pass batch), so the vertex count is the number that matters most.
 *
 *   javac -d /tmp/lb src/main/java/dev/skymusic/{MistTrail,MeshFont,LyricMotion,LyricMesh}.java tools/LyricBench.java
 *   java -cp /tmp/lb:src/main/resources dev.skymusic.LyricBench
 */
public final class LyricBench {
    // ------------------------------------------------------------------ the scene
    static final String TEXT = "Hold me closer tiny dancer";
    static final float[] CHUNK_T = {1.0f, 3.5f, 6.0f};          // seconds since each of the three visible lines was born (one is mid-animation)
    static final float[] CHUNK_DIM = {0f, 0.4f, 0.8f};
    static MeshFont.Glyph[] glyphs; static float[] pens, advs; static int n; static float rowW;
    static double checksum = 0; static long verts = 0;

    // sign in eye space
    static float eOx = 0f, eOy = 0.1f, eOz = -7f, eRx, eRy, eRz, eUx, eUy, eUz, eNx, eNy, eNz, eS = 0.034f;
    static float lLx = -0.33f, lLy = -0.27f, lLz = 0.42f, thickMul = 1f, tanHX = 1.78f, tanHY = 0.70f;

    static float smooth(float x) { x = x < 0f ? 0f : (x > 1f ? 1f : x); return x * x * (3f - 2f * x); }
    static float clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }

    // ------------------------------------------------------------------ BEFORE: verbatim port of the v15 code
    static final class Old {
        static final double ENTER_Z = 0.40, ENTER_W = 14.0; static final float ENTER_DROP = 22f;
        static final float ENTER_VN = (float) peakVel(ENTER_Z, ENTER_W);
        static double animSecs = 0; static float sPos, sVel, mSx, mSy, mLean, mOff, mA;
        static float lPx, lPy, lPz, lAx, lAy, lAz, lBx, lBy, lBz, lCx, lCy, lCz;
        static final float FRONT_AMB = 0.84f, FRONT_DIFF = 0.16f, WALL_AMB = 0.50f, WALL_DIFF = 0.46f, DEPTH = 6f;
        static boolean frontToYou = true, ghostMode = false;

        static double peakVel(double z, double w) { double wd = w * Math.sqrt(1.0 - z * z), k = z * w, t = Math.atan(wd / k) / wd; return w * w / wd * Math.exp(-k * t) * Math.sin(wd * t); }
        static void springPV(float t, double z, double w) {
            if (t <= 0f) { sPos = 0f; sVel = 0f; return; }
            double wd = w * Math.sqrt(1.0 - z * z), k = z * w;
            if (t > 9.0 / k) { sPos = 1f; sVel = 0f; return; }
            double e = Math.exp(-k * t), c = Math.cos(wd * t), sn = Math.sin(wd * t);
            sPos = (float) (1.0 - e * (c + (k / wd) * sn)); sVel = (float) (e * (w * w / wd) * sn);
        }
        static float wobble(float t) { if (t <= 0f || t > 1.7f) return 0f; float ramp = t >= 0.04f ? 1f : smooth(t / 0.04f); return ramp * (float) (Math.exp(-5.2 * t) * Math.sin(21.0 * t)); }
        static float sway(float t) { if (t <= 0f || t > 1.7f) return 0f; float ramp = t >= 0.05f ? 1f : smooth(t / 0.05f); return ramp * (float) (Math.exp(-4.6 * t) * Math.sin(17.0 * t)); }
        static void letterMotion(int gi, int total, float tIn, float onset, float sl, float p, float dimK) {
            float te = tIn - (onset - 0.22f);
            springPV(te, ENTER_Z, ENTER_W);
            float e = sPos, v = sVel / ENTER_VN;
            if (v < 0f) v *= 2.4f;
            float sy = 1f + 0.26f * v, sx = 1f - 0.17f * v;
            float off = (1f - e) * ENTER_DROP;
            mA = smooth(clamp01(te / 0.20f));
            float ts = tIn - onset;
            float wv = wobble(ts);
            sy *= 1f + 0.20f * wv; sx *= 1f - 0.13f * wv;
            mLean = ((gi & 1) == 0 ? 1f : -1f) * 0.12f * sway(ts);
            springPV(ts, 0.50, 15.0);
            off -= 3.2f * sPos;
            float ev = (float) Math.sin(Math.PI * sl);
            sy *= 1f + 0.14f * ev; sx *= 1f - 0.09f * ev;
            off -= sl * 5f;
            float idleK = p * (1f - dimK) * (1f - sl) * mA;
            sy *= 1f + 0.014f * (float) Math.sin(animSecs * 3.4 + gi * 0.65) * idleK;
            sx *= 1f - 0.009f * (float) Math.sin(animSecs * 3.4 + gi * 0.65) * idleK;
            off += 0.5f * (float) Math.sin(animSecs * 2.3 + gi * 0.9) * idleK;
            mSx = sx; mSy = sy; mOff = off;
        }
        static void vtx(float vx, float vy, float vz, float r, float g, float b, float a) {
            float x = lPx + vx * lAx + vy * lBx + vz * lCx, y = lPy + vx * lAy + vy * lBy + vz * lCy, z = lPz + vx * lAz + vy * lBz + vz * lCz;
            verts++; checksum += x + y + z + r + g + b + a;              // colour batch
            verts++; checksum += x + y + z;                              // the depth pre-pass writes every vertex a second time
        }
        static void meshGlyph(MeshFont.Glyph g, float pen, float base, float pvx, float sx, float sy, float lean, float r, float gr, float b, float a) {
            if (a < 0.012f) return;
            float zs = Math.max(0.5f, Math.min(1.5f, 0.5f * (sx + sy))) * thickMul;
            float h = DEPTH * 0.5f;
            float ox = pvx + (pen - pvx) * sx;
            lPx = eOx + ox * eRx + base * eUx; lPy = eOy + ox * eRy + base * eUy; lPz = eOz + ox * eRz + base * eUz;
            lAx = sx * eRx; lAy = sx * eRy; lAz = sx * eRz;
            lBx = sy * (eUx - lean * eRx); lBy = sy * (eUy - lean * eRy); lBz = sy * (eUz - lean * eRz);
            lCx = zs * eNx; lCy = zs * eNy; lCz = zs * eNz;
            float cvx = g.adv * 0.5f, cvy = -7f;
            float cx = lPx + cvx * lAx + cvy * lBx, cy = lPy + cvx * lAy + cvy * lBy, cz = lPz + cvx * lAz + cvy * lBz;
            float rad = 22f * eS * Math.max(1f, Math.max(sx, sy)) + 0.5f;
            if (cz > rad) return;
            float depth = Math.max(0.01f, -cz);
            if (Math.abs(cx) - rad > depth * tanHX * 1.15f || Math.abs(cy) - rad > depth * tanHY * 1.15f) return;
            float[] t = g.tri;
            if (frontToYou || ghostMode) {
                float k = FRONT_AMB + FRONT_DIFF * Math.max(0f, lLz);
                float fr = r * k, fg = gr * k, fb = b * k;
                for (int i = 0; i < t.length; i += 2) { float gk = 0.975f + 0.045f * Math.max(-1f, Math.min(1f, (-7f - t[i + 1]) / 7.5f)); vtx(t[i], t[i + 1], h, fr * gk, fg * gk, fb * gk, a); }
            }
            float[] sg = g.seg;
            for (int i = 0; i < sg.length; i += 8) {
                float x0 = sg[i], y0 = sg[i + 1], x1 = sg[i + 2], y1 = sg[i + 3];
                float s0 = WALL_AMB + WALL_DIFF * Math.max(0f, sg[i + 4] * lLx + sg[i + 5] * lLy);
                float s1 = WALL_AMB + WALL_DIFF * Math.max(0f, sg[i + 6] * lLx + sg[i + 7] * lLy);
                vtx(x0, y0, h, r * s0, gr * s0, b * s0, a); vtx(x0, y0, -h, r * s0, gr * s0, b * s0, a); vtx(x1, y1, -h, r * s1, gr * s1, b * s1, a);
                vtx(x0, y0, h, r * s0, gr * s0, b * s0, a); vtx(x1, y1, -h, r * s1, gr * s1, b * s1, a); vtx(x1, y1, h, r * s1, gr * s1, b * s1, a);
            }
        }
    }

    // ------------------------------------------------------------------ AFTER: the real classes, with the same counting sink (every vertex counted twice like the game does)
    static final LyricMesh.Sink SINK = new LyricMesh.Sink() {
        public void begin() { }
        public void v(float x, float y, float z, float r, float g, float b, float a) {
            verts++; checksum += x + y + z + r + g + b + a;
            verts++; checksum += x + y + z;
        }
    };

    static void setup() {
        MeshFont.load();
        if (!MeshFont.ok) throw new IllegalStateException("put src/main/resources on the class path");
        glyphs = new MeshFont.Glyph[64]; pens = new float[64]; advs = new float[64]; n = 0;
        float cx = 0;
        for (char c : TEXT.toCharArray()) {
            if (c == ' ') { cx += 6f; continue; }
            MeshFont.Glyph g = MeshFont.get(c);
            glyphs[n] = g; pens[n] = cx; advs[n] = g.adv; n++; cx += g.adv + MeshFont.TRACK;
        }
        rowW = cx;
        double a = Math.toRadians(-20);
        eRx = (float) Math.cos(a) * eS; eRy = 0; eRz = (float) -Math.sin(a) * eS;
        eUx = 0; eUy = -eS; eUz = 0;
        eNx = (float) Math.sin(a) * eS; eNy = 0; eNz = (float) Math.cos(a) * eS;
    }

    static void frameOld(float time) {
        Old.animSecs = time;
        for (int c = 0; c < 3; c++) {
            float t = CHUNK_T[c] + time * 0f, dim = CHUNK_DIM[c];
            float rowY = (c - 1) * 30f;
            for (int i = 0; i < n; i++) {
                float onI = 0.30f + i * 0.075f;
                float p = smooth(clamp01((t - onI) / 0.5f));
                Old.letterMotion(i, n, t + time, onI, 0f, p, dim);
                float bi = clamp01(smooth(clamp01((t + time - onI + 0.10f) / 0.38f)) * (1f - 0.65f * dim));
                float x0 = -rowW / 2f, pen = x0 + pens[i], foot = pen + advs[i] * 0.5f;
                Old.meshGlyph(glyphs[i], pen, rowY + 6f + Old.mOff, foot, Old.mSx, Old.mSy, Old.mLean, 0.5f + 0.5f * bi, 0.5f + 0.5f * bi, 0.6f + 0.4f * bi, Old.mA);
            }
        }
    }

    static void frameNew(float time, boolean cull) {
        LyricMesh.cullWalls = cull;
        LyricMotion.frame(time);
        for (int c = 0; c < 3; c++) {
            float t = CHUNK_T[c] + time, dim = CHUNK_DIM[c];
            float rowY = (c - 1) * 30f;
            for (int i = 0; i < n; i++) {
                float onI = 0.30f + i * 0.075f;
                float p = smooth(clamp01((t - onI) / 0.5f));
                LyricMotion.letter(i, t, onI, 0f, p, dim);
                float bi = clamp01(LyricMotion.lit(t, onI) * (1f - 0.65f * dim));
                float x0 = -rowW / 2f, pen = x0 + pens[i], foot = pen + advs[i] * 0.5f;
                float shc = x0 + (rowW + 60f) * ((time / 5.5f) % 1f) - 30f;
                float shL = bi > 0.02f ? LyricMesh.sheen(pen, shc, 30f) * bi : 0f, shR = bi > 0.02f ? LyricMesh.sheen(pen + advs[i], shc, 30f) * bi : 0f;
                LyricMesh.glyph(glyphs[i], pen, rowY + 6f + LyricMotion.yoff, foot, LyricMotion.sx, LyricMotion.sy, LyricMotion.lean, LyricMotion.roll, LyricMotion.tilt, LyricMotion.zoff,
                        0.5f + 0.5f * bi, 0.5f + 0.5f * bi, 0.6f + 0.4f * bi, LyricMotion.alpha, LyricMotion.flash, shL, shR);
            }
        }
    }

    interface Frame { void run(float t); }

    static double bench(String name, Frame f) {
        for (int w = 0; w < 400; w++) f.run(1f + (w % 50) * 0.016f);                       // warm-up (JIT)
        double best = 1e18; long vv = 0;
        for (int rep = 0; rep < 30; rep++) {
            verts = 0;
            long t0 = System.nanoTime();
            for (int fr = 0; fr < 200; fr++) f.run(1f + (fr % 50) * 0.016f);
            double ms = (System.nanoTime() - t0) / 1e6 / 200.0;
            best = Math.min(best, ms); vv = verts / 200;
        }
        System.out.printf("%-34s %7.3f ms per frame   %6d vertex writes per frame (colour + depth pre-pass)%n", name, best, vv);
        return best;
    }

    public static void main(String[] a) {
        setup();
        LyricMesh.sink = SINK;
        LyricMesh.setSign(eOx, eOy, eOz, eRx, eRy, eRz, eUx, eUy, eUz, eNx, eNy, eNz, eS, true);
        LyricMesh.setLight(lLx, lLy, lLz);
        LyricMesh.ghost = false; LyricMesh.thickMul = 1f; LyricMesh.tanHX = tanHX; LyricMesh.tanHY = tanHY;
        System.out.println("scene: 3 lines x " + n + " letters, the first line mid-animation, camera 7 blocks away, sign turned 20 degrees\n");
        double before = bench("BEFORE (v15 letters)", t -> frameOld(t));
        double afterOff = bench("AFTER, wall culling off", t -> frameNew(t, false));
        double after = bench("AFTER (new motion + culling + sheen)", t -> frameNew(t, true));
        System.out.printf("%nletter building time: %.0f%% of before; checksum %.1f%n", 100.0 * after / before, checksum);
    }
}
