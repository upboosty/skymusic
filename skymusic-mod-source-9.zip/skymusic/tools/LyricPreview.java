package dev.skymusic;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Arrays;

/**
 * Offline software preview of the lyric text: runs the REAL LyricMotion / LyricMesh / MistTrail / MeshFont code and rasterises it the way the game
 * does (depth-only pre-pass, then colour pass with depth test LEQUAL and no depth writes, then the mist with alpha blending and the glow / sparkles
 * additive), in front of a plain sky. Dev tool only, it is not part of the mod jar.
 *
 *   javac -d /tmp/lp src/main/java/dev/skymusic/{MistTrail,MeshFont,LyricMotion,LyricMesh}.java tools/LyricPreview.java
 *   java -Djava.awt.headless=true -cp /tmp/lp:src/main/resources dev.skymusic.LyricPreview out_dir [-Dkey=value ...]
 *
 * Options (all -D): times=0.4,0.8,1.2  yaw=-20  dist=8  sky=0.10 (0.1 night .. 0.9 day)  light=0.6 (sun / moon strength)  env=0.8 (light at the sign)
 *                   text="Hold me closer|tiny dancer"  fx=1 (mist, glow, sparkles on)  q=2 (quality step)  crop=1 (crop around the text)
 *                   check=1 (compare culled / unculled renders)  bench=1 (time the letter builder)  name=sheet
 */
public final class LyricPreview {
    static int W = 1280, H = 720;
    static float fy;
    static float[] zbuf, img;
    static BufferedImage texW, texP, texG, texS;

    static String prop(String k, String d) { String v = System.getProperty(k); return v == null ? d : v; }
    static float fprop(String k, float d) { return Float.parseFloat(prop(k, String.valueOf(d))); }

    // ------------------------------------------------------------------ rasteriser
    static final int DEPTH = 0, COLOR = 1, TEX_ALPHA = 2, TEX_ADD = 3;

    static float[] sample(BufferedImage t, float u, float v) {
        int tw = t.getWidth(), th = t.getHeight();
        float x = u * tw - 0.5f, y = v * th - 0.5f;
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y);
        float fx = x - x0, fyy = y - y0;
        float[] o = new float[4];
        for (int j = 0; j < 2; j++)
            for (int i = 0; i < 2; i++) {
                int xx = Math.floorMod(x0 + i, tw), yy = Math.floorMod(y0 + j, th);
                int p = t.getRGB(xx, yy);
                float wgt = (i == 0 ? 1 - fx : fx) * (j == 0 ? 1 - fyy : fyy);
                o[0] += ((p >> 16) & 255) / 255f * wgt; o[1] += ((p >> 8) & 255) / 255f * wgt;
                o[2] += (p & 255) / 255f * wgt; o[3] += ((p >>> 24) & 255) / 255f * wgt;
            }
        return o;
    }

    /** one triangle of vertices at float offsets a, b, c of d: position at +0..2, uv at uvO.., colour (r g b a) at colO.. */
    static void tri(float[] d, int a, int b, int c, int uvO, int colO, int mode, BufferedImage tex) {
        int[] ix = {a, b, c};
        float[] sx = new float[3], sy = new float[3], iw = new float[3];
        for (int i = 0; i < 3; i++) {
            float w = -d[ix[i] + 2];
            if (w < 0.05f) return;
            iw[i] = 1f / w;
            sx[i] = W / 2f + d[ix[i]] * iw[i] * fy;
            sy[i] = H / 2f - d[ix[i] + 1] * iw[i] * fy;
        }
        float area = (sx[1] - sx[0]) * (sy[2] - sy[0]) - (sx[2] - sx[0]) * (sy[1] - sy[0]);
        if (Math.abs(area) < 1e-9f) return;
        int minX = Math.max(0, (int) Math.floor(Math.min(sx[0], Math.min(sx[1], sx[2])))), maxX = Math.min(W - 1, (int) Math.ceil(Math.max(sx[0], Math.max(sx[1], sx[2]))));
        int minY = Math.max(0, (int) Math.floor(Math.min(sy[0], Math.min(sy[1], sy[2])))), maxY = Math.min(H - 1, (int) Math.ceil(Math.max(sy[0], Math.max(sy[1], sy[2]))));
        for (int y = minY; y <= maxY; y++)
            for (int x = minX; x <= maxX; x++) {
                float px = x + 0.5f, py = y + 0.5f;
                float w0 = ((sx[1] - px) * (sy[2] - py) - (sx[2] - px) * (sy[1] - py)) / area;
                float w1 = ((sx[2] - px) * (sy[0] - py) - (sx[0] - px) * (sy[2] - py)) / area;
                float w2 = 1f - w0 - w1;
                if (w0 < 0 || w1 < 0 || w2 < 0) continue;
                float ipw = w0 * iw[0] + w1 * iw[1] + w2 * iw[2];
                float depth = 1f / ipw;
                int idx = y * W + x;
                if (mode == DEPTH) { if (depth <= zbuf[idx]) zbuf[idx] = depth; continue; }
                if (depth > zbuf[idx]) continue;                                               // LEQUAL depth test (exact: the colour pass computes the very same depth as the pre-pass), no depth writes
                float pw0 = w0 * iw[0] / ipw, pw1 = w1 * iw[1] / ipw, pw2 = w2 * iw[2] / ipw;
                float rr = pw0 * d[a + colO] + pw1 * d[b + colO] + pw2 * d[c + colO];
                float gg = pw0 * d[a + colO + 1] + pw1 * d[b + colO + 1] + pw2 * d[c + colO + 1];
                float bb = pw0 * d[a + colO + 2] + pw1 * d[b + colO + 2] + pw2 * d[c + colO + 2];
                float aa = pw0 * d[a + colO + 3] + pw1 * d[b + colO + 3] + pw2 * d[c + colO + 3];
                if (tex != null) {
                    float u = pw0 * d[a + uvO] + pw1 * d[b + uvO] + pw2 * d[c + uvO], v = pw0 * d[a + uvO + 1] + pw1 * d[b + uvO + 1] + pw2 * d[c + uvO + 1];
                    float[] t = sample(tex, u, v);
                    rr *= t[0]; gg *= t[1]; bb *= t[2]; aa *= t[3];
                }
                if (mode == TEX_ADD) {                                                         // rgb carries the brightness
                    img[idx * 3] += rr; img[idx * 3 + 1] += gg; img[idx * 3 + 2] += bb;
                } else {
                    img[idx * 3] = img[idx * 3] * (1 - aa) + rr * aa;
                    img[idx * 3 + 1] = img[idx * 3 + 1] * (1 - aa) + gg * aa;
                    img[idx * 3 + 2] = img[idx * 3 + 2] * (1 - aa) + bb * aa;
                }
            }
    }

    static void drawQuads(MistTrail.Mesh m, int mode, BufferedImage tex) {
        for (int q = 0; q + 3 < m.n; q += 4) {
            int a = q * 9, b = (q + 1) * 9, c = (q + 2) * 9, e = (q + 3) * 9;
            tri(m.d, a, b, c, 3, 5, mode, tex);
            tri(m.d, a, c, e, 3, 5, mode, tex);
        }
    }

    // ------------------------------------------------------------------ the letters (collected through the real sink)
    static float[] V = new float[7 * 3 * 8192];
    static int nV = 0;
    static float maxC = 0f, minC = 1f;                        // the game's vertex buffers store bytes: every colour must stay within 0..1
    static final LyricMesh.Sink SINK = new LyricMesh.Sink() {
        public void begin() { }
        public void v(float x, float y, float z, float r, float g, float b, float a) {
            maxC = Math.max(maxC, Math.max(r, Math.max(g, Math.max(b, a)))); minC = Math.min(minC, Math.min(r, Math.min(g, Math.min(b, a))));
            int o = nV * 7;
            if (o + 7 > V.length) V = Arrays.copyOf(V, V.length * 2);
            V[o] = x; V[o + 1] = y; V[o + 2] = z; V[o + 3] = r; V[o + 4] = g; V[o + 5] = b; V[o + 6] = a;
            nV++;
        }
    };

    static float clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }
    static float lerp(float a, float b, float f) { return a + (b - a) * f; }

    // layout of the text: one entry per letter
    static int[] lRow, lWord, lGi; static float[] lPen, lAdv; static int nLet = 0;
    static float[] rowW = new float[8]; static int rows = 0;
    static final float SPACE_W = 6f, ROW_GAP = 26f, BASE = 6f;

    static void layout(String text) {
        String[] rs = text.split("\\|");
        rows = rs.length;
        int cap = 512;
        lRow = new int[cap]; lWord = new int[cap]; lGi = new int[cap]; lPen = new float[cap]; lAdv = new float[cap];
        nLet = 0;
        int gi = 0, word = 0;
        for (int r = 0; r < rows; r++) {
            float cx = 0; boolean first = true;
            for (String w : rs[r].trim().split("\\s+")) {
                if (!first) cx += SPACE_W;
                first = false;
                for (int k = 0; k < w.length(); k++) {
                    MeshFont.Glyph g = MeshFont.get(w.charAt(k));
                    if (g == null) continue;
                    lRow[nLet] = r; lWord[nLet] = word; lGi[nLet] = gi++; lPen[nLet] = cx; lAdv[nLet] = g.adv; nLet++;
                    cx += g.adv + MeshFont.TRACK;
                }
                word++;
            }
            rowW[r] = cx;
        }
    }

    static float onsetOf(int i) { return 0.30f + lGi[i] * 0.075f + lWord[i] * 0.10f; }

    // ------------------------------------------------------------------ one frame
    static int statTris;

    /** renders one frame of the line at time t (seconds since the line was born) into img; returns the number of letter triangles */
    static int renderFrame(float t, boolean cull, boolean fx, int quality, float yawDeg, float dist, float sky, float light, float env, float leaveT) {
        Arrays.fill(zbuf, Float.MAX_VALUE);
        for (int i = 0; i < W * H; i++) { float g = sky * (0.55f + 0.45f * (1f - (i / W) / (float) H)); img[i * 3] = g * 0.55f; img[i * 3 + 1] = g * 0.72f; img[i * 3 + 2] = g; }

        final float s = 0.034f;
        double a = Math.toRadians(yawDeg);
        float rx = (float) Math.cos(a) * s, ry = 0, rz = (float) -Math.sin(a) * s;            // right / down / toward-you, one layout px long, eye space
        float dx = 0, dy = -s, dz = 0;
        float nx = (float) Math.sin(a) * s, ny = 0, nz = (float) Math.cos(a) * s;
        float ox = fprop("ox", 0f), oy = fprop("oy", 0.1f), oz = -dist;
        boolean front = nx * -ox + ny * -oy + nz * -oz > 0f;
        LyricMesh.setSign(ox, oy, oz, rx, ry, rz, dx, dy, dz, nx, ny, nz, s, front);
        // light of the sun / moon in the sign's own axes (upper left, a little toward the viewer)
        LyricMesh.setLight(-0.55f * light, -0.45f * light, 0.70f * light);
        LyricMesh.ghost = false; LyricMesh.thickMul = Math.max(1f, Math.min(6f, 0.07f / (LyricMesh.DEPTH * s)));
        LyricMesh.tanHX = (float) (W / 2f / fy); LyricMesh.tanHY = (float) (H / 2f / fy);
        LyricMesh.cullWalls = cull;
        LyricMesh.wallsDrawn = 0; LyricMesh.wallsCulled = 0;
        LyricMotion.frame(t + 3.7);
        nV = 0;

        float dimK = 0f;
        float sweep = onsetOf(nLet - 1) + 0.3f;
        int tris = 0;
        float[] front0 = new float[rows];
        Arrays.fill(front0, -1e9f);
        float[] rowRev = new float[rows];
        float[] rowPulse = new float[rows];
        for (int i = 0; i < nLet; i++) {
            float onI = onsetOf(i);
            float tIn = t;
            float sl = clamp01((leaveT < 0 ? -1f : (t - leaveT) - lGi[i] * 0.035f) / 0.7f);
            sl = sl * sl * (3f - 2f * sl);
            float p = clamp01((tIn - onI) / 0.5f); p = p * p * (3f - 2f * p);
            LyricMotion.letter(lGi[i], tIn, onI, sl, p, dimK);
            float bi = clamp01(LyricMotion.lit(tIn, onI) * (1f - 0.65f * dimK));
            float emi = 0.35f * bi;
            float eri = lerp(env, 1f, emi), egi = lerp(env, 1f, emi), ebi = lerp(env, 1f, emi);
            float mr = lerp(0.52f, 1f, bi) * eri, mg = lerp(0.60f, 1f, bi) * egi, mb = lerp(0.76f, 1f, bi) * ebi;
            float x0 = -rowW[lRow[i]] / 2f;
            float pen = x0 + lPen[i], foot = pen + lAdv[i] * 0.5f, rowY = (lRow[i] - (rows - 1) / 2f) * ROW_GAP;
            float base = rowY + BASE + LyricMotion.yoff;
            float shL = 0f, shR = 0f;
            if (quality >= 2) {
                float shW = 30f, shc = x0 + (rowW[lRow[i]] + 2 * shW) * ((t / 5.5f + lRow[i] * 0.37f) % 1f) - shW;
                shL = LyricMesh.sheen(pen, shc, shW) * bi; shR = LyricMesh.sheen(pen + lAdv[i], shc, shW) * bi;
            }
            float lineA = 1f;
            float wordA = lineA * (1f - 0.5f * sl);
            MeshFont.Glyph g = glyphAt(i);
            tris += LyricMesh.glyph(g, pen, base, foot, LyricMotion.sx, LyricMotion.sy, LyricMotion.lean, LyricMotion.roll, LyricMotion.tilt, LyricMotion.zoff,
                    mr, mg, mb, wordA * LyricMotion.alpha, LyricMotion.flash, shL, shR);
            // row bookkeeping for the glow
            int r = lRow[i];
            front0[r] = Math.max(front0[r], pen + lAdv[i] * LyricMotion.lit(tIn, onI));
            rowRev[r] = Math.max(rowRev[r], LyricMotion.lit(tIn, onI));
            rowPulse[r] = Math.max(rowPulse[r], LyricMotion.bloom);
        }
        statTris = tris;

        // letters: depth pre-pass, then colour pass
        for (int i = 0; i + 2 < nV; i += 3) tri(V, i * 7, (i + 1) * 7, (i + 2) * 7, -1, 3, DEPTH, null);
        for (int i = 0; i + 2 < nV; i += 3) tri(V, i * 7, (i + 1) * 7, (i + 2) * 7, -1, 3, COLOR, null);

        if (fx) {
            MistTrail.Mesh wisp = new MistTrail.Mesh(), puff = new MistTrail.Mesh(), glow = new MistTrail.Mesh(), spark = new MistTrail.Mesh();
            float tr = lerp(env, 1f, 0.45f);
            float fr = lerp(env, 1f, 0.70f);
            MistTrail.Look look = new MistTrail.Look();
            look.opacity = 0.70f; look.layers = 4; look.puffs = true;                  // like the game: 3 wisps per row at the top step (trailLayers = 3), 2 at step 1, 1 at step 0
            look.layerMul = new float[]{1f, quality >= 1 ? 1f : 0f, quality >= 2 ? 1f : 0f, 0f};
            look.puffMul = quality >= 1 ? 1f : 0f;
            for (int r = 0; r < rows; r++) {
                float rowY = (r - (rows - 1) / 2f) * ROW_GAP;
                float x0 = -rowW[r] / 2f;
                float enter = clamp01(t / 0.55f); enter = enter * enter * (3f - 2f * enter);
                float fade = enter * (1f + 0.15f * rowPulse[r]);
                if (quality >= 1)
                    MistTrail.addGlow(glow, ox, oy, oz, rx, ry, rz, dx, dy, dz, nx, ny, nz, x0 - 2f, front0[r] + 2f, rowY, ROW_GAP,
                            0.20f * fprop("glow", 0.5f) * 2f * enter * clamp01(rowRev[r] * 3f), fr * 0.80f, fr * 0.88f, fr);
                if (!"0".equals(prop("mist", "1")))
                MistTrail.addRow(wisp, puff, look, ox, oy, oz, rx, ry, rz, dx, dy, dz, nx, ny, nz, rowW[r] * 0.5f + 6f, rowY, ROW_GAP, t + 11f, 977 * 3 + 13 + r * 31, fade, 1f, tr, tr, tr);
            }
            if (quality >= 1)
                for (int i = 0; i < nLet; i++) {
                    float onI = onsetOf(i), ts = t - onI;
                    if (ts <= 0f || ts > 1.5f) continue;
                    LyricMotion.letter(lGi[i], t, onI, 0f, 1f, 0f);
                    float x0 = -rowW[lRow[i]] / 2f, foot = x0 + lPen[i] + lAdv[i] * 0.5f, rowY = (lRow[i] - (rows - 1) / 2f) * ROW_GAP;
                    MistTrail.addLetterFx(glow, spark, ox, oy, oz, rx, ry, rz, dx, dy, dz, nx, ny, nz, foot, rowY + BASE + LyricMotion.yoff - 7f,
                            LyricMotion.bloom, ts, lGi[i] * 7 + 1, quality >= 2 ? 4 : 2, fprop("glow", 0.5f), 1f,
                            fr * 0.80f, fr * 0.88f, fr, fr, fr * 0.95f, fr * 0.82f);
                }
            drawQuads(wisp, TEX_ALPHA, texW);
            drawQuads(puff, TEX_ALPHA, texP);
            drawQuads(glow, TEX_ADD, texG);
            drawQuads(spark, TEX_ADD, texS);
            statTris += 0;
        }
        return tris;
    }

    static MeshFont.Glyph glyphAt(int i) {
        // recover the glyph of letter i from the text (layout() skipped letters without a glyph, so keep our own list)
        return glyphs[i];
    }
    static MeshFont.Glyph[] glyphs = new MeshFont.Glyph[512];

    static BufferedImage toImage() { return toImage(img); }

    static BufferedImage toImage(float[] data) {
        BufferedImage fr = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        for (int i = 0; i < W * H; i++) {
            float r = data[i * 3], g = data[i * 3 + 1], b = data[i * 3 + 2];
            // a touch of filmic roll-off so additive light does not just clip
            int rr = Math.max(0, Math.min(255, (int) (r * 255))), gg = Math.max(0, Math.min(255, (int) (g * 255))), bb = Math.max(0, Math.min(255, (int) (b * 255)));
            fr.setRGB(i % W, i / W, (rr << 16) | (gg << 8) | bb);
        }
        return fr;
    }

    public static void main(String[] args) throws Exception {
        File dir = new File(args[0]);
        dir.mkdirs();
        File texDir = new File(prop("tex", "src/main/resources/assets/skymusic/textures/mist"));
        texW = ImageIO.read(new File(texDir, "wisp.png")); texP = ImageIO.read(new File(texDir, "puff.png"));
        texG = ImageIO.read(new File(texDir, "glow.png")); texS = ImageIO.read(new File(texDir, "spark.png"));
        MeshFont.load();
        if (!MeshFont.ok) throw new IllegalStateException("text3d.bin not found: put src/main/resources on the class path");
        String text = prop("text", "Hold me closer|tiny dancer");
        layout(text);
        // glyph list in the same order as the letters
        {
            int n = 0;
            for (String r : text.split("\\|")) for (String w : r.trim().split("\\s+")) for (int k = 0; k < w.length(); k++) { MeshFont.Glyph g = MeshFont.get(w.charAt(k)); if (g != null) glyphs[n++] = g; }
        }
        fy = (H / 2f) / (float) Math.tan(Math.toRadians(35));
        zbuf = new float[W * H]; img = new float[W * H * 3];
        LyricMesh.sink = SINK;
        float yaw = fprop("yaw", -20f), dist = fprop("dist", 8f), sky = fprop("sky", 0.10f), light = fprop("light", 0.6f), env = fprop("env", 0.8f);
        boolean fx = !"0".equals(prop("fx", "1"));
        int q = (int) fprop("q", 2f);
        float leave = fprop("leave", -1f);
        String[] ts = prop("times", "0.35,0.6,0.9,1.3,1.8,2.6").split(",");
        String name = prop("name", "sheet");

        if ("1".equals(prop("check", "0"))) {                          // the wall culling must not change a single pixel
            long worst = 0; int maxd = 0;
            for (String tt : ts) {
                float t = Float.parseFloat(tt);
                renderFrame(t, true, false, q, yaw, dist, sky, light, env, leave);
                float[] a = img.clone(); int trisA = statTris; int dA = LyricMesh.wallsDrawn, cA = LyricMesh.wallsCulled;
                renderFrame(t, false, false, q, yaw, dist, sky, light, env, leave);
                int trisB = statTris;
                int diff = 0, md = 0, mdPix = -1;
                for (int i = 0; i < a.length; i++) {
                    int d = Math.abs(Math.round(a[i] * 255) - Math.round(img[i] * 255));
                    if (d > 0) diff++;
                    if (d > md) { md = d; mdPix = i / 3; }
                }
                if (md > 0 && "1".equals(prop("dump", "0"))) {                 // where is the worst pixel? write both renders around it, enlarged
                    int px = mdPix % W, py = mdPix / W;
                    System.out.println("   worst differing pixel at (" + px + ", " + py + ")");
                    int x0 = Math.max(0, Math.min(W - 40, px - 20)), y0 = Math.max(0, Math.min(H - 40, py - 20));
                    BufferedImage ia = toImage(a).getSubimage(x0, y0, 40, 40), ib = toImage(img).getSubimage(x0, y0, 40, 40);
                    BufferedImage both = new BufferedImage(40 * 8 * 2 + 8, 40 * 8, BufferedImage.TYPE_INT_RGB);
                    both.getGraphics().drawImage(ia.getScaledInstance(320, 320, java.awt.Image.SCALE_REPLICATE), 0, 0, null);
                    both.getGraphics().drawImage(ib.getScaledInstance(320, 320, java.awt.Image.SCALE_REPLICATE), 328, 0, null);
                    ImageIO.write(both, "png", new File(dir, "diff_" + tt + ".png"));
                }
                System.out.printf("t=%.2f  triangles culled-on %d / off %d (%.0f%% fewer)  walls drawn %d culled %d  pixels differing %d (max %d/255)%n",
                        t, trisA, trisB, 100.0 * (trisB - trisA) / Math.max(1, trisB), dA, cA, diff, md);
                worst += diff; maxd = Math.max(maxd, md);
            }
            System.out.println("TOTAL differing channel values: " + worst + ", max difference " + maxd + "/255");
            System.out.println("vertex colour range seen: " + minC + " .. " + maxC + (maxC <= 1f && minC >= 0f ? "  (ok)" : "  (OUT OF RANGE!)"));
            return;
        }
        if ("1".equals(prop("bench", "0"))) {
            final long[] cnt = {0};
            LyricMesh.sink = new LyricMesh.Sink() { public void begin() { } public void v(float x, float y, float z, float r, float g, float b, float a) { cnt[0]++; } };
            for (int mode = 0; mode < 2; mode++) {
                boolean cull = mode == 0;
                long best = Long.MAX_VALUE; long verts = 0;
                for (int rep = 0; rep < 60; rep++) {
                    cnt[0] = 0;
                    long t0 = System.nanoTime();
                    for (int fr = 0; fr < 20; fr++) renderFrameGeometryOnly(1.2f + fr * 0.016f, cull, yaw, dist);
                    long dt = System.nanoTime() - t0;
                    if (rep >= 20) best = Math.min(best, dt);
                    verts = cnt[0] / 20;
                }
                System.out.printf("cull=%s: %.3f ms per frame for %d letters (best of 40 runs), %d vertices per frame%n", cull, best / 20.0 / 1e6, nLet, verts);
            }
            return;
        }

        int cols = (int) fprop("cols", 3f), rowsN = (ts.length + cols - 1) / cols;
        int CW = Integer.parseInt(prop("cw", "640")), CH = Integer.parseInt(prop("ch", "250"));
        BufferedImage sheet = new BufferedImage(CW * cols, CH * rowsN, BufferedImage.TYPE_INT_RGB);
        for (int ti = 0; ti < ts.length; ti++) {
            float t = Float.parseFloat(ts[ti]);
            int tris = renderFrame(t, true, fx, q, yaw, dist, sky, light, env, leave);
            BufferedImage fr = toImage();
            float ox = fprop("ox", 0f), oy = fprop("oy", 0.1f);
            int cxs = Math.round(W / 2f + ox / dist * fy), cys = Math.round(H / 2f - oy / dist * fy);
            int zoom = (int) fprop("zoom", 1f);
            BufferedImage crop = fr.getSubimage(Math.max(0, cxs - CW / 2 / zoom), Math.max(0, cys - CH / 2 / zoom), CW / zoom, CH / zoom);
            sheet.getGraphics().drawImage(crop.getScaledInstance(CW, CH, java.awt.Image.SCALE_SMOOTH), (ti % cols) * CW, (ti / cols) * CH, null);
            System.out.printf("t=%.2f  letter triangles %d  (walls drawn %d, culled %d)%n", t, tris, LyricMesh.wallsDrawn, LyricMesh.wallsCulled);
        }
        ImageIO.write(sheet, "png", new File(dir, name + ".png"));
    }

    /** only the letter geometry (no rasterising): for the benchmark */
    static void renderFrameGeometryOnly(float t, boolean cull, float yawDeg, float dist) {
        final float s = 0.034f;
        double a = Math.toRadians(yawDeg);
        float rx = (float) Math.cos(a) * s, rz = (float) -Math.sin(a) * s, nx = (float) Math.sin(a) * s, nz = (float) Math.cos(a) * s;
        LyricMesh.setSign(0f, 0.1f, -dist, rx, 0, rz, 0, -s, 0, nx, 0, nz, s, true);
        LyricMesh.setLight(-0.33f, -0.27f, 0.42f);
        LyricMesh.ghost = false; LyricMesh.thickMul = 1f; LyricMesh.tanHX = 1.78f; LyricMesh.tanHY = 0.70f; LyricMesh.cullWalls = cull;
        LyricMotion.frame(t);
        for (int i = 0; i < nLet; i++) {
            float onI = onsetOf(i);
            LyricMotion.letter(lGi[i], t, onI, 0f, 1f, 0f);
            float x0 = -rowW[lRow[i]] / 2f, pen = x0 + lPen[i], foot = pen + lAdv[i] * 0.5f, rowY = (lRow[i] - (rows - 1) / 2f) * ROW_GAP;
            LyricMesh.glyph(glyphs[i], pen, rowY + BASE + LyricMotion.yoff, foot, LyricMotion.sx, LyricMotion.sy, LyricMotion.lean, LyricMotion.roll, LyricMotion.tilt, LyricMotion.zoff,
                    1f, 1f, 1f, 1f, LyricMotion.flash, 0f, 0f);
        }
    }
}
