#!/usr/bin/env python3
"""Generates the sky textures (moon, star sprite, aurora curtain) used by CustomSky.
Run: python3 tools/gen_textures.py   (needs numpy + Pillow). Output: src/main/resources/assets/skymusic/textures/sky/"""
import os
import numpy as np
from PIL import Image

OUT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "skymusic", "textures", "sky")
os.makedirs(OUT, exist_ok=True)

def smooth(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)

# ------------------------------------------------------------------ moon
def value_noise(n, cells, rng):
    g = rng.random((cells + 1, cells + 1)).astype(np.float32)
    im = Image.fromarray(g, mode="F").resize((n, n), Image.BICUBIC)
    return np.asarray(im)

def fbm(n, octs, seed, base=4, pers=0.5):
    rng = np.random.default_rng(seed)
    tot = np.zeros((n, n), np.float32); amp = 1.0; norm = 0.0
    for o in range(octs):
        tot += amp * value_noise(n, base * 2 ** o, rng); norm += amp; amp *= pers
    return tot / norm

def make_moon(size=256, ss=4):
    N = size * ss
    yy, xx = np.mgrid[0:N, 0:N].astype(np.float32)
    x = (xx + 0.5) / N * 2 - 1
    y = 1 - (yy + 0.5) / N * 2
    r = np.hypot(x, y)
    xw = x + (fbm(N, 4, 11) - 0.5) * 0.10
    yw = y + (fbm(N, 4, 12) - 0.5) * 0.10

    alb = 0.72 + (fbm(N, 5, 13) - 0.5) * 0.14 + (fbm(N, 3, 17) - 0.5) * 0.10   # bright, slightly blotchy highlands
    maria = [  # cx, cy, rx, ry, rot, strength  (approximate real near side, north up)
        (-0.30, 0.42, 0.30, 0.26, 0.3, 1.00), (0.10, 0.45, 0.16, 0.16, 0.0, 0.95),
        (0.30, 0.17, 0.24, 0.16, 0.5, 0.95), (0.66, 0.40, 0.11, 0.08, 0.2, 1.00),
        (0.58, -0.10, 0.16, 0.10, -0.9, 0.85), (0.36, -0.17, 0.08, 0.08, 0.0, 0.80),
        (-0.62, 0.02, 0.28, 0.46, 0.15, 0.95), (-0.22, -0.40, 0.20, 0.15, 0.2, 0.85),
        (-0.52, -0.40, 0.09, 0.09, 0.0, 0.90), (-0.05, 0.80, 0.42, 0.06, -0.1, 0.70),
        (0.06, 0.18, 0.08, 0.07, 0.0, 0.80), (-0.35, -0.05, 0.16, 0.13, 0.0, 0.85),
    ]
    M = np.zeros_like(x)
    for cx, cy, rx, ry, rot, st in maria:
        c, s = np.cos(rot), np.sin(rot)
        dx, dy = xw - cx, yw - cy
        u = (dx * c + dy * s) / rx; v = (-dx * s + dy * c) / ry
        M = np.maximum(M, st * (1 - smooth(0.78, 1.12, np.sqrt(u * u + v * v))))
    M = np.clip(M * (0.80 + 0.40 * fbm(N, 4, 14, 3)), 0, 1)
    mare_col = 0.34 + 0.07 * fbm(N, 5, 15)
    b = alb * (1 - M) + mare_col * M
    b += (fbm(N, 7, 16, 16, 0.6) - 0.5) * 0.05           # fine grain

    rng = np.random.default_rng(99)
    def crater(cx, cy, rc, strength=1.0, dark_floor=0.0):
        px, py = int((cx + 1) / 2 * N), int((1 - cy) / 2 * N)
        w = int(rc / 2 * N * 1.9) + 2
        x0, x1, y0, y1 = max(px - w, 0), min(px + w, N), max(py - w, 0), min(py + w, N)
        if x0 >= x1 or y0 >= y1: return
        d = np.hypot(x[y0:y1, x0:x1] - cx, y[y0:y1, x0:x1] - cy) / rc
        rim = 0.055 * np.exp(-((d - 1.0) / 0.26) ** 2)
        ejecta = 0.030 * np.exp(-((d - 1.5) / 0.6) ** 2) * (d > 1.0)
        floor = -(0.018 + dark_floor) * (1 - smooth(0.6, 1.0, d))
        b[y0:y1, x0:x1] += strength * (rim + ejecta + floor)
    for _ in range(1600):
        a = rng.random() * 2 * np.pi; rr = np.sqrt(rng.random()) * 0.97
        rc = 0.006 + 0.045 * rng.random() ** 3.2
        crater(rr * np.cos(a), rr * np.sin(a), rc, 0.35 + 0.5 * rng.random())
    # famous ones
    crater(-0.23, 0.18, 0.042, 1.7)    # Copernicus
    crater(-0.58, 0.22, 0.030, 1.7)    # Kepler
    crater(-0.60, 0.34, 0.028, 2.6)    # Aristarchus (very bright)
    crater(-0.08, 0.78, 0.075, 0.5, 0.20)   # Plato (dark floor)
    crater(-0.85, -0.02, 0.065, 0.5, 0.16)  # Grimaldi
    crater(0.46, 0.22, 0.020, 2.0)     # Proclus
    crater(-0.12, -0.80, 0.040, 2.2)   # Tycho
    # rays from Tycho and Copernicus
    for (cx, cy, nr, amp, decay) in [(-0.12, -0.80, 30, 0.13, 2.3), (-0.23, 0.18, 12, 0.05, 3.6)]:
        ang = np.arctan2(y - cy, x - cx); dist = np.hypot(x - cx, y - cy)
        phase = rng.random(nr) * 2 * np.pi; wid = 7 + rng.random(nr) * 16
        rays = np.zeros_like(x)
        for k in range(nr):
            th = rng.random() * 2 * np.pi
            da = np.angle(np.exp(1j * (ang - th)))
            rays = np.maximum(rays, np.exp(-(da * wid[k]) ** 2) * (0.4 + 0.6 * rng.random()))
        b += amp * rays * np.exp(-dist * decay) * (dist > 0.04)

    b *= 1.0 - 0.14 * smooth(0.55, 1.0, r) ** 1.4         # gentle limb darkening
    b = np.clip(b, 0.10, 1.0)
    b = b / np.percentile(b[r < 0.95], 99.7) * 0.97
    b = np.clip(b, 0, 1)
    a = np.clip((1.0 - r) / 0.012, 0, 1)                   # anti-aliased disc edge
    rgb = np.stack([b * 1.0, b * 0.988, b * 0.97], -1) * a[..., None]   # premultiplied
    rgba = np.concatenate([rgb, a[..., None]], -1)
    rgba = rgba.reshape(size, ss, size, ss, 4).mean(axis=(1, 3))
    Image.fromarray((np.clip(rgba, 0, 1) * 255 + 0.5).astype(np.uint8), "RGBA").save(os.path.join(OUT, "moon.png"))

# ------------------------------------------------------------------ star sprite
def make_star(size=64):
    g = (np.arange(size) + 0.5) / size * 2 - 1
    x, y = np.meshgrid(g, g)
    r = np.hypot(x, y)
    i = (np.exp(-(r / 0.20) ** 2) + 0.20 * np.exp(-(r / 0.50) ** 2)) * (1 - smooth(0.55, 1.0, r))
    i = np.clip(i, 0, 1)
    rgba = np.stack([i, i, i, np.ones_like(i)], -1)
    Image.fromarray((rgba * 255 + 0.5).astype(np.uint8), "RGBA").save(os.path.join(OUT, "star.png"))

# ------------------------------------------------------------------ aurora curtain (tiles horizontally)
def pnoise(W, cells, seed):
    rng = np.random.default_rng(seed); g = rng.random(cells)
    xs = np.arange(W) / W * cells; i0 = np.floor(xs).astype(int) % cells; i1 = (i0 + 1) % cells
    f = xs - np.floor(xs); f = f * f * (3 - 2 * f)
    return g[i0] * (1 - f) + g[i1] * f

def pfbm(W, cells, octs, seed, pers=0.55):
    t = np.zeros(W); a = 1.0; n = 0.0
    for o in range(octs):
        t += a * pnoise(W, cells * 2 ** o, seed + o * 17); n += a; a *= pers
    return t / n

def norm01(v): return (v - v.min()) / (v.max() - v.min())

def make_aurora(W=1024, H=256):
    ray = norm01(0.55 * pfbm(W, 22, 4, 1) + 0.45 * pfbm(W, 90, 3, 2))
    ray = 0.20 + 0.80 * np.clip((ray - 0.22) / 0.78, 0, 1) ** 1.3
    length = 0.55 + 0.45 * norm01(pfbm(W, 16, 3, 3))
    hue = norm01(pfbm(W, 10, 2, 4))
    h = 1 - (np.arange(H) + 0.5) / H                      # row 0 = top of the curtain, last row = bright lower edge
    hh = h[:, None]; L = length[None, :]; R = ray[None, :]
    bot = smooth(0.0, 0.035, hh)
    tip = 1 - smooth(0.55 * L, L, hh)
    inten = R * bot * np.exp(-1.7 * hh / L) * tip
    inten = inten + 0.30 * bot * np.exp(-hh / 0.07) * (0.4 + 0.6 * R)   # continuous bright lower edge
    cols = np.array([[0.62, 1.00, 0.66], [0.20, 0.97, 0.45], [0.10, 0.72, 0.58], [0.30, 0.36, 0.88]])
    pos = np.array([0.0, 0.22, 0.62, 1.0])
    def col(c): return np.interp(h, pos, cols[:, c])
    base = np.stack([col(0)[:, None] + 0 * R, col(1)[:, None] + 0 * R, col(2)[:, None] + 0 * R], -1)
    shift = (hue[None, :, None] - 0.5) * 0.22
    base = base + np.concatenate([shift * 0.4, -shift * 0.3, shift * 0.8], -1)
    img = np.clip(base, 0, 1) * inten[..., None]
    # faint wide glow under the rays
    soft = np.convolve(np.r_[ray[-12:], ray, ray[:12]], np.ones(25) / 25, mode="valid")
    img += np.stack([0.15 * np.ones_like(hh), 0.55 * np.ones_like(hh), 0.30 * np.ones_like(hh)], -1)[:, :1, :] * \
           (0.10 * np.exp(-3.0 * hh) * soft[None, :])[..., None]
    # tiny horizontal blur so single rays do not alias
    k = img.copy(); img = 0.25 * np.roll(k, 1, 1) + 0.5 * k + 0.25 * np.roll(k, -1, 1)
    img = np.clip(img / img.max(), 0, 1)
    rgba = np.concatenate([img, np.ones((H, W, 1))], -1)
    Image.fromarray((rgba * 255 + 0.5).astype(np.uint8), "RGBA").save(os.path.join(OUT, "aurora.png"))

if __name__ == "__main__":
    make_moon(); make_star(); make_aurora()
    for n in ("moon", "star", "aurora"):
        with open(os.path.join(OUT, n + ".png.mcmeta"), "w") as f:
            f.write('{"texture":{"blur":true,"clamp":%s}}\n' % ("false" if n == "aurora" else "true"))
    print("ok", os.listdir(OUT))
