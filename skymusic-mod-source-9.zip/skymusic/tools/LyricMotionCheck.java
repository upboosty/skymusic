package dev.skymusic;

import java.util.Random;

/**
 * Numerical checks of the lyric motion and of the glow / sparkle geometry (dev tool, not part of the mod jar):
 *  - nothing is ever NaN / infinite, angles stay inside the range the fast sin / cos in LyricMesh are exact for,
 *  - nothing JUMPS: no output has a discontinuity, even at the instants a letter is born, sung or starts to leave (a jump of size J shows up as a second
 *    difference of about J; fast but smooth motion, like the peak of the entrance spring, does not),
 *  - a sung letter settles to its resting pose, a leaving letter ends up where it should,
 *  - every vertex colour the effects produce is within 0..1 (the GPU buffers store bytes: 1.02 would wrap around to black).
 *
 *   javac -d /tmp/lc src/main/java/dev/skymusic/{MistTrail,MeshFont,LyricMotion,LyricMesh}.java tools/LyricMotionCheck.java
 *   java -cp /tmp/lc dev.skymusic.LyricMotionCheck
 */
public final class LyricMotionCheck {
    static int failures = 0;
    static void check(boolean ok, String what) { if (!ok) { failures++; System.out.println("FAIL: " + what); } }

    static float[] snap() {
        return new float[]{LyricMotion.sx, LyricMotion.sy, LyricMotion.lean, LyricMotion.roll, LyricMotion.tilt, LyricMotion.yoff, LyricMotion.zoff,
                LyricMotion.alpha, LyricMotion.flash, LyricMotion.bloom};
    }
    static final String[] NAMES = {"sx", "sy", "lean", "roll", "tilt", "yoff", "zoff", "alpha", "flash", "bloom"};
    // biggest change per 1/240 s step (the fastest legitimate motion is the peak of the entrance spring: 8.4 x its range per second) ...
    static final float[] MAX_STEP = {0.020f, 0.030f, 0.012f, 0.012f, 0.025f, 1.00f, 0.12f, 0.035f, 0.20f, 0.10f};
    // ... and the biggest second difference (a jump of this size or more would be a visible pop; smooth curves stay far below it)
    static final float[] MAX_KINK = {0.010f, 0.015f, 0.005f, 0.004f, 0.006f, 0.25f, 0.06f, 0.020f, 0.080f, 0.030f};

    public static void main(String[] args) {
        // ---------------------------------------------------------------- no NaN, bounded angles, no jumps
        final float dt = 1f / 240f;
        float[] worst = new float[NAMES.length], worstKink = new float[NAMES.length];
        String[] worstAt = new String[NAMES.length], worstKinkAt = new String[NAMES.length];
        Random rnd = new Random(7);
        int cases = 0;
        for (int gi = 0; gi < 40; gi++) {
            for (float onset : new float[]{0.3f, 1.1f, 2.0f}) {
                for (float leaveAt : new float[]{-1f, 3.0f, 4.5f}) {
                    for (float dim : new float[]{0f, 0.5f, 1f}) {
                        float[] prev = null, prevD = null;
                        for (float t = -0.5f; t < 7f; t += dt) {
                            LyricMotion.frame(t + 2.5);
                            float sl = leaveAt < 0 ? 0f : Math.max(0f, Math.min(1f, (t - leaveAt) / 0.7f));
                            sl = sl * sl * (3f - 2f * sl);
                            float p = Math.max(0f, Math.min(1f, (t - onset) / 0.5f)); p = p * p * (3f - 2f * p);
                            LyricMotion.letter(gi, t, onset, sl, p, dim);
                            float[] s = snap();
                            for (int k = 0; k < s.length; k++) check(!Float.isNaN(s[k]) && !Float.isInfinite(s[k]), NAMES[k] + " is NaN / infinite at t=" + t);
                            check(Math.abs(LyricMotion.roll) <= 0.85f + 1e-6f && Math.abs(LyricMotion.tilt) <= 0.85f + 1e-6f, "angle out of range at t=" + t);
                            check(LyricMotion.sx > 0.5f && LyricMotion.sx < 1.6f && LyricMotion.sy > 0.5f && LyricMotion.sy < 1.9f, "scale out of range sx=" + LyricMotion.sx + " sy=" + LyricMotion.sy);
                            check(LyricMotion.alpha >= 0f && LyricMotion.alpha <= 1.0001f, "alpha out of range " + LyricMotion.alpha);
                            check(LyricMotion.flash >= 0f && LyricMotion.flash <= 1.0001f && LyricMotion.bloom >= 0f && LyricMotion.bloom <= 1.0001f, "flash / bloom out of range");
                            if (prev != null) {
                                float[] dd = new float[s.length];
                                for (int k = 0; k < s.length; k++) {
                                    dd[k] = s[k] - prev[k];
                                    float d = Math.abs(dd[k]);
                                    if (d > worst[k]) { worst[k] = d; worstAt[k] = "gi=" + gi + " onset=" + onset + " leave=" + leaveAt + " dim=" + dim + " t=" + t; }
                                    if (prevD != null && s[7] > 0.03f) {                          // (only while the letter is visible: at its birth it is still fully transparent)
                                        float kk = Math.abs(dd[k] - prevD[k]);
                                        if (kk > worstKink[k]) { worstKink[k] = kk; worstKinkAt[k] = "gi=" + gi + " onset=" + onset + " leave=" + leaveAt + " dim=" + dim + " t=" + t; }
                                    }
                                }
                                prevD = dd;
                            }
                            prev = s;
                        }
                        cases++;
                    }
                }
            }
        }
        System.out.println("motion: " + cases + " letter timelines x " + (int) (7.5f / dt) + " frames at 240 fps");
        for (int k = 0; k < NAMES.length; k++) {
            boolean ok = worst[k] <= MAX_STEP[k], okK = worstKink[k] <= MAX_KINK[k];
            System.out.printf("  %-5s biggest step %.4f (limit %.3f)   biggest jump (2nd difference) %.4f (limit %.3f)  %s%n", NAMES[k], worst[k], MAX_STEP[k], worstKink[k], MAX_KINK[k], ok && okK ? "ok" : "PROBLEM");
            check(ok, NAMES[k] + " moves too fast (" + worst[k] + ") at " + worstAt[k]);
            check(okK, NAMES[k] + " JUMPS (" + worstKink[k] + ") at " + worstKinkAt[k]);
        }

        // ---------------------------------------------------------------- resting poses
        LyricMotion.frame(100.0);
        LyricMotion.letter(4, 20f, 1f, 0f, 1f, 0f);                         // sung long ago, not leaving, lit
        System.out.printf("resting sung letter: sx %.3f sy %.3f yoff %.2f zoff %.2f tilt %.4f roll %.4f alpha %.2f flash %.3f bloom %.3f%n",
                LyricMotion.sx, LyricMotion.sy, LyricMotion.yoff, LyricMotion.zoff, LyricMotion.tilt, LyricMotion.roll, LyricMotion.alpha, LyricMotion.flash, LyricMotion.bloom);
        check(Math.abs(LyricMotion.sx - 1f) < 0.02f && Math.abs(LyricMotion.sy - 1f) < 0.02f, "a sung letter must settle to its normal size");
        check(Math.abs(LyricMotion.yoff + 3.2f) < 1.6f, "a sung letter rests a few px higher (the hop)");
        check(Math.abs(LyricMotion.zoff - 3.0f) < 0.01f, "a sung letter rests popped out of the sign");
        check(Math.abs(LyricMotion.tilt) < 0.001f && Math.abs(LyricMotion.roll) < 0.02f, "a sung letter must settle upright");
        check(LyricMotion.alpha > 0.999f && LyricMotion.flash == 0f && LyricMotion.bloom == 0f, "alpha 1, no flash, no bloom long after");
        LyricMotion.letter(4, 3f, 1f, 1f, 1f, 0f);                          // fully left
        System.out.printf("fully left letter:   sx %.3f sy %.3f yoff %.2f zoff %.2f tilt %.3f roll %.3f%n", LyricMotion.sx, LyricMotion.sy, LyricMotion.yoff, LyricMotion.zoff, LyricMotion.tilt, LyricMotion.roll);
        check(LyricMotion.yoff < -9f && LyricMotion.sx < 0.95f, "a leaving letter drifts up and shrinks");
        LyricMotion.letter(4, 0.0f, 1f, 0f, 0f, 0f);                        // not yet born
        check(LyricMotion.alpha == 0f && LyricMotion.flash == 0f && LyricMotion.bloom == 0f, "a letter that is not born yet is invisible");

        // ---------------------------------------------------------------- effects: colours within 0..1, no NaN, sparkles never in your face
        MistTrail.Mesh glow = new MistTrail.Mesh(), spark = new MistTrail.Mesh();
        float minC = 1f, maxC = 0f; int quads = 0, bad = 0;
        for (int it = 0; it < 20000; it++) {
            glow.clear(); spark.clear();
            float s = 0.034f, a = (float) Math.toRadians(rnd.nextFloat() * 360f);
            float rx = (float) Math.cos(a) * s, rz = (float) -Math.sin(a) * s, nx = (float) Math.sin(a) * s, nz = (float) Math.cos(a) * s;
            float dist = 0.05f + rnd.nextFloat() * 14f;
            float ox = (rnd.nextFloat() - 0.5f) * 6f, oy = (rnd.nextFloat() - 0.5f) * 3f, oz = -dist;
            float amount = rnd.nextFloat() * 1.0f, glowK = rnd.nextFloat();
            quads += MistTrail.addLetterFx(glow, spark, ox, oy, oz, rx, 0, rz, 0, -s, 0, nx, 0, nz, (rnd.nextFloat() - 0.5f) * 200f, (rnd.nextFloat() - 0.5f) * 60f,
                    rnd.nextFloat(), rnd.nextFloat() * 1.7f, rnd.nextInt(), 1 + rnd.nextInt(4), glowK, amount, 0.8f, 0.9f, 1f, 1f, 0.95f, 0.82f);
            quads += MistTrail.addGlow(glow, ox, oy, oz, rx, 0, rz, 0, -s, 0, nx, 0, nz, -80f, -80f + rnd.nextFloat() * 160f, (rnd.nextFloat() - 0.5f) * 60f, 26f,
                    rnd.nextFloat() * 0.4f * glowK * 2f, 0.8f, 0.9f, 1f);
            for (MistTrail.Mesh m : new MistTrail.Mesh[]{glow, spark})
                for (int v = 0; v < m.n; v++) {
                    for (int c = 0; c < 9; c++) { float f = m.d[v * 9 + c]; if (Float.isNaN(f) || Float.isInfinite(f)) bad++; }
                    for (int c = 5; c < 9; c++) { float f = m.d[v * 9 + c]; minC = Math.min(minC, f); maxC = Math.max(maxC, f); }
                }
        }
        System.out.printf("effects: %d quads from 20000 random placements, colour range %.3f .. %.3f, bad numbers %d%n", quads, minC, maxC, bad);
        check(bad == 0, "NaN / infinity in effect geometry");
        check(minC >= 0f && maxC <= 1f, "effect vertex colour outside 0..1");

        System.out.println(failures == 0 ? "\nALL CHECKS PASSED" : "\n" + failures + " CHECK(S) FAILED");
        if (failures != 0) System.exit(1);
    }
}
