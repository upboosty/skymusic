#!/usr/bin/env python3
"""
Bakes the 3D lyric font used by SkyRenderer.
Reads a .ttf, flattens every glyph outline, triangulates the front face (holes included) and writes
  src/main/resources/assets/skymusic/font/text3d.bin
The mod extrudes that flat outline into a solid letter at runtime (thickness = DEPTH in SkyRenderer.java, so it can be changed without re-baking).

File format (big endian):
  int  magic 0x33444654, int glyphCount
  per glyph: int codepoint, float advance (em), short triCount, short segCount,
             triCount * 6 int16   front-face triangles  (x0 y0 x1 y1 x2 y2)
             segCount * (4 int16 + 4 int8)  outline edges (x0 y0 x1 y1, normal0 xy, normal1 xy)
  coordinates are in em, y DOWN from the baseline, stored as int16 = em * 8192; normals as int8 = n * 127.

Needs: fontTools.   Run:  python3 tools/gen_text3d.py [path/to/font.ttf]
Swap the font: pass another .ttf (TrueType outlines). FALLBACK_FONT supplies notes / hearts / arrows the main font lacks.
"""
import os, sys, math, struct
from fontTools.ttLib import TTFont
from fontTools.pens.basePen import BasePen

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
MAIN_FONT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "fonts", "impact.ttf")
FALLBACK_FONT = os.path.join(HERE, "fonts", "dejavu-bold.ttf")
FALLBACK_SCALE = 0.92
OUT = os.path.join(ROOT, "src", "main", "resources", "assets", "skymusic", "font", "text3d.bin")
Q = 8192.0
SMOOTH_COS = 0.80            # neighbouring outline edges closer than ~37 degrees share one smooth normal (curves); sharper corners stay sharp
CURVE_STEP = 0.035           # max length of a flattened curve piece (em)


# ---------------------------------------------------------------- outlines
class FlattenPen(BasePen):
    def __init__(self, gs, upem):
        super().__init__(gs)
        self.u = float(upem)
        self.contours = []
        self.cur = None

    def _p(self, pt): return (pt[0] / self.u, pt[1] / self.u)       # em, y up

    def _moveTo(self, pt): self.cur = [self._p(pt)]

    def _lineTo(self, pt): self.cur.append(self._p(pt))

    def _qCurveToOne(self, p1, p2):
        a, b, c = self.cur[-1], self._p(p1), self._p(p2)
        n = max(2, min(10, int(math.hypot(c[0] - a[0], c[1] - a[1]) / CURVE_STEP) + 1))
        for i in range(1, n + 1):
            t = i / n; mt = 1 - t
            self.cur.append((mt * mt * a[0] + 2 * mt * t * b[0] + t * t * c[0], mt * mt * a[1] + 2 * mt * t * b[1] + t * t * c[1]))

    def _curveToOne(self, p1, p2, p3):
        a, b, c, d = self.cur[-1], self._p(p1), self._p(p2), self._p(p3)
        n = max(2, min(12, int(math.hypot(d[0] - a[0], d[1] - a[1]) / CURVE_STEP) + 2))
        for i in range(1, n + 1):
            t = i / n; mt = 1 - t
            self.cur.append(tuple(mt ** 3 * a[k] + 3 * mt * mt * t * b[k] + 3 * mt * t * t * c[k] + t ** 3 * d[k] for k in (0, 1)))

    def _closePath(self): self._end()

    def _endPath(self): self._end()

    def _end(self):
        if self.cur:
            pts = []
            for p in self.cur:
                if not pts or math.hypot(p[0] - pts[-1][0], p[1] - pts[-1][1]) > 1e-5: pts.append(p)
            while len(pts) > 1 and math.hypot(pts[0][0] - pts[-1][0], pts[0][1] - pts[-1][1]) <= 1e-5: pts.pop()
            if len(pts) >= 3: self.contours.append(pts)
        self.cur = None


def area(r):
    return 0.5 * sum(r[i][0] * r[(i + 1) % len(r)][1] - r[(i + 1) % len(r)][0] * r[i][1] for i in range(len(r)))


def inside(pt, r):
    x, y = pt; c = False; n = len(r)
    for i in range(n):
        x1, y1 = r[i]; x2, y2 = r[(i + 1) % n]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1: c = not c
    return c


def group(contours):
    """-> list of (outer, [holes]) with outer CCW and holes CW (y up)"""
    info = []
    for i, c in enumerate(contours):
        depth = sum(1 for j, d in enumerate(contours) if j != i and inside(c[0], d))
        info.append(depth)
    outers = []
    for i, c in enumerate(contours):
        if info[i] % 2 == 0:
            outers.append((i, c if area(c) > 0 else c[::-1], []))
    for i, c in enumerate(contours):
        if info[i] % 2 == 1:
            best = None
            for (oi, o, hs) in outers:
                if info[oi] == info[i] - 1 and inside(c[0], contours[oi]):
                    if best is None or abs(area(o)) < abs(area(best[1])): best = (oi, o, hs)
            if best is not None: best[2].append(c if area(c) < 0 else c[::-1])
    return [(o, hs) for (_, o, hs) in outers]


# ---------------------------------------------------------------- triangulation (hole bridging + ear clipping)
def cross(o, a, b): return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def seg_cross(p, q, a, b):
    """proper intersection of segments pq and ab"""
    d1, d2, d3, d4 = cross(p, q, a), cross(p, q, b), cross(a, b, p), cross(a, b, q)
    return ((d1 > 1e-12 and d2 < -1e-12) or (d1 < -1e-12 and d2 > 1e-12)) and ((d3 > 1e-12 and d4 < -1e-12) or (d3 < -1e-12 and d4 > 1e-12))


def same(a, b): return abs(a[0] - b[0]) < 1e-9 and abs(a[1] - b[1]) < 1e-9


def clear(m, p, rings):
    for r in rings:
        n = len(r)
        for i in range(n):
            a, b = r[i], r[(i + 1) % n]
            if same(a, m) or same(b, m) or same(a, p) or same(b, p): continue
            if seg_cross(m, p, a, b): return False
    return True


def bridge(outer, holes):
    ring = list(outer)
    rest = sorted(holes, key=lambda h: -max(q[0] for q in h))
    for k, hole in enumerate(rest):
        hi = max(range(len(hole)), key=lambda i: hole[i][0])
        m = hole[hi]
        others = [ring] + rest[k:]
        order = sorted(range(len(ring)), key=lambda j: (ring[j][0] - m[0]) ** 2 + (ring[j][1] - m[1]) ** 2)
        pick = None
        for j in order:
            p = ring[j]
            if not clear(m, p, others): continue
            mid = ((m[0] + p[0]) / 2, (m[1] + p[1]) / 2)
            if not inside(mid, ring) or inside(mid, hole): continue
            pick = j; break
        if pick is None: pick = order[0]
        ring = ring[:pick + 1] + hole[hi:] + hole[:hi + 1] + [ring[pick]] + ring[pick + 1:]
    return ring


def in_tri(p, a, b, c):
    d1, d2, d3 = cross(a, b, p), cross(b, c, p), cross(c, a, p)
    return d1 >= -1e-12 and d2 >= -1e-12 and d3 >= -1e-12


def ear_clip(ring):
    idx = list(range(len(ring)))
    tris = []
    guard = 0
    while len(idx) > 3 and guard < 100000:
        guard += 1
        n = len(idx); cut = False
        for i in range(n):
            ia, ib, ic = idx[(i - 1) % n], idx[i], idx[(i + 1) % n]
            a, b, c = ring[ia], ring[ib], ring[ic]
            cr = cross(a, b, c)
            if abs(cr) < 1e-12:                         # collinear / spike: drop the vertex without a triangle
                idx.pop(i); cut = True; break
            if cr < 0: continue                         # reflex
            ok = True
            for j in idx:
                if j in (ia, ib, ic): continue
                p = ring[j]
                if same(p, a) or same(p, b) or same(p, c): continue
                if in_tri(p, a, b, c): ok = False; break
            if ok:
                tris.append((a, b, c)); idx.pop(i); cut = True; break
        if not cut:                                     # numerical trouble: cut the sharpest convex corner anyway
            best, bi = -1, 0
            for i in range(n):
                cr = cross(ring[idx[(i - 1) % n]], ring[idx[i]], ring[idx[(i + 1) % n]])
                if cr > best: best, bi = cr, i
            a, b, c = ring[idx[(bi - 1) % n]], ring[idx[bi]], ring[idx[(bi + 1) % n]]
            if best > 0: tris.append((a, b, c))
            idx.pop(bi)
    if len(idx) == 3:
        a, b, c = (ring[i] for i in idx)
        if cross(a, b, c) > 1e-12: tris.append((a, b, c))
    return tris


# ---------------------------------------------------------------- outline edges with normals
def edges_of(ring):
    """ring oriented so that material is on the left (outer CCW, hole CW). returns [(p0, p1, n0, n1)], normals point away from the material"""
    n = len(ring)
    en = []
    for i in range(n):
        a, b = ring[i], ring[(i + 1) % n]
        dx, dy = b[0] - a[0], b[1] - a[1]
        l = math.hypot(dx, dy) or 1.0
        en.append((dy / l, -dx / l))
    out = []
    for i in range(n):
        a, b = ring[i], ring[(i + 1) % n]
        e = en[i]; ep = en[(i - 1) % n]; enx = en[(i + 1) % n]
        def vn(e1, e2):
            if e1[0] * e2[0] + e1[1] * e2[1] >= SMOOTH_COS:
                sx, sy = e1[0] + e2[0], e1[1] + e2[1]; l = math.hypot(sx, sy) or 1.0
                return (sx / l, sy / l)
            return e1
        out.append((a, b, vn(e, ep), vn(e, enx)))
    return out


# ---------------------------------------------------------------- build
def bake_glyph(font, gs, name, scale, adv_units):
    upem = font['head'].unitsPerEm
    pen = FlattenPen(gs, upem)
    gs[name].draw(pen)
    tris, segs = [], []
    total_area = 0.0
    for outer, holes in group(pen.contours):
        total_area += area(outer) + sum(area(h) for h in holes)
        for t in ear_clip(bridge(outer, holes)): tris.append(t)
        for ring in [outer] + holes: segs += edges_of(ring)
    tri_area = sum(abs(cross(a, b, c)) / 2 for a, b, c in tris)
    warn = abs(tri_area - total_area) > 0.002 + 0.01 * abs(total_area)
    return tris, segs, adv_units / upem * scale, warn


def q16(v):
    return max(-32768, min(32767, int(round(v * Q))))


def q8(v):
    return max(-127, min(127, int(round(v * 127))))


def main():
    main_f, fb_f = TTFont(MAIN_FONT), TTFont(FALLBACK_FONT)
    mc, fc = main_f.getBestCmap(), fb_f.getBestCmap()
    mgs, fgs = main_f.getGlyphSet(), fb_f.getGlyphSet()
    extra = [0x266a, 0x266b, 0x2665, 0x2605, 0x2606, 0x2190, 0x2191, 0x2192, 0x2193, 0x2022, 0x20ac, 0x2122, 0x2026]
    cps = [c for c in sorted(mc) if (32 <= c < 0x2200 or c in extra) and not (0x7f <= c <= 0xa0) and c != 0xad]
    jobs = []
    for c in cps:
        jobs.append((c, main_f, mgs, mc[c], 1.0))
    for c in extra:
        if c not in mc and c in fc: jobs.append((c, fb_f, fgs, fc[c], FALLBACK_SCALE))
    jobs.sort(key=lambda j: j[0])
    blob = bytearray(struct.pack('>ii', 0x33444654, 0))
    count = 0; ntri = nseg = 0; bad = []
    for (c, font, gs, name, scale) in jobs:
        adv = font['hmtx'][name][0]
        tris, segs, adv_em, warn = bake_glyph(font, gs, name, scale, adv)
        if warn: bad.append(chr(c))
        sc = scale
        blob += struct.pack('>ifhh', c, adv_em, len(tris), len(segs))
        for t in tris:
            for (x, y) in t: blob += struct.pack('>hh', q16(x * sc), q16(-y * sc))
        for (a, b, n0, n1) in segs:
            blob += struct.pack('>hhhh', q16(a[0] * sc), q16(-a[1] * sc), q16(b[0] * sc), q16(-b[1] * sc))
            blob += struct.pack('>bbbb', q8(n0[0]), q8(-n0[1]), q8(n1[0]), q8(-n1[1]))
        count += 1; ntri += len(tris); nseg += len(segs)
    struct.pack_into('>i', blob, 4, count)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    open(OUT, 'wb').write(bytes(blob))
    print("glyphs %d, triangles %d, outline edges %d, %.0f KB -> %s" % (count, ntri, nseg, len(blob) / 1024.0, OUT))
    if bad: print("triangulation area mismatch (check): " + " ".join(bad))
    # handy numbers for SkyRenderer's EM_PX
    for ch in "HEx":
        if ord(ch) in mc:
            gb = main_f['glyf'][mc[ord(ch)]]
            print("height of %s: %.3f em" % (ch, gb.yMax / main_f['head'].unitsPerEm))


if __name__ == "__main__":
    main()
