package dev.skymusic;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

/**
 * Offline software preview of the lyric mist trail: runs the REAL MistTrail geometry and rasterises it the way the game does
 * (z-buffer, perspective-correct texturing, alpha blending SRC_ALPHA / ONE_MINUS_SRC_ALPHA, no depth writes for the mist),
 * in front of a stand-in sign. Dev tool only, it is not part of the mod jar.
 *
 *   javac -d /tmp/mp src/main/java/dev/skymusic/MistTrail.java tools/MistPreview.java
 *   java -cp /tmp/mp dev.skymusic.MistPreview src/main/resources/assets/skymusic/textures/mist out.png [yawDegrees] [distance] [rows]
 */
public final class MistPreview {
    static int W = 1280, H = 720;      // rendered large, the sheet shows a 640 x 360 crop around the sign
    static float fy;                       // focal length in px for a 70 degree vertical field of view
    static float[] zbuf;
    static float[] img;                    // rgb

    static BufferedImage texW, texP;

    static float[] sample(BufferedImage t, float u, float v) {
        int tw = t.getWidth(), th = t.getHeight();
        float x = u * tw - 0.5f, y = v * th - 0.5f;
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y);
        float fx = x - x0, fyy = y - y0;
        float[] o = new float[4];
        for (int j = 0; j < 2; j++)
            for (int i = 0; i < 2; i++) {
                int xx = Math.floorMod(x0 + i, tw), yy = Math.floorMod(y0 + j, th);
                int p = t.getRGB(xx, yy);
                float wgt = (i == 0 ? 1 - fx : fx) * (j == 0 ? 1 - fyy : fyy);
                o[0] += ((p >> 16) & 255) / 255f * wgt; o[1] += ((p >> 8) & 255) / 255f * wgt;
                o[2] += (p & 255) / 255f * wgt; o[3] += ((p >>> 24) & 255) / 255f * wgt;
            }
        return o;
    }

    /** one triangle: 3 vertices of (x y z u v r g b a) in eye space; tex == null -> flat colour, writes depth */
    static void tri(float[] a, float[] b, float[] c, BufferedImage tex, boolean writeDepth) {
        float[][] p = {a, b, c};
        float[] sx = new float[3], sy = new float[3], iw = new float[3];
        for (int i = 0; i < 3; i++) {
            float w = -p[i][2];
            if (w < 0.05f) return;                        // (the preview does not clip: it keeps the camera away from the geometry)
            iw[i] = 1f / w;
            sx[i] = W / 2f + p[i][0] * iw[i] * fy;
            sy[i] = H / 2f - p[i][1] * iw[i] * fy;
        }
        float area = (sx[1] - sx[0]) * (sy[2] - sy[0]) - (sx[2] - sx[0]) * (sy[1] - sy[0]);
        if (Math.abs(area) < 1e-6f) return;
        int minX = Math.max(0, (int) Math.floor(Math.min(sx[0], Math.min(sx[1], sx[2])))), maxX = Math.min(W - 1, (int) Math.ceil(Math.max(sx[0], Math.max(sx[1], sx[2]))));
        int minY = Math.max(0, (int) Math.floor(Math.min(sy[0], Math.min(sy[1], sy[2])))), maxY = Math.min(H - 1, (int) Math.ceil(Math.max(sy[0], Math.max(sy[1], sy[2]))));
        for (int y = minY; y <= maxY; y++)
            for (int x = minX; x <= maxX; x++) {
                float px = x + 0.5f, py = y + 0.5f;
                float w0 = ((sx[1] - px) * (sy[2] - py) - (sx[2] - px) * (sy[1] - py)) / area;
                float w1 = ((sx[2] - px) * (sy[0] - py) - (sx[0] - px) * (sy[2] - py)) / area;
                float w2 = 1f - w0 - w1;
                if (w0 < 0 || w1 < 0 || w2 < 0) continue;
                float ipw = w0 * iw[0] + w1 * iw[1] + w2 * iw[2];
                float depth = 1f / ipw;
                int idx = y * W + x;
                if (depth > zbuf[idx] + 1e-4f) continue;                         // LEQUAL depth test
                float rr, gg, bb, aa;
                float pw0 = w0 * iw[0] / ipw, pw1 = w1 * iw[1] / ipw, pw2 = w2 * iw[2] / ipw;
                rr = pw0 * a[5] + pw1 * b[5] + pw2 * c[5]; gg = pw0 * a[6] + pw1 * b[6] + pw2 * c[6];
                bb = pw0 * a[7] + pw1 * b[7] + pw2 * c[7]; aa = pw0 * a[8] + pw1 * b[8] + pw2 * c[8];
                if (tex != null) {
                    float u = pw0 * a[3] + pw1 * b[3] + pw2 * c[3], v = pw0 * a[4] + pw1 * b[4] + pw2 * c[4];
                    float[] t = sample(tex, u, v);
                    rr *= t[0]; gg *= t[1]; bb *= t[2]; aa *= t[3];
                }
                img[idx * 3] = img[idx * 3] * (1 - aa) + rr * aa;
                img[idx * 3 + 1] = img[idx * 3 + 1] * (1 - aa) + gg * aa;
                img[idx * 3 + 2] = img[idx * 3 + 2] * (1 - aa) + bb * aa;
                if (writeDepth) zbuf[idx] = depth;
            }
    }

    static void drawMesh(MistTrail.Mesh m, BufferedImage tex) {
        for (int q = 0; q + 3 < m.n; q += 4) {
            float[][] v = new float[4][9];
            for (int i = 0; i < 4; i++) System.arraycopy(m.d, (q + i) * 9, v[i], 0, 9);
            tri(v[0], v[1], v[2], tex, false);
            tri(v[0], v[2], v[3], tex, false);
        }
    }

    static float[] vtx(float x, float y, float z, float r, float g, float b) { return new float[]{x, y, z, 0, 0, r, g, b, 1f}; }

    /** a stand-in for the lyric text: opaque bars (they write depth, so mist behind them is hidden like in the game) */
    static void fakeText(float[] o, float[] r, float[] d, float[] n, int rows, float half) {
        for (int row = 0; row < rows; row++) {
            float rowY = (row - (rows - 1) / 2f) * 26f;
            float x = -half + 6;
            int word = 0;
            while (x < half - 30) {
                float wl = 34 + 9 * ((word * 7 + row * 3) % 5);
                float h0 = rowY - 8, h1 = rowY + 8;
                float[][] c = new float[4][];
                float[][] xy = {{x, h0}, {x + wl, h0}, {x + wl, h1}, {x, h1}};
                for (int i = 0; i < 4; i++)
                    c[i] = vtx(o[0] + xy[i][0] * r[0] + xy[i][1] * d[0], o[1] + xy[i][0] * r[1] + xy[i][1] * d[1], o[2] + xy[i][0] * r[2] + xy[i][1] * d[2], 0.95f, 0.95f, 1f);
                tri(c[0], c[1], c[2], null, true);
                tri(c[0], c[2], c[3], null, true);
                x += wl + 10;
                word++;
            }
        }
    }

    static void clear(float sky) {
        java.util.Arrays.fill(zbuf, Float.MAX_VALUE);
        for (int i = 0; i < W * H; i++) { float g = sky * (0.55f + 0.45f * (1f - (i / W) / (float) H)); img[i * 3] = g * 0.55f; img[i * 3 + 1] = g * 0.72f; img[i * 3 + 2] = g; }
    }

    public static void main(String[] args) throws Exception {
        File dir = new File(args[0]);
        texW = ImageIO.read(new File(dir, "wisp.png"));
        texP = ImageIO.read(new File(dir, "puff.png"));
        File out = new File(args[1]);
        float yaw = args.length > 2 ? Float.parseFloat(args[2]) : -18f;
        float dist = args.length > 3 ? Float.parseFloat(args[3]) : 8f;
        int rows = args.length > 4 ? Integer.parseInt(args[4]) : 2;
        float sky = args.length > 5 ? Float.parseFloat(args[5]) : 0.10f;        // 0.10 = dark (night / black like the reference), 0.9 = bright day
        fy = (H / 2f) / (float) Math.tan(Math.toRadians(35));
        zbuf = new float[W * H]; img = new float[W * H * 3];
        float s = 0.034f;
        double a = Math.toRadians(yaw);
        float[] r = {(float) Math.cos(a) * s, 0, (float) -Math.sin(a) * s};
        float[] d = {0, -s, 0};
        float[] n = {(float) Math.sin(a) * s, 0, (float) Math.cos(a) * s};
        float[] o = {1.2f, 0.2f, -dist};
        float half = 125f;
        float[] times = {0.4f, 1.6f, 2.8f, 4.0f, 5.2f, 6.4f};
        int cols = 3, rws = 2;
        int CW = 640, CH = 360;
        BufferedImage sheet = new BufferedImage(CW * cols, CH * rws, BufferedImage.TYPE_INT_RGB);
        MistTrail.Look look = new MistTrail.Look();
        if (args.length > 6) look.opacity = Float.parseFloat(args[6]);
        if (args.length > 7) look.size = Float.parseFloat(args[7]);
        for (int ti = 0; ti < times.length; ti++) {
            clear(sky);
            fakeText(o, r, d, n, rows, half);
            MistTrail.Mesh wisp = new MistTrail.Mesh(), puff = new MistTrail.Mesh();
            int quads = 0;
            for (int row = 0; row < rows; row++) {
                float rowY = (row - (rows - 1) / 2f) * 26f;
                quads += MistTrail.addRow(wisp, puff, look, o[0], o[1], o[2], r[0], r[1], r[2], d[0], d[1], d[2], n[0], n[1], n[2],
                        half, rowY, 26f, times[ti], 1000 + row * 13, 1f, 1f, 1f, 1f, 1f);
            }
            if (!"1".equals(System.getProperty("nowisp"))) drawMesh(wisp, texW);
            if (!"1".equals(System.getProperty("nopuff"))) drawMesh(puff, texP);
            BufferedImage fr = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
            for (int i = 0; i < W * H; i++) {
                int rr = Math.max(0, Math.min(255, (int) (img[i * 3] * 255))), gg = Math.max(0, Math.min(255, (int) (img[i * 3 + 1] * 255))), bb = Math.max(0, Math.min(255, (int) (img[i * 3 + 2] * 255)));
                fr.setRGB(i % W, i / W, (rr << 16) | (gg << 8) | bb);
            }
            int cxs = Math.round(W / 2f + o[0] / -o[2] * fy), cys = Math.round(H / 2f - o[1] / -o[2] * fy);
            sheet.getGraphics().drawImage(fr.getSubimage(Math.max(0, cxs - CW / 2), Math.max(0, cys - CH / 2), CW, CH), (ti % cols) * CW, (ti / cols) * CH, null);
            System.out.println("t=" + times[ti] + " quads=" + quads);
        }
        ImageIO.write(sheet, "png", out);
    }
}
