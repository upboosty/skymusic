package dev.skymusic;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Giant Apple-Music-style lyrics floating in the sky.
 *
 * Look: bold baked font (one atlas texture), every word starts dim and lights up as it is sung (soft glow, tiny lift),
 * lines spring in from below, then defocus (blur), dim and drift up when they are done.
 *
 * Speed: the whole lyric text is ONE batch of textured quads (one texture, one draw call). The old version drew every
 * letter through the vanilla font renderer, which switches glyph textures all the time and made hundreds of draw calls per frame.
 * Each lyric line is a flat sign in the world: its plane is projected once per frame and every glyph corner is then simple arithmetic.
 * (The lyrics are part of the HUD, so F1 hides them.) Letters that are not in the atlas fall back to the vanilla font.
 */
public class SkyRenderer {
    public static volatile boolean customFont = true;
    /** 0 = never, 1 = always, 2 = auto: a small plain subtitle only while the sky lyrics are out of view */
    public static volatile int subtitleMode = 2;
    public static volatile String status = "not rendered yet";
    /** /sky size <percent>: size of the lyric lines (1 = default) */
    public static volatile float SIZE = 1f;

    private static final float ROW_GAP = 26f;       // layout px between rows (the layout thinks in a 20 px font)
    private static final float BASE = 6f;           // baseline is this far below the visual middle of a row
    private static final float SPACE_W = 7.4f;      // width of a space
    private static final float LEG = 2.1f;          // vanilla font (8 px) -> layout px, for letters the atlas does not have
    private static final float MAX_SCALE = 0.30f;   // world units per layout px (short lines)
    private static final float TARGET_W = 44f;      // max line width in blocks
    private static final double DIST = 70;          // radius of the lyric dome (blocks)
    public static volatile float ELEV = 0.45f;       // elevation of the lyric block centre in radians (~26 degrees up), /sky height <deg>
    private static boolean anchored = false;
    private static boolean errorShown = false;

    // camera matrices captured at the end of the world render, used by the HUD pass
    private static final Matrix4f VP = new Matrix4f();
    private static boolean haveVP = false;
    private static float camYaw = 0, camPitch = 0;
    private static double camX = 0, camY = 0, camZ = 0;
    private static float scrW = 1, scrH = 1;

    public static void init() {
        LyricFont.load();
        WorldRenderEvents.LAST.register(SkyRenderer::capture);
        HudRenderCallback.EVENT.register(SkyRenderer::renderHud);
    }

    public static void recheckFont() { LAYOUTS.clear(); }

    private static void capture(WorldRenderContext ctx) {
        VP.set(ctx.projectionMatrix()).mul(ctx.matrixStack().peek().getPositionMatrix());
        camYaw = ctx.camera().getYaw();
        camPitch = ctx.camera().getPitch();
        camX = ctx.camera().getPos().x; camY = ctx.camera().getPos().y; camZ = ctx.camera().getPos().z;
        haveVP = true;
    }

    private static boolean useAtlas() { return customFont && LyricFont.ok; }

    // ---------- layout of one lyric line ----------
    /** one animated piece of a line: a short word, or a part of a long word */
    private static final class Seg {
        float x, w;                 // start and width inside its row (layout px)
        float f0, f1;               // the share of the line's sweep during which it lights up (0..1)
        int idx, n;                 // running number in the line, number of letters
        int base;                   // number of the first letter of this piece in the whole line (for the jelly wave)
        boolean legacy;             // contains letters the atlas does not have -> vanilla font
        int[] cp; float[] gx;       // atlas glyphs: code points and pen x from the segment start
        OrderedText ot; float lw;   // vanilla: the text and its vanilla width
    }
    private static final class Layout {
        Seg[][] segs; float[] rowW; int rows; float maxW = 1f; int total = 1;
    }

    // layouts are cached by text; the carousel draws up to four lines at once
    private static final java.util.HashMap<String, Layout> LAYOUTS = new java.util.HashMap<>();
    private static boolean layoutAtlas = true;
    private static Layout layoutFor(String text, TextRenderer tr, boolean atlas) {
        if (atlas != layoutAtlas || LAYOUTS.size() > 64) { LAYOUTS.clear(); layoutAtlas = atlas; }
        Layout l = LAYOUTS.get(text);
        if (l == null) { l = build(text, tr, atlas); LAYOUTS.put(text, l); }
        return l;
    }

    private static Layout build(String text, TextRenderer tr, boolean atlas) {
        String[] rows = wrap(text);
        Layout L = new Layout();
        L.rows = rows.length;
        L.segs = new Seg[rows.length][];
        L.rowW = new float[rows.length];
        List<Seg> all = new ArrayList<>();
        int total = 0;
        for (int r = 0; r < rows.length; r++) {
            List<Seg> list = new ArrayList<>();
            float cx = 0;
            boolean first = true;
            for (String word : rows[r].trim().split("\\s+")) {
                if (word.isEmpty()) continue;
                if (!first) cx += SPACE_W;
                first = false;
                int[] cps = word.codePoints().toArray();
                int pieces = cps.length > 6 ? (int) Math.ceil(cps.length / 4.0) : 1;     // long words light up in parts
                int per = (int) Math.ceil(cps.length / (double) pieces);
                for (int a = 0; a < cps.length; a += per) {
                    int b = Math.min(cps.length, a + per);
                    Seg s = new Seg();
                    s.x = cx; s.n = b - a;
                    boolean okAtlas = atlas;
                    for (int k = a; k < b && okAtlas; k++) {
                        LyricFont.Glyph g = LyricFont.get(cps[k]);
                        if (g == null || !g.has[0]) okAtlas = false;
                    }
                    if (okAtlas) {
                        s.cp = Arrays.copyOfRange(cps, a, b);
                        s.gx = new float[s.n];
                        float px = 0;
                        for (int k = 0; k < s.n; k++) { s.gx[k] = px; px += LyricFont.get(s.cp[k]).adv; }
                        s.w = px;
                    } else {
                        s.legacy = true;
                        Text t = Text.literal(new String(cps, a, b - a));
                        s.ot = t.asOrderedText();
                        s.lw = tr.getWidth(t);
                        s.w = s.lw * LEG;
                    }
                    cx += s.w;
                    list.add(s); all.add(s); total += s.n;
                }
            }
            L.segs[r] = list.toArray(new Seg[0]);
            L.rowW[r] = cx;
            L.maxW = Math.max(L.maxW, cx);
        }
        float acc = 0; int i = 0;
        for (Seg s : all) {                                   // when each piece lights up: longer pieces take longer
            s.f0 = acc / Math.max(1, total);
            s.base = (int) acc;
            acc += s.n;
            s.f1 = acc / Math.max(1, total);
            s.idx = i++;
        }
        L.total = Math.max(1, total);
        return L;
    }

    private static String[] wrap(String s) {
        s = s.trim();
        int len = s.codePointCount(0, s.length());
        int k = Math.min(5, Math.max(1, (int) Math.ceil(len / 21.0)));
        if (k == 1) return new String[]{s};
        String[] words = s.split("\\s+");
        int target = (int) Math.ceil(len / (double) k);
        List<String> rows = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : words) {
            if (cur.length() > 0 && cur.length() + 1 + w.length() > target && rows.size() < k - 1) {
                rows.add(cur.toString()); cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        rows.add(cur.toString());
        return rows.toArray(new String[0]);
    }

    // ---------- helpers ----------
    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static float easeOutCubic(float x) { float u = 1f - x; return 1f - u * u * u; }
    private static float smooth(float x) { return x * x * (3f - 2f * x); }
    private static float lerp(float a, float b, float f) { return a + (b - a) * f; }
    private static float wrapDeg(float d) { return ((d % 360f) + 540f) % 360f - 180f; }
    private static int rgb(float r, float g, float b, int a) {
        return (a << 24) | ((int) (clamp01(r) * 255) << 16) | ((int) (clamp01(g) * 255) << 8) | (int) (clamp01(b) * 255);
    }
    /** underdamped spring 0 -> 1 (t in seconds): slides in and overshoots by about 8% before it settles */
    private static float spring(float t) {
        if (t <= 0f) return 0f;
        if (t > 1.6f) return 1f;
        double z = 0.62, w = 11.0, wd = w * Math.sqrt(1.0 - z * z), k = z * w;
        return (float) (1.0 - Math.exp(-k * t) * (Math.cos(wd * t) + (k / wd) * Math.sin(wd * t)));
    }

    // ---------- jelly motion ----------
    private static final double ENTER_Z = 0.40, ENTER_W = 14.0;     // springy entrance of every letter (damping ratio, rad/s)
    private static final float ENTER_DROP = 22f;                    // letters fly up from this far below (layout px)
    private static final float ENTER_VN = (float) peakVel(ENTER_Z, ENTER_W);
    private static double animSecs = 0;
    private static float sPos, sVel;                                // result of springPV()

    private static double peakVel(double z, double w) {
        double wd = w * Math.sqrt(1.0 - z * z), k = z * w, t = Math.atan(wd / k) / wd;
        return w * w / wd * Math.exp(-k * t) * Math.sin(wd * t);
    }

    /** underdamped spring 0 -> 1 with its own damping ratio z and frequency w; sPos = position, sVel = velocity (1/s) */
    private static void springPV(float t, double z, double w) {
        if (t <= 0f) { sPos = 0f; sVel = 0f; return; }
        double wd = w * Math.sqrt(1.0 - z * z), k = z * w;
        if (t > 9.0 / k) { sPos = 1f; sVel = 0f; return; }
        double e = Math.exp(-k * t), c = Math.cos(wd * t), sn = Math.sin(wd * t);
        sPos = (float) (1.0 - e * (c + (k / wd) * sn));
        sVel = (float) (e * (w * w / wd) * sn);
    }

    /** damped jelly shake: starts at 0 without a jolt, about 0.7 at the first swing, gone after ~1 s */
    private static float wobble(float t) {
        if (t <= 0f || t > 1.7f) return 0f;
        float ramp = t >= 0.04f ? 1f : smooth(t / 0.04f);
        return ramp * (float) (Math.exp(-5.2 * t) * Math.sin(21.0 * t));
    }

    /** the sideways part of the shake (slower, so it does not move in lock step with the squash) */
    private static float sway(float t) {
        if (t <= 0f || t > 1.7f) return 0f;
        float ramp = t >= 0.05f ? 1f : smooth(t / 0.05f);
        return ramp * (float) (Math.exp(-4.6 * t) * Math.sin(17.0 * t));
    }

    // what letterMotion() hands back: scale, lean (sideways shift of the top per unit of height), vertical offset (down = +), opacity
    private static float mSx, mSy, mLean, mOff, mA;

    /**
     * Jelly motion of one letter. gi / total = its number in the line (the wave runs along the line), tIn = seconds since the line
     * was born, onset = when this letter is sung, sl = how far it has left (0..1), p = how sung it is (0..1), dimK = line dimming.
     * Entrance: springs up from below, stretches while it flies and squashes when it lands. Sung: hops up and shakes like jelly.
     * Leaving: stretches a little while it drifts up. Lit letters breathe very slightly.
     */
    private static void letterMotion(int gi, int total, float tIn, float onset, float sl, float p, float dimK) {
        float stag = Math.min(0.026f, 0.38f / Math.max(1, total));
        float te = tIn - gi * stag;
        springPV(te, ENTER_Z, ENTER_W);
        float e = sPos, v = sVel / ENTER_VN;
        if (v < 0f) v *= 2.4f;                                 // the way back down is slower: exaggerate it so the landing really squashes
        float sy = 1f + 0.26f * v, sx = 1f - 0.17f * v;
        float off = (1f - e) * ENTER_DROP;
        mA = smooth(clamp01(te / 0.20f));

        float ts = tIn - onset;
        float wv = wobble(ts);
        sy *= 1f + 0.20f * wv;  sx *= 1f - 0.13f * wv;
        mLean = ((gi & 1) == 0 ? 1f : -1f) * 0.12f * sway(ts);
        springPV(ts, 0.50, 15.0);
        off -= 3.2f * sPos;                                    // sung letters hop up a little and settle with a bounce

        float ev = (float) Math.sin(Math.PI * sl);             // leaving: stretch while drifting up
        sy *= 1f + 0.14f * ev;  sx *= 1f - 0.09f * ev;
        off -= sl * 5f;

        float idleK = p * (1f - dimK) * (1f - sl) * mA;        // lit letters breathe, just barely
        sy *= 1f + 0.014f * (float) Math.sin(animSecs * 3.4 + gi * 0.65) * idleK;
        sx *= 1f - 0.009f * (float) Math.sin(animSecs * 3.4 + gi * 0.65) * idleK;
        off += 0.5f * (float) Math.sin(animSecs * 2.3 + gi * 0.9) * idleK;
        mSx = sx; mSy = sy; mOff = off;
    }

    private static float scaleOf(Layout L) { return Math.min(Math.min(MAX_SCALE, TARGET_W / L.maxW), 22f / (L.rows * ROW_GAP)) * SIZE; }
    private static float heightOf(Layout L, float mult) { return L.rows * ROW_GAP * scaleOf(L) * mult; }

    // ---------- projection ----------
    private static final Vector4f V4 = new Vector4f();
    private static final float[] PC = new float[2];
    private static final Matrix4f AFF = new Matrix4f(), MT = new Matrix4f();

    /** world point (relative to the camera) -> GUI-scaled screen coordinates; false if behind the camera */
    private static boolean project(double x, double y, double z, float[] out) {
        V4.set((float) x, (float) y, (float) z, 1f);
        VP.transform(V4);
        if (V4.w <= 0.05f) return false;
        out[0] = (V4.x / V4.w * 0.5f + 0.5f) * scrW;
        out[1] = (0.5f - V4.y / V4.w * 0.5f) * scrH;
        return true;
    }

    // the plane of the sign being drawn, in clip space: point(x, y) = C0 + x * CX + y * CY  (x right, y down, in layout px)
    private static float c0x, c0y, c0w, cxx, cxy, cxw, cyx, cyy, cyw;
    private static float SX, SY;

    private static void setPlane(double rx, double ry, double rz, float rightX, float rightZ, float s) {
        V4.set((float) rx, (float) ry, (float) rz, 1f); VP.transform(V4); c0x = V4.x; c0y = V4.y; c0w = V4.w;
        V4.set(rightX * s, 0f, rightZ * s, 0f); VP.transform(V4); cxx = V4.x; cxy = V4.y; cxw = V4.w;
        V4.set(0f, -s, 0f, 0f); VP.transform(V4); cyx = V4.x; cyy = V4.y; cyw = V4.w;
    }

    /** sign plane point -> GUI screen coordinates in SX, SY; false if behind the camera */
    private static boolean sp(float x, float y) {
        float w = c0w + x * cxw + y * cyw;
        if (w <= 0.05f) return false;
        float inv = 1f / w;
        SX = ((c0x + x * cxx + y * cyx) * inv * 0.5f + 0.5f) * scrW;
        SY = (0.5f - (c0y + x * cxy + y * cyy) * inv * 0.5f) * scrH;
        return true;
    }

    // ---------- the one textured batch ----------
    private static BufferBuilder buf;
    private static boolean begun = false;
    private static Matrix4f hudM;
    private static int drawn = 0;

    private static void beginAtlas() {
        RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
        RenderSystem.setShaderTexture(0, LyricFont.TEX);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        begun = true;
    }

    private static void endAtlas() {
        if (!begun) return;
        begun = false;
        try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch (Throwable ignored) { }
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
    }

    private static final float[] QX = new float[4], QY = new float[4];

    /**
     * One glyph quad of variant vi (0 sharp, 1 soft, 2 glow). pen = pen x and base = baseline y on the sign plane (already including the
     * letter's own bounce), pvx = x of the letter's foot (middle of its advance). The letter is squashed / stretched by sx, sy about its
     * foot (so it stays planted like jelly), lean shifts the top sideways, dy = extra offset down (shadow).
     */
    private static void glyphQuad(LyricFont.Glyph g, int vi, float pen, float base, float pvx, float sx, float sy, float lean,
                                  float r, float gr, float b, float a, float dy) {
        if (a < 0.012f || !g.has[vi]) return;
        float l = pen + g.ox[vi], t = base + g.oy[vi], rr = l + g.w[vi], bb = t + g.h[vi];
        l = pvx + (l - pvx) * sx; rr = pvx + (rr - pvx) * sx;
        t = base + (t - base) * sy; bb = base + (bb - base) * sy;
        float lt = lean * (base - t), lb = lean * (base - bb);          // the top leans, the foot stays
        t += dy; bb += dy;
        if (!sp(l + lt, t)) return;  QX[0] = SX; QY[0] = SY;
        if (!sp(l + lb, bb)) return; QX[1] = SX; QY[1] = SY;
        if (!sp(rr + lb, bb)) return; QX[2] = SX; QY[2] = SY;
        if (!sp(rr + lt, t)) return; QX[3] = SX; QY[3] = SY;
        float minX = Math.min(Math.min(QX[0], QX[1]), Math.min(QX[2], QX[3])), maxX = Math.max(Math.max(QX[0], QX[1]), Math.max(QX[2], QX[3]));
        float minY = Math.min(Math.min(QY[0], QY[1]), Math.min(QY[2], QY[3])), maxY = Math.max(Math.max(QY[0], QY[1]), Math.max(QY[2], QY[3]));
        if (maxX < -scrW * 0.1f || minX > scrW * 1.1f || maxY < -scrH * 0.1f || minY > scrH * 1.1f) return;
        if (!begun) beginAtlas();
        float u0 = g.u0[vi], v0 = g.v0[vi], u1 = g.u1[vi], v1 = g.v1[vi];
        buf.vertex(hudM, QX[0], QY[0], 0f).texture(u0, v0).color(r, gr, b, a).next();
        buf.vertex(hudM, QX[1], QY[1], 0f).texture(u0, v1).color(r, gr, b, a).next();
        buf.vertex(hudM, QX[2], QY[2], 0f).texture(u1, v1).color(r, gr, b, a).next();
        buf.vertex(hudM, QX[3], QY[3], 0f).texture(u1, v0).color(r, gr, b, a).next();
        drawn++;
    }


    // ---------- main ----------
    private static final long T0 = System.nanoTime();
    private static long lastNanos = T0;
    private static float dt = 0.016f;

    // Every lyric line is born in the air somewhere in front of you, faces you, and then stays exactly there (position and rotation).
    private static final float R_MIN = 8f, R_MAX = 14f;          // blocks away from you when it is born (never too close)
    private static final float VIEW_HALF_W = 32f;                // it is born inside +-32 degrees sideways of where you look
    private static final float SPOT_LO = -4f, SPOT_HI = 20f;     // and between -4 and +20 degrees up/down from where you aim
    private static final float AIM_MIN = -8f;                    // looking down more than this counts as looking just slightly down
    private static final float ABS_LO = -10f, ABS_HI = 55f;      // lowest / highest angle it may be born at (above you is fine, the floor is not)
    private static final float LEAVE_T = 0.85f;                  // seconds a line needs to drift away

    private static final class Anchor { double x, y, z; float face; float hwB, hhB, k; }
    private static final java.util.HashMap<Integer, Anchor> ANCH = new java.util.HashMap<>();
    private static Lrc lastLrc = null;
    // song end: the last lines still play their leaving animation instead of vanishing
    private static boolean playing = false, ending = false;
    private static double lastT = 0, forceLeave = Double.MAX_VALUE;
    private static long endNs = 0;
    private static Lrc endLrc = null;
    private static int frameNo = 0;
    private static java.util.Random rng = new java.util.Random();
    private static String lastTitle = null, titleText = "♪", titlePlain = "♪";

    // per-frame context
    private static Lrc ctxLrc;
    // result of chunkInfo()
    private static double cTime, cSweep, cLeave;

    private static void renderHud(DrawContext dc, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !haveVP) { playing = false; ending = false; return; }
        long now = System.nanoTime();
        dt = Math.max(0.0005f, Math.min(0.05f, (now - lastNanos) / 1e9f));
        lastNanos = now;
        double t = SkyMusicClient.PLAYER.getTime();
        boolean fin = false;
        if (t >= 0) { playing = true; ending = false; lastT = t; endLrc = SkyMusicClient.lyrics; }
        else {
            if (playing) { playing = false; ending = true; endNs = now; }     // the song just ended (or was stopped)
            if (ending) {
                double el = (now - endNs) / 1e9;
                if (el > 1.9) ending = false; else { fin = true; t = lastT + el; }
            }
            if (!fin) { anchored = false; status = "no song playing"; return; }
        }
        try {
            scrW = mc.getWindow().getScaledWidth();
            scrH = mc.getWindow().getScaledHeight();
            forceLeave = fin ? lastT : Double.MAX_VALUE;           // everything still on screen leaves now
            renderLyrics(dc, mc, t, fin ? endLrc : SkyMusicClient.lyrics);
        } catch (Throwable e) {
            endAtlas();
            status = "error: " + e;
            if (!errorShown) { errorShown = true; SkyMusicClient.msg("Lyrics error (please report): " + e); }
        }
    }

    /** chunk 0 = title card, chunk n = lyric line n-1 */
    private static String itemText(int c) {
        if (c == 0) return titleText;
        String s = ctxLrc.lines.get(c - 1).text();
        return s.isEmpty() ? "♪  ♫  ♪" : s;
    }

    /** when chunk c starts, how long its words take to light up and when it starts to leave (seconds of song time). false = not shown. */
    private static boolean chunkInfo(int c, int nLines) {
        String tx = itemText(c);
        int len = tx.codePointCount(0, tx.length());
        if (c == 0) {
            double first = ctxLrc != null ? ctxLrc.lines.get(0).time() : 7.0;
            if (ctxLrc != null && first < 1.2) return false;          // lyrics start right away, no room for a title card
            cTime = 0;
            cSweep = Math.max(0.6, Math.min(first * 0.7, 1.6));
            cLeave = Math.min(Math.min(first, cSweep + 3.5), forceLeave);
            return true;
        }
        Lrc.Line ln = ctxLrc.lines.get(c - 1);
        double next = c < nLines ? ctxLrc.lines.get(c).time() : ln.time() + 5.0;
        double gap = Math.max(0.3, next - ln.time());
        cTime = ln.time();
        // the words light up across the time the line is sung (the gap to the next line), but a short line in a long gap does not drag
        cSweep = Math.max(0.45, Math.min(gap * 0.88, Math.max(len * 0.09, 0.9)));
        cLeave = Math.min(cTime + Math.max(0.8, Math.min(gap, cSweep + 2.8)), forceLeave);   // leaves when the next line comes, or a bit after it was sung
        return true;
    }

    /** distance in degrees between two rectangles (negative = overlapping) */
    private static float rectSep(float y, float e, float hw, float hh, float oy, float oe, float ohw, float ohh) {
        return Math.max(Math.abs(y - oy) - (hw + ohw), Math.abs(e - oe) - (hh + ohh));
    }

    /** how far (degrees, as seen from where you stand now) a candidate spot is from an earlier line; large if that line is far away */
    private static float sepToAnchor(Anchor p, float y, float e, float hwD, float hhD) {
        if (p == null) return 99f;
        double dx = p.x - camX, dy = p.y - camY, dz = p.z - camZ;
        double dist = Math.max(0.5, Math.sqrt(dx * dx + dy * dy + dz * dz));
        float elAbs = (float) Math.toDegrees(Math.asin(dy / dist));
        float yawRel = wrapDeg((float) Math.toDegrees(Math.atan2(-dx, dz)) - camYaw) * (float) Math.cos(Math.toRadians(elAbs));
        float elRel = elAbs - (-camPitch);
        float hw = (float) Math.toDegrees(Math.atan(p.hwB / dist)), hh = (float) Math.toDegrees(Math.atan(p.hhB / dist));
        return rectSep(y, e, hwD, hhD, yawRel, elRel, hw, hh);
    }

    private static boolean solidAt(MinecraftClient mc, BlockPos pos) {
        net.minecraft.block.BlockState st = mc.world.getBlockState(pos);
        if (st.isAir()) return false;
        return !st.getCollisionShape(mc.world, pos).isEmpty() || !st.getFluidState().isEmpty();   // stone, trees, leaves, water ... not grass or flowers
    }

    /** how many spots of the sign (centre ax,ay,az, facing angle face) lie inside blocks (coarse grid: this runs when a line is born) */
    private static int solidHits(MinecraftClient mc, double ax, double ay, double az, float hw, float hh, float face) {
        if (mc.world == null) return 0;
        float rx = (float) Math.sin(face), rz = (float) -Math.cos(face);
        float nx = (float) Math.cos(face), nz = (float) Math.sin(face);
        int nw = Math.max(1, Math.min(4, (int) Math.ceil(hw / 1.8f))), nh = Math.max(1, Math.min(2, (int) Math.ceil(hh / 1.8f)));
        BlockPos.Mutable bp = new BlockPos.Mutable();
        int hits = 0;
        for (int i = -nw; i <= nw; i++)
            for (int j = -nh; j <= nh; j++)
                for (int d = -1; d <= 1; d++) {
                    double u = i * hw / nw, py = ay + j * hh / nh;
                    bp.set(ax + rx * u + nx * d * 0.6, py, az + rz * u + nz * d * 0.6);
                    if (solidAt(mc, bp) && ++hits >= 4) return hits;
                }
        return hits;
    }

    /**
     * The fixed place in the world where chunk c lives; picked the first time it is needed from where you look right now:
     * in front of you (if you look down it is just ahead of where you stand), never lower than your feet, never too close,
     * and, as far as possible, not inside blocks. It faces you when it is born and never turns after that.
     */
    private static Anchor anchorFor(MinecraftClient mc, int c, Layout L, float bias) {
        Anchor a = ANCH.get(c);
        if (a != null) return a;
        float aim = Math.max(-camPitch, AIM_MIN);
        double feetY = mc.player.getY();
        Anchor p1 = ANCH.get(c - 1), p2 = ANCH.get(c - 2);
        double bx = 0, by = 0, bz = 0; float bk = R_MIN / (float) DIST, bhw = 2f, bhh = 1f, bface = 0f, bScore = -1e9f;
        for (int tries = 0; tries < 28; tries++) {
            float R = R_MIN + rng.nextFloat() * (R_MAX - R_MIN);
            float k = R / (float) DIST;
            float hw = L.maxW * scaleOf(L) * k * 0.5f * 1.15f + 0.4f;
            float hh = heightOf(L, 1f) * k * 0.5f * 1.15f + 0.3f;
            float hwD = (float) Math.toDegrees(Math.atan(hw / R)), hhD = (float) Math.toDegrees(Math.atan(hh / R));
            float lim = Math.max(0f, VIEW_HALF_W - hwD);
            float eLo = SPOT_LO + hhD, eHi = SPOT_HI - hhD;
            if (eLo > eHi) eLo = eHi = (SPOT_LO + SPOT_HI) / 2f;
            float yo = (rng.nextFloat() * 2f - 1f) * lim;
            float eo = eLo + rng.nextFloat() * (eHi - eLo);
            float sc = rectSep(yo, eo, hwD, hhD, 0f, 0f, 3f, 3f) + 4f;                // keep the crosshair clear
            sc = Math.min(sc, Math.min(sepToAnchor(p1, yo, eo, hwD, hhD), sepToAnchor(p2, yo, eo, hwD, hhD)));
            sc = Math.min(sc, 20f);

            float eAbs = Math.max(ABS_LO, Math.min(ABS_HI, aim + eo + bias));
            double er = Math.toRadians(eAbs), ce = Math.cos(er);
            R = (float) Math.max(R, 6.5 / Math.max(0.3, ce));                             // always at least 6.5 blocks away sideways
            double yr = Math.toRadians(camYaw + yo / Math.max(0.35, ce));
            double ax = camX - Math.sin(yr) * ce * R;
            double az = camZ + Math.cos(yr) * ce * R;
            double ay = Math.max(camY + Math.sin(er) * R, feetY + hh + 0.5);               // never below the floor you stand on
            float face = (float) Math.atan2(camZ - az, camX - ax);                         // looks at you, for good
            int hits = solidHits(mc, ax, ay, az, hw, hh, face);
            float score = sc - hits * 30f;
            if (score > bScore) { bScore = score; bx = ax; by = ay; bz = az; bk = k; bhw = hw; bhh = hh; bface = face; }
            if (hits == 0 && sc >= 5f) break;
        }
        a = new Anchor();
        a.x = bx; a.y = by; a.z = bz; a.face = bface; a.k = bk; a.hwB = bhw; a.hhB = bhh;
        ANCH.put(c, a);
        return a;
    }

    private static void renderLyrics(DrawContext dc, MinecraftClient mc, double t, Lrc lrc) {
        TextRenderer tr = mc.textRenderer;
        boolean atlas = useAtlas();
        boolean hasLyrics = lrc != null && !lrc.lines.isEmpty();
        int nLines = hasLyrics ? lrc.lines.size() : 0;
        drawn = 0;
        hudM = dc.getMatrices().peek().getPositionMatrix();
        dc.draw();                                                 // whatever was drawn before us goes first

        String ttl = SkyMusicClient.title;
        if (ttl == null) ttl = "";
        if (!ttl.equals(lastTitle)) {
            lastTitle = ttl;
            titleText = ttl.isEmpty() ? "♪" : "♪  " + ttl;
            titlePlain = ttl.isEmpty() ? "♪" : "♪ " + ttl;
            ANCH.clear();
        }
        Lrc use = hasLyrics ? lrc : null;
        if (use != lastLrc) { lastLrc = use; ANCH.clear(); rng = new java.util.Random(); }
        ctxLrc = use;
        float bias = (float) Math.toDegrees(ELEV - 0.45f);       // /sky height shifts where new lines are born, up or down

        double secs = (System.nanoTime() - T0) / 1e9;
        animSecs = secs;

        int idx = hasLyrics ? lrc.indexAt(t) : -1;
        int cur = idx + 1;
        String plain = null;
        boolean visible = false;                                   // is the line being sung on screen right now?
        for (int c = Math.max(0, cur - 5); c <= cur; c++) {          // oldest first, so the newest chunk is painted on top
            if (!chunkInfo(c, nLines)) continue;
            double tIn = t - cTime;
            double tLeave = t - cLeave;
            if (tIn < 0 || tLeave > LEAVE_T) continue;

            Layout L = layoutFor(itemText(c), tr, atlas);
            Anchor an = anchorFor(mc, c, L, bias);

            float spr = spring((float) tIn);                                     // springs up into place (a little overshoot)
            float ex = clamp01((float) (tLeave / LEAVE_T));
            float exS = smooth(ex);                                              // then drifts up and away ...
            float dimK = smooth(clamp01(ex * 2.2f));                             // ... dimming first,
            float softK = smooth(clamp01((ex - 0.05f) * 1.7f));                  // ... going out of focus,
            float outA = 1f - smooth(clamp01((ex - 0.30f) / 0.70f));             // ... and fading out
            float bob = (float) Math.sin(secs * 0.8 + c * 1.7) * 0.05f;          // barely floating
            double rx = an.x - camX, ry = an.y - camY + bob - (1f - spr) * 0.30 + exS * 1.25, rz = an.z - camZ;
            float scaleK = (0.90f + 0.10f * spr) * (1f - 0.07f * exS);
            float sBlocks = scaleOf(L) * an.k * scaleK;
            float rightX = (float) Math.sin(an.face), rightZ = (float) -Math.cos(an.face);
            drawChunk(dc, tr, L, rx, ry, rz, rightX, rightZ, sBlocks, (float) tIn, (float) cSweep, (float) tLeave, outA, dimK, softK);
            if (c == cur) {
                plain = c == 0 ? titlePlain : itemText(c);
                visible = project(rx, ry, rz, PC) && PC[0] > scrW * 0.04f && PC[0] < scrW * 0.96f && PC[1] > scrH * 0.04f && PC[1] < scrH * 0.96f;
            }
        }
        endAtlas();                           // all lyric glyphs go out in one draw call
        dc.draw();                            // then the vanilla-font fallback text, so it all sits under the rest of the HUD

        // small plain subtitle when you are not looking at the floating lyrics (or always, /sky subtitle on)
        int sm = subtitleMode;
        if (plain != null && (sm == 1 || (sm == 2 && !visible))) {
            int y = (int) (scrH * 0.12f);
            dc.drawCenteredTextWithShadow(tr, Text.literal(plain), (int) (scrW / 2f), y, 0xFFFFFF);
        }
        if ((frameNo++ & 15) == 0)
            status = "playing, t=" + String.format("%.1f", t) + ", quads drawn=" + drawn + ", on screen=" + visible
                + ", font=" + (atlas ? "baked atlas" : (customFont ? "vanilla (atlas missing)" : "vanilla"));
    }

    /**
     * Draws one lyric line as an upright sign in the world. (rx, ry, rz) = its centre relative to the camera, (rightX, rightZ) = which way
     * "right" points, s = blocks per layout px. tIn = seconds since the line started (words light up as it is sung), sweep = seconds the
     * singing of the line takes, tLeave = seconds since it started leaving (negative = not leaving yet), lineA = overall opacity,
     * dimK / softK = how far the line has dimmed / gone out of focus.
     */
    private static void drawChunk(DrawContext dc, TextRenderer tr, Layout L, double rx, double ry, double rz, float rightX, float rightZ, float s,
                                  float tIn, float sweep, float tLeave, float lineA, float dimK, float softK) {
        if (lineA < 0.01f) return;
        setPlane(rx, ry, rz, rightX, rightZ, s);
        if (c0w <= 0.05f) return;
        VertexConsumerProvider.Immediate vc = dc.getVertexConsumers();
        float sw = Math.max(0.2f, sweep);
        for (int pass = 0; pass < 2; pass++) {                           // pass 0: soft shadow + glow behind, pass 1: the letters
            for (int r = 0; r < L.rows; r++) {
                float rowY = (r - (L.rows - 1) / 2f) * ROW_GAP;
                float x0 = -L.rowW[r] / 2f;
                for (Seg sg : L.segs[r]) {
                    float p = smooth(clamp01((tIn - sg.f0 * sw) / Math.max(0.16f, (sg.f1 - sg.f0) * sw * 1.25f)));   // 0 = not sung yet, 1 = sung
                    float sl = smooth(clamp01((tLeave - sg.idx * 0.035f) / 0.7f));                                    // leaving, word by word
                    float wordA = lineA * (1f - 0.5f * sl);
                    float bt = clamp01(p * (1f - 0.65f * dimK));                                                      // brightness
                    float cr = lerp(0.74f, 1f, bt), cg = lerp(0.82f, 1f, bt), cb = lerp(0.98f, 0.985f, bt);
                    float segCx = x0 + sg.x + sg.w / 2f;
                    float onset0 = sg.f0 * sw, span = (sg.f1 - sg.f0) * sw * 0.8f;     // the letters of a piece are sung one after the other
                    if (sg.legacy) {                                     // letters the atlas does not have: vanilla font (moves as one piece)
                        if (pass == 0) continue;
                        letterMotion(sg.base, L.total, tIn, onset0, sl, p, dimK);
                        float pcy = rowY + mOff;
                        float sharpA = wordA * mA * (0.42f + 0.58f * bt);
                        if (!sp(segCx, pcy)) continue;
                        float ox = SX, oy = SY;
                        if (!sp(segCx + 8f, pcy)) continue;
                        float ax = (SX - ox) / 8f, ay = (SY - oy) / 8f;
                        if (!sp(segCx, pcy + 8f)) continue;
                        float bx = (SX - ox) / 8f, by = (SY - oy) / 8f;
                        int a = (int) (255 * sharpA);
                        if (a < 8) continue;                             // tiny alpha would be treated as opaque by vanilla
                        AFF.set(ax, ay, 0f, 0f, bx, by, 0f, 0f, 0f, 0f, 1f, 0f, ox, oy, 0f, 1f);
                        MT.set(hudM).mul(AFF).scale(LEG * mSx, LEG * mSy, 1f);
                        tr.draw(sg.ot, -sg.lw / 2f, -4f, rgb(cr, cg, cb, a), true, MT, vc, TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
                        drawn++;
                        continue;
                    }
                    for (int i = 0; i < sg.cp.length; i++) {
                        LyricFont.Glyph g = LyricFont.get(sg.cp[i]);
                        letterMotion(sg.base + i, L.total, tIn, onset0 + span * i / Math.max(1, sg.n), sl, p, dimK);
                        float pen = x0 + sg.x + sg.gx[i];
                        float foot = pen + g.adv * 0.5f;                          // the letter stays planted on its own foot
                        float base = rowY + BASE + mOff;
                        float a = wordA * mA;
                        if (pass == 0) {
                            float glowA = a * (0.60f * (float) Math.sin(Math.PI * p) + 0.30f * p * (1f - dimK));
                            float shA = a * 0.34f * (0.6f + 0.4f * bt);
                            glyphQuad(g, 2, pen, base, foot, mSx, mSy, mLean, 0.03f, 0.05f, 0.13f, shA, 1.6f);
                            glyphQuad(g, 2, pen, base, foot, mSx, mSy, mLean, 0.58f, 0.76f, 1f, glowA, 0f);
                        } else {
                            float sharpA = a * (0.42f + 0.58f * bt);
                            glyphQuad(g, 0, pen, base, foot, mSx, mSy, mLean, cr, cg, cb, sharpA * (1f - softK), 0f);
                            if (softK > 0.02f) glyphQuad(g, 1, pen, base, foot, mSx, mSy, mLean, cr, cg, cb, sharpA * softK, 0f);
                        }
                    }
                }
            }
        }
    }
}
